@echo off
title LocalTranslate - Avvio
color 0A
cd /d "%~dp0"

echo ================================================================
echo                    LocalTranslate Windows
echo           Traduzione Locale 100%% Offline * Zero Cloud
echo ================================================================
echo.

:: 1. Verifica se l'ambiente virtuale esiste
if not exist ".venv\Scripts\pythonw.exe" (
    echo [ATTENZIONE] LocalTranslate non e' ancora stato installato su questo PC!
    echo.
    echo Prima del primo avvio, e' necessario completare l'installazione
    echo automatica guidata per scaricare il modello locale (600 MB).
    echo.
    echo Avvio automatico di "1-INSTALLA-SUBITO.bat"...
    echo ================================================================
    pause
    call "1-INSTALLA-SUBITO.bat"
    exit /b
)

:: 2. Verifica se il modello esiste
if not exist "backend\models\manifest.json" (
    if not exist "backend\models\nllb-200-distilled-600M-int8\manifest.json" (
        echo [ATTENZIONE] Il modello di traduzione locale non e' ancora scaricato!
        echo.
        echo Avvio di "1-INSTALLA-SUBITO.bat" per scaricare il modello...
        echo ================================================================
        pause
        call "1-INSTALLA-SUBITO.bat"
        exit /b
    )
)

:: 3. Avvio in background (finestra invisibile)
echo Avvio di LocalTranslate in background (Area di Notifica / System Tray)...
start "" wscript.exe "LocalTranslate.vbs"

echo.
echo ================================================================
echo [SUCCESSO] LocalTranslate e' ora attivo e funzionante!
echo.
echo - L'icona si trova in basso a destra nell'Area di Notifica (System Tray).
echo - Seleziona qualsiasi testo in QUALSIASI programma e premi:
echo.
echo       Ctrl + Alt + T
echo.
echo - Apparira' subito la finestra fluttuante con la traduzione!
echo ================================================================
echo.
timeout /t 5 >nul
exit
