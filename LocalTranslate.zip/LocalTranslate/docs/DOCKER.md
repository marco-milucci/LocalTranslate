# Guida Docker per LocalTranslate

Questa modalità è ideale per ambienti aziendali, PC con proxy restrittivi o utenti che preferiscono non installare Python e dipendenze `pip` sul sistema operativo host.

---

## 🌟 Vantaggi della Modalità Docker

1. **Zero Installazioni su Windows**: non serve installare Python, né configurare `pip`, CTranslate2, SentencePiece o PyTorch su Windows.
2. **Superamento del Blocco Proxy**: Docker Desktop gestisce il proxy aziendale in modo centralizzato e trasparente, evitando gli errori di rete di `pip` o del terminale Windows.
3. **Isolamento e Sicurezza**: tutto l'ambiente di runtime gira all'interno di un container Linux isolato.
4. **Privacy Assoluta**: la porta `8765` è esposta tassativamente ed esclusivamente su `127.0.0.1:8765` (localhost) dell'host. Nessun accesso esterno è permesso.

---

## 📋 Prerequisiti

- **Docker Desktop per Windows** (con backend WSL2 abilitato).
- Se la tua azienda usa un proxy, configuralo in Docker Desktop:
  - Clicca sull'icona dell'ingranaggio (**Settings**) in Docker Desktop.
  - Vai su **Resources** ➔ **Proxies**.
  - Inserisci il server proxy aziendale (es. `http://proxy.azienda.lan:8080`).

---

## 🚀 Avvio Rapido in 1 Clic (Windows)

Nella cartella del progetto trovi due file dedicati:

### 1. Avviare il Container
Fai doppio clic su:
```text
DOCKER-AVVIA.bat
```
Lo script:
- Verifica che Docker Desktop sia attivo.
- Costruisce l'immagine Docker (`localtranslate:latest`) con tutte le librerie pre-installate.
- Se il modello locale (600 MB) non è ancora presente, ti chiederà se desideri scaricarlo direttamente tramite la connessione di Docker.
- Avvia il backend su `http://127.0.0.1:8765`.

### 2. Fermare il Container
Quando hai finito, fai doppio clic su:
```text
DOCKER-FERMA.bat
```

---

## 🌐 Utilizzo con l'Estensione Chrome / Edge

Una volta avviato il container Docker:
1. Apri **Google Chrome** o **Microsoft Edge**.
2. Vai su `chrome://extensions` o `edge://extensions`.
3. Attiva la spunta **Modalità sviluppatore**.
4. Clicca su **Carica estensione non pacchettizzata** e seleziona la cartella `extension` di LocalTranslate.
5. Seleziona qualsiasi testo su qualsiasi pagina web:
   - **Tasto destro ➔ LocalTranslate ➔ Traduci in italiano**!

---

## 🛠️ Comandi Manuali da Terminale (CLI)

Se preferisci usare direttamente la riga di comando:

### Build e Avvio:
```bash
docker compose up -d --build
```

### Download del modello all'interno del container:
```bash
docker compose exec localtranslate python -m backend.scripts.download_and_convert
```

### Visualizzare i log di traduzione (solo metriche tecniche):
```bash
docker compose logs -f
```

### Verificare la salute del servizio:
```bash
curl http://127.0.0.1:8765/health
```

### Arresto del servizio:
```bash
docker compose down
```
