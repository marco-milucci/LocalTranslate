# Modello di Traduzione e Quantizzazione: LocalTranslate

Questo documento descrive il modello di base utilizzato da LocalTranslate, le tecniche di quantizzazione adottate, le licenze d'uso e la procedura per integrare modelli futuri.

---

## 1. Modello di Base: NLLB-200 Distilled 600M

LocalTranslate utilizza come modello universale di base:

```
facebook/nllb-200-distilled-600M
```

Sviluppato da **Meta AI Research** all'interno dell'iniziativa *No Language Left Behind* (NLLB), si tratta di un'architettura **Encoder-Decoder Transformer** multilingue ad alta capacità:

- **Parametri**: ~615 milioni (versione distillata ottimizzata per l'efficienza).
- **Copertura Linguistica**: Supporta oltre **200 lingue** e varianti geografiche, garantendo una traduzione diretta senza dover passare obbligatoriamente dall'inglese come lingua ponte.
- **Accuratezza**: Offre traduzioni di **alta qualità** e fluidità semantica in contesti generali, tecnici e quotidiani.
  *(Nota etica: Non viene mai dichiarata una traduzione "matematicamente perfetta"; i sistemi neurali generano traduzioni di alta qualità soggette a possibili sfumature di contesto).*

---

## 2. Motore di Esecuzione e Quantizzazione INT8

Per consentire l'esecuzione fluida su PC desktop e laptop consumer senza richiedere GPU costose, il modello viene convertito nel formato compatto **CTranslate2**:

### Vantaggi di CTranslate2 rispetto a PyTorch tradizionale:
1. **Velocità**: Kernel C++ ottimizzati per CPU (istruzioni vettoriali AVX, AVX2, AVX-512 e ARM NEON) e GPU (Tensor Cores NVIDIA), con un incremento di throughput da 3x a 5x.
2. **Quantizzazione INT8 (`int8_float32`)**:
   - I pesi delle matrici lineari a 32-bit (FP32) vengono quantizzati su numeri interi a 8-bit (INT8).
   - L'occupazione di memoria RAM passa da ~2.4 GB a soli **~650 - 750 MB**.
   - La perdita di accuratezza rispetto al modello originale a precisione piena è virtualmente impercettibile (< 0.2 punti BLEU).
3. **Residenza in Memoria**: Il modello viene caricato una sola volta all'avvio del backend e rimane pronto per l'inferenza istantanea.

---

## 3. Gestione e Verifica tramite Manifest

La directory del modello (`backend/models/nllb-200-distilled-600M-int8/`) include un file descrittivo crittografico:

```json
{
  "model_id": "facebook/nllb-200-distilled-600M",
  "version": "1.0.0",
  "quantization": "int8",
  "framework": "ctranslate2",
  "files": {
    "model.bin": {
      "sha256": "4b68e...",
      "size_bytes": 625123456
    },
    "shared_vocabulary.json": {
      "sha256": "a1c9...",
      "size_bytes": 4812300
    },
    "sentencepiece.bpe.model": {
      "sha256": "e3b0...",
      "size_bytes": 4721990
    }
  }
}
```

La classe `ModelManager`:
- Verifica che tutti i file siano presenti.
- Confronta gli hash calcolati con quelli del manifest prima di caricare il modello.
- Se un file risulta modificato o incompleto, il caricamento viene interrotto e viene notificato un avviso chiaro all'utente.

---

## 4. Architettura Multi-Modello e Sostituzione Modelli

Il sistema è progettato tramite il disaccoppiamento `BaseModelProvider` e `ModelRouter` per consentire l'aggiunta di modelli alternativi:

### Scenari Supportati dal Router:
1. **Modelli Specializzati per Coppie Comuni**:
   - È possibile registrare modelli dedicati bilingue (ad es. **Helsinki-NLP / OPUS-MT** per `en -> it` o `it -> en`).
   - I modelli OPUS-MT hanno un peso di soli ~150-250MB e una latenza ancora inferiore.
2. **Modelli Futuri a Maggiore Capacità**:
   - Possibilità di collegare modelli da 1.3B o 3.3B quando sono disponibili GPU o quantità elevate di RAM.

### Come Integrare un Nuovo Modello:
1. Converte il modello desiderato in formato CTranslate2 nella cartella `backend/models/<nome-modello>/`.
2. Crea una sottoclasse di `BaseModelProvider` per configurare il tokenizer del nuovo modello.
3. Registra la route in `ModelRouter`:
   ```python
   router.register_route(
       "opus-mt-en-it",
       ModelRoute(
           model_id="Helsinki-NLP/opus-mt-en-it",
           source_languages=["eng_Latn"],
           target_languages=["ita_Latn"],
           min_ram_gb=1.0,
           requires_cuda=False,
           is_specialized=True,
       )
   )
   ```

---

## 5. Licenze e Condizioni d'Uso

- **Codice di LocalTranslate**: Rilasciato sotto licenza libera open source **MIT License**.
- **Modello NLLB-200**: Il modello `facebook/nllb-200-distilled-600M` è concesso in licenza da **Meta AI** sotto i termini della licenza **Creative Commons Attribution-NonCommercial 4.0 International (CC-BY-NC 4.0)**.
  - L'uso è liberamente consentito per fini personali, accademici, di ricerca e non commerciali.
  - Per utilizzi commerciali diretti, l'architettura di LocalTranslate consente di sostituire NLLB-200 con modelli compatibili con licenze commerciali (ad esempio modelli basati su OPUS-MT con licenza Apache 2.0).
