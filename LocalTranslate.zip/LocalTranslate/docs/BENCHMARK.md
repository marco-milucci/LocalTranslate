# Guida al Benchmark Locale: LocalTranslate

Questa guida illustra come misurare con precisione le prestazioni di inferenza, la latenza, il throughput e il consumo di memoria sul tuo hardware locale.

---

## 1. Esecuzione del Benchmark

Il benchmark può essere eseguito direttamente tramite lo script CLI dedicato:

```bash
# Esecuzione con profilo Fast (default)
python backend/scripts/benchmark.py --profile fast

# Esecuzione con profilo Quality
python backend/scripts/benchmark.py --profile quality
```

Su Windows con virtual environment:
```powershell
.\.venv\Scripts\python.exe backend\scripts\benchmark.py --profile fast
```

---

## 2. Metriche Rilevate

Lo script di benchmark esegue una batteria di test progressivi e riporta:

1. **Rilevamento Hardware**:
   - Architettura CPU, core fisici, thread logici.
   - Disponibilità CUDA e GPU.
   - Dispositivo di calcolo e compute type selezionato (`int8`, `int8_float32`, `float16`).
2. **Consumo di Memoria**:
   - Memoria RAM del processo prima e dopo il caricamento del modello.
   - Tempo di inizializzazione iniziale del modello residente.
3. **Scenari di Traduzione**:
   - **Testo Breve**: Latenza su singola frase tipica da browser.
   - **Testo Medio**: Paragrafo esplicativo di ~350 caratteri.
   - **Testo Grande**: Documento multi-paragrafo con preservazione formattazione.
   - **Batch Traduzioni**: 32 frasi elaborate simultaneamente per misurare il picco di throughput vettoriale.

---

## 3. Valori Prestazionali Tipici

| Hardware di Riferimento | Dispositivo | Compute Type | Latenza Singola Frase | Throughput Batch | RAM Residente |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Intel Core i7-12700 / AMD Ryzen 7** | CPU (8 cores) | `int8_float32` | ~35 - 55 ms | ~1.400 - 2.200 car/s | ~680 MB |
| **Intel Core i5 / Laptop 4-core** | CPU (4 cores) | `int8_float32` | ~60 - 95 ms | ~850 - 1.200 car/s | ~650 MB |
| **NVIDIA RTX 3060 / 4060** | CUDA GPU | `int8_float16` | ~12 - 20 ms | ~4.500 - 7.000 car/s | ~420 MB VRAM |
| **ARM64 (Apple M-series / Snapdragon X)** | CPU NEON | `int8` | ~40 - 65 ms | ~1.200 - 1.800 car/s | ~640 MB |

---

## 4. Confronto tra Profili: Fast vs Quality

- **Profilo Fast (`--profile fast`)**:
  - Utilizza Greedy search (beam size = 1) o beam ridotto.
  - Dimensione batch elevata (fino a 16 chunk per passo).
  - Ideale per traduzione immediata di articoli, email e pagine web generiche.
  - Throughput circa **2.5x - 3.5x superiore**.

- **Profilo Quality (`--profile quality`)**:
  - Utilizza Beam search esteso (beam size = 4).
  - Batch conservativo (4 chunk per passo) per massimizzare la precisione dell'esplorazione lessicale.
  - Ideale per contratti, documentazione tecnica complessa e testi legali.
