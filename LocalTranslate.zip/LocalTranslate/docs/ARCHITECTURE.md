# Architettura del Sistema: LocalTranslate

Questo documento descrive in dettaglio l'architettura tecnica, i pattern di progettazione e i flussi di dati di **LocalTranslate**.

---

## 1. Visione d'Insieme

LocalTranslate è strutturato come un'applicazione a due livelli:
1. **Frontend**: Un'estensione per browser basata su **Manifest V3** per Google Chrome e Microsoft Edge.
2. **Backend**: Un servizio HTTP locale autonomo basato su **FastAPI**, **Uvicorn** e **CTranslate2**, vincolato tassativamente all'interfaccia di loopback `127.0.0.1`.

```
+-------------------------------------------------------------------------+
|                              BROWSER WEB                                |
|                                                                         |
|  [Testo Selezionato]                                                    |
|           |                                                             |
|           v (chrome.contextMenus onClick)                               |
|  +-------------------------------------+                                |
|  |     service_worker.js (MV3)         |                                |
|  |                                     |                                |
|  |  Salva in chrome.storage.session    |                                |
|  |  (Nessun dato nella Query String!)  |                                |
|  +------------------+------------------+                                |
|                     | Apre popup.html                                   |
|                     v                                                   |
|  +-------------------------------------+                                |
|  |         popup.html / popup.js       |                                |
|  |                                     |                                |
|  |  1. Legge e PURGA storage.session   |                                |
|  |  2. Invoca API locale via fetch     |                                |
|  +------------------+------------------+                                |
+---------------------|---------------------------------------------------+
                      | HTTP POST (http://127.0.0.1:8765/v1/translate)
                      v
+-------------------------------------------------------------------------+
|                       BACKEND PYTHON LOCALE                             |
|                                                                         |
|  +-------------------------------------------------------------------+  |
|  | SecurityValidator & PrivacyLogFilter                              |  |
|  |  - Valida dimensioni e origini CORS (solo estensione e localhost) |  |
|  |  - Rifiuta shell injection, path traversal                        |  |
|  |  - Esclude rigorosamente il testo dell'utente dai log             |  |
|  +----------------------------------+--------------------------------+  |
|                                     |                                   |
|                                     v                                   |
|  +-------------------------------------------------------------------+  |
|  | LocalLanguageDetector                                             |  |
|  |  - Analisi offline n-gram e script con calcolo confidenza         |  |
|  +----------------------------------+--------------------------------+  |
|                                     |                                   |
|                                     v                                   |
|  +-------------------------------------------------------------------+  |
|  | IntelligentChunker                                                |  |
|  |  - Riconoscimento paragrafi (\n\n), righe vuote                   |  |
|  |  - Protezione URL, email, abbreviazioni, numeri decimali, codice  |  |
|  |  - Generazione sequenza ordinata di TextChunk                     |  |
|  +----------------------------------+--------------------------------+  |
|                                     |                                   |
|                                     v                                   |
|  +-------------------------------------------------------------------+  |
|  | BatchManager & ModelRouter                                        |  |
|  |  - Selezione modello (NLLB universale / modelli specializzati)    |  |
|  |  - Dynamic batching secondo profilo (Fast: 16, Quality: 4)        |  |
|  +----------------------------------+--------------------------------+  |
|                                     |                                   |
|                                     v                                   |
|  +-------------------------------------------------------------------+  |
|  | CTranslate2TranslationEngine (RESIDENT IN MEMORY)                 |  |
|  |  - Tokenizzazione SentencePiece                                   |  |
|  |  - Inferenza INT8 (quantizzazione vettorizzata)                   |  |
|  |  - Esecuzione GPU (CUDA) o CPU (senza oversubscription)           |  |
|  |  - Cache LRU in memoria per duplicati                             |  |
|  +----------------------------------+--------------------------------+  |
|                                     |                                   |
|                                     v                                   |
|  +-------------------------------------------------------------------+  |
|  | TextReconstructor                                                 |  |
|  |  - Ricostruzione esatta di spaziature, indentazioni e paragrafi   |  |
|  +-------------------------------------------------------------------+  |
+-------------------------------------------------------------------------+
```

---

## 2. Moduli e Pattern di Progettazione

L'architettura del backend è rigorosamente disaccoppiata tramite interfacce astratte:

### `BaseModelProvider` & `NLLBModelProvider`
Isola il reperimento e la tokenizzazione dei file del modello. Fornisce:
- `get_model_path()`
- `load_tokenizer()`
- `tokenize(text, lang)`
- `detokenize(tokens)`
- `get_metadata()`

Questo consente di sostituire l'attuale modello NLLB con altri modelli (ad es. MarianMT/OPUS o modelli personalizzati) senza modificare una singola riga del motore di inferenza o delle route API.

### `BaseTranslationEngine` & `CTranslate2TranslationEngine`
Gestisce l'inferenza ad alte prestazioni. 
- Mantiene l'oggetto `ctranslate2.Translator` **residente in memoria** per l'intero ciclo di vita dell'applicazione. Non viene mai ricaricato tra una richiesta e l'altra.
- Implementa una cache in RAM di tipo **Least Recently Used (LRU)** con limite di 2048 elementi per velocizzare frasi frequenti o duplicati.

### `ModelManager`
Supervisiona il ciclo di vita e l'integrità dei pesi:
- Verifica l'integrità di ciascun file tramite hash **SHA-256** memorizzati in `manifest.json`.
- Rileva file mancanti o corrotti.
- Se il modello è assente, solleva un'eccezione con il messaggio prescrittivo:
  `Modello non installato. Avvia l'installazione del modello locale.`
- Non tenta **mai** il download automatico da Internet durante una chiamata di traduzione.

### `HardwareDetector`
All'avvio, esamina le capacità del sistema ospite:
- **Dispositivo**: Se CUDA è installato e funzionante con CTranslate2, assegna `device = "cuda"`. Altrimenti, esegue un fallback trasparente su `device = "cpu"`.
- **Compute Type**: Seleziona automaticamente `int8_float16` o `float16` su CUDA, e `int8_float32` o `int8` su CPU.
- **Thread Allocation**: Calcola `intra_threads` e `inter_threads` in base ai core fisici rilevati tramite `psutil`, rispettando la regola ferrea:
  $$\text{inter\_threads} \times \text{intra\_threads} \le \text{core\_fisici}$$
  Questo evita il degrado prestazionale causato dal thread switching e dalla contesa di cache (oversubscription).

### `IntelligentChunker` & `TextReconstructor`
La traduzione di testi estesi o formattati richiede di preservare la struttura documentale:
1. Il testo viene analizzato separando i paragrafi (`\r?\n\s*\r?\n`).
2. All'interno di ogni paragrafo, le frasi vengono individuate senza spezzare:
   - URL (`https://...`)
   - Indirizzi email (`name@domain.com`)
   - Numeri decimali (es. `3.14159`)
   - Abbreviazioni comuni (`e.g.`, `Dr.`, `Sig.`, `vs.`, ecc.)
   - Blocchi di codice (fenced markdown o backtick)
3. Ciascun chunk mantiene le coordinate di posizionamento (`chunk_id`, `paragraph_idx`, `prefix_ws`, `suffix_ws`).
4. Una volta tradotti i singoli chunk tramite batch, `TextReconstructor` ripristina la struttura originale al carattere esatto.

---

## 3. Elaborazione dei Testi Massivi e Job Asincroni

Per gestire documenti di migliaia di parole senza bloccare l'interfaccia utente né saturare la memoria, LocalTranslate adotta una strategia bifase:

1. **Testi Brevi/Medi (< 4.000 caratteri)**:
   - Inoltrati direttamente a `POST /v1/translate`.
   - Eseguiti in modalità sincrona ad alta priorità.

2. **Testi Grandi (>= 4.000 caratteri)**:
   - Inoltrati a `POST /v1/jobs`.
   - Viene creato un oggetto `TranslationJob` con UUID univoco e accodato a un pool controllato (`ThreadPoolExecutor`).
   - L'endpoint ritorna immediatamente `HTTP 202 Accepted` con `{"job_id": "...", "status": "queued"}`.
   - Il frontend visualizza una barra di progresso e interroga `GET /v1/jobs/{job_id}` ogni 300ms.
   - L'utente può premere **Annulla** in qualsiasi momento, inviando `DELETE /v1/jobs/{job_id}` che attiva un `threading.Event` cooperativo arrestando i batch successivi.
   - **Zero Retention**: Al completamento, il risultato risiede in RAM per un TTL configurabile (default 10 minuti) prima di essere deallocato automaticamente dal garbage collector. Nessun database permanente viene creato sul disco.

---

## 4. Profili di Traduzione

Il sistema supporta due profili selezionabili in tempo reale dall'utente:

| Parametro | Profilo **Fast** | Profilo **Quality** |
| :--- | :--- | :--- |
| **Obiettivo** | Massima velocità e throughput | Massima accuratezza semantica |
| **Beam Size** | 1 (Greedy Search) | 4 |
| **Batch Size** | 16 | 4 |
| **Max Decoding Length** | 256 token | 512 token |
| **Patience** | 1.0 | 1.2 |
| **Repetition Penalty**| 1.05 | 1.10 |
| **Quantizzazione** | INT8 | INT8 |

---

## 5. Sicurezza e Isolamento

- **Ascolto Esclusivo Loopback**: Uvicorn è configurato per ascoltare solo ed esclusivamente su `127.0.0.1`.
- **Politica CORS Rigida**: Le origini ammesse sono limitate alle estensioni del browser (`chrome-extension://*`, `edge-extension://*`) e all'origine loopback locale. Qualsiasi richiesta cross-origin proveniente da siti web ordinari viene bloccata.
- **Validazione Input**: Limite massimo di caratteri per richiesta impostato a 500.000 caratteri con restituzione di codice HTTP 413 in caso di superamento. Sanitizzazione HTML automatica delle stringhe trasmesse alla UI.
