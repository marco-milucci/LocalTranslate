# Guida alla Distribuzione Portabile Plug-and-Play

Questa guida descrive come distribuire **LocalTranslate** su tutti i PC Windows 10/11 come **applicazione autonoma, portabile e autosufficiente**, esattamente come qualsiasi software desktop scaricabile dal web:
* ❌ **Nessun Python da installare** sul PC di destinazione.
* ❌ **Nessun comando `pip`** o dipendenza da scaricare al primo avvio.
* ❌ **Nessun blocco del proxy aziendale** o firewall.
* ❌ **Nessuna dipendenza da Docker** o privilegi di amministratore.
* ✅ **100% Plug-and-Play**: doppio clic su `LocalTranslate.exe` e funziona subito.

---

## 📦 Struttura del Pacchetto Portabile (`LocalTranslate-Portable.zip`)

Quando il pacchetto portabile viene generato, contiene al suo interno tutti i binari nativi Windows e il modello neurale INT8:

```text
LocalTranslate-Portable/
│
├── LocalTranslate.exe                <-- L'applicazione desktop con icona ufficiale (doppio clic per avviare)
├── _internal/                        <-- Tutte le DLL Windows, runtime CTranslate2 INT8 e librerie Python già compilate
│
├── backend/
│   └── models/
│       └── nllb-200-distilled-600M-int8/  <-- Modello neurale già incorporato (600 MB)
│           ├── model.bin
│           ├── shared_vocabulary.json
│           ├── sentencepiece.bpe.model
│           └── manifest.json
│
├── extension/                        <-- Estensione Chrome ed Edge pronta da caricare
│   ├── manifest.json
│   ├── background/
│   └── ui/
│
└── assets/
    └── LocalTranslate.ico            <-- Icona ad alta risoluzione
```

---

## 🛠️ Come Generare il Pacchetto Portabile

Poiché i binari nativi `.exe` e le DLL Windows devono essere compilati per architettura Windows a 64 bit, hai due modalità semplicissime:

### Modalità A: Compilazione Automatica Gratuita in Cloud (GitHub Actions)
Se carichi il progetto su un repository GitHub (anche privato):
1. Vai nella scheda **Actions** del repository su GitHub.
2. Troverai il workflow: **"Build Portable Windows Executable"**.
3. Clicca su **Run workflow**.
4. I server Windows di GitHub installeranno le dipendenze in un ambiente privo di proxy, scaricheranno e quantizzeranno il modello ed eseguiranno PyInstaller.
5. Al termine (circa 5-8 minuti), potrai scaricare direttamente il file:
   ```text
   LocalTranslate-Portable-Windows.zip
   ```
6. Questo ZIP è il pacchetto definitivo pronto per essere distribuito a chiunque!

---

### Modalità B: Compilazione su un Qualsiasi PC Windows Libero (es. PC di casa o non dietro proxy)
Se hai accesso a un PC Windows senza blocchi di rete:
1. Apri la cartella del progetto in PowerShell.
2. Esegui il comando di build:
   ```powershell
   .\windows\build.ps1 -Clean -IncludeModel
   ```
3. Lo script:
   - Compila `LocalTranslate.exe` senza finestra di console nera (`--windowed`).
   - Copia il modello neurale `backend/models` pre-convertito.
   - Copia l'estensione browser.
   - Crea l'archivio compresso:
     ```text
     dist/LocalTranslate-Portable-Windows.zip
     ```

---

## 🚀 Come Distribuire e Usare sui PC Aziendali / con Proxy

Una volta ottenuto `LocalTranslate-Portable-Windows.zip`:

1. **Copia lo ZIP** sul PC di destinazione (tramite chiavetta USB, cartella condivisa aziendale o link intranet).
2. **Estrai lo ZIP** sul Desktop o in una cartella a piacere (es. `C:\LocalTranslate`).
3. **Fai doppio clic su `LocalTranslate.exe`**:
   - L'applicazione compare subito nella barra di notifica (System Tray) vicino all'orologio di Windows.
   - La scorciatoia universale **`Ctrl + Alt + T`** è attiva all'istante in qualsiasi programma (Word, PDF, Notepad, Excel, Browser).
4. **Collega il browser (Chrome o Edge)**:
   - Apri `chrome://extensions` (o `edge://extensions`).
   - Abilita *Modalità sviluppatore*.
   - Clicca *Carica estensione non pacchettizzata* e seleziona la cartella `extension` dentro la cartella estratta.

Zero configurazioni, zero proxy, zero terminale: pura esperienza Plug-and-Play.
