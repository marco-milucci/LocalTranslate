# Guida per lo Sviluppo: LocalTranslate

Questo documento descrive l'ambiente di sviluppo, la struttura del codice sorgente e le procedure per testare ed estendere **LocalTranslate**.

---

## 1. Setup dell'Ambiente di Sviluppo

LocalTranslate supporta sia sistemi **Windows** (10/11) sia ambienti **Linux** e **macOS** per lo sviluppo del backend.

### Con `uv` (consigliato per velocità):
```bash
# Creazione ambiente virtuale
uv venv .venv
source .venv/bin/activate  # Su Windows: .venv\Scripts\activate

# Installazione dipendenze di produzione e sviluppo
uv pip install -r requirements-dev.txt
```

### Con `python venv` standard:
```bash
python3 -m venv .venv
source .venv/bin/activate  # Su Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
```

---

## 2. Esecuzione della Suite di Test

Tutti i test unitari e di integrazione risiedono in `backend/tests/`:

```bash
# Esecuzione completa
pytest backend/tests -v

# Esecuzione con filtro per modulo
pytest backend/tests/test_chunker.py -v
pytest backend/tests/test_privacy.py -v
```

---

## 3. Struttura del Codice

```
LocalTranslate/
├── backend/
│   ├── app/
│   │   ├── main.py                  # Inizializzazione FastAPI e ciclo di vita lifespan
│   │   ├── config.py                # Impostazioni di configurazione e binding loopback
│   │   ├── core/                    # Logica fondamentale disaccoppiata
│   │   │   ├── hardware.py          # Rilevamento CPU, thread e GPU
│   │   │   ├── chunker.py           # Algoritmo di splitting del testo
│   │   │   ├── reconstructor.py     # Ricostruzione documento con preservazione layout
│   │   │   ├── language_detector.py # Rilevatore linguistico 100% offline
│   │   │   ├── languages.py         # Mappatura codici linguistici NLLB
│   │   │   ├── profiles.py          # Profili Fast e Quality
│   │   │   ├── logging_filter.py    # Filtro privacy per log tecnici
│   │   │   └── security.py          # Validazione input, limiti e sanitizzazione
│   │   ├── engine/                  # Motori di inferenza e gestione modelli
│   │   │   ├── base.py              # Interfacce astratte BaseModelProvider / BaseTranslationEngine
│   │   │   ├── model_provider.py    # Provider SentencePiece / NLLB
│   │   │   ├── model_manager.py     # Ciclo di vita modello (install, verify, load)
│   │   │   ├── ctranslate2_engine.py# Motore CTranslate2 residente in memoria
│   │   │   ├── batch_manager.py     # Gestione dynamic batching per chunk multipli
│   │   │   ├── router.py            # ModelRouter per future estensioni multi-modello
│   │   │   └── job_manager.py       # Gestione job asincroni con TTL in memoria
│   │   └── api/                     # Endpoint REST FastAPI
│   │       ├── schemas.py           # Schemi Pydantic v2
│   │       ├── routes_health.py     # GET /health
│   │       ├── routes_capabilities.py # GET /v1/capabilities
│   │       ├── routes_translate.py  # POST /v1/translate e batch
│   │       └── routes_jobs.py       # POST /v1/jobs, GET /v1/jobs/{id}, DELETE /v1/jobs/{id}
│   ├── scripts/
│   │   ├── download_and_convert.py  # Script CLI per conversione pesi in CTranslate2 INT8
│   │   └── benchmark.py             # CLI per benchmark prestazionale locale
│   └── tests/                       # Suite di test automatizzata (44 test)
├── extension/                       # Estensione Manifest V3 Chrome/Edge
│   ├── manifest.json
│   ├── background/service_worker.js # Menu contestuale e storage di sessione in RAM
│   ├── ui/                          # Interfaccia grafica utente (HTML/CSS/JS)
│   └── icons/                       # Asset iconografici
└── windows/                         # Script PowerShell di automazione per Windows
```

---

## 4. Linee Guida di Contribuzione

- **Nessuna Telemetria**: Non aggiungere mai librerie di terze parti che effettuano chiamate di rete esterne.
- **Isolamento dei Log**: Non inserire mai stringhe di testo utente, output tradotti o URL nelle istruzioni `logger.info`, `logger.debug` o `logger.error`.
- **Esecuzione Sandboxed**: Tutte le nuove funzionalità devono poter essere verificate offline con la suite di test.
