# Guida alla Risoluzione dei Problemi: LocalTranslate

Questo documento raccoglie le soluzioni ai problemi più frequenti riscontrabili durante l'installazione o l'utilizzo di **LocalTranslate**.

---

## 1. Messaggio: *"Backend offline. Avvia LocalTranslate sul tuo PC"*

### Causa:
Il servizio Python locale non è in esecuzione o non riesce a comunicare sulla porta `8765`.

### Soluzioni:
1. **Avvia il backend**: Apri PowerShell ed esegui:
   ```powershell
   .\windows\run.ps1
   ```
2. **Verifica il funzionamento**: Apri il browser all'indirizzo [http://127.0.0.1:8765/health](http://127.0.0.1:8765/health). Dovresti vedere una risposta JSON come:
   ```json
   {"status":"ok","version":"1.0.0","model_installed":true,"model_loaded":true,"device":"cpu","compute_type":"int8"}
   ```
3. **Porta occupata da un'altra applicazione**:
   Se la porta `8765` è già occupata, puoi impostare una porta personalizzata avviando con:
   ```powershell
   .\windows\run.ps1 -Port 8890
   ```

---

## 2. Messaggio: *"Modello non installato. Avvia l'installazione del modello locale"*

### Causa:
Il modello NLLB non è stato ancora scaricato o convertito nella cartella `backend/models/nllb-200-distilled-600M-int8/`.

### Soluzione:
Esegui lo script di installazione:
```powershell
.\windows\install.ps1
```
oppure esegui direttamente lo script di conversione:
```powershell
.\.venv\Scripts\python.exe backend\scripts\download_and_convert.py
```
Assicurati di disporre di almeno 1.5 GB di spazio libero su disco e di una connessione Internet attiva durante il setup iniziale.

---

## 3. Il menu contestuale non appare dopo aver selezionato il testo

### Causa:
L'estensione Manifest V3 potrebbe non essere stata inizializzata dal browser o la pagina corrente è una pagina interna del browser (es. `chrome://` o `edge://`), dove le estensioni sono disabilitate per ragioni di sicurezza.

### Soluzioni:
1. Seleziona testo su una normale pagina web (es. `wikipedia.org` o `github.com`).
2. Ricarica l'estensione:
   - Vai su `chrome://extensions` (o `edge://extensions`).
   - Clicca sull'icona di **ricarica** (freccia circolare) nella scheda di LocalTranslate.
3. Se desideri utilizzare LocalTranslate anche in modalità **Navigazione in Incognito / InPrivate**:
   - Clicca su **Dettagli** nella scheda dell'estensione.
   - Attiva l'opzione **"Consenti in modalità di navigazione in incognito"**.

---

## 4. Ho una scheda NVIDIA, ma LocalTranslate usa la CPU

### Causa:
I driver NVIDIA CUDA non sono installati o la versione delle librerie CUDA di sistema non è compatibile con la build di CTranslate2.

### Comportamento di LocalTranslate:
LocalTranslate implementa una strategia di **fallback sicuro**: se l'inizializzazione CUDA genera qualsiasi eccezione (mancanza di cuDNN, driver obsoleti, memoria insufficiente), il backend passa automaticamente alla CPU senza interrompere il servizio e attiva la quantizzazione INT8 ottimizzata con istruzioni AVX/AVX2.

### Come abilitare la GPU:
1. Installa i driver grafici NVIDIA più recenti dal sito ufficiale NVIDIA.
2. Verifica che CUDA sia rilevabile eseguendo:
   ```powershell
   nvidia-smi
   ```
3. Riavvia `run.ps1`: la UI mostrerà ora il badge `CUDA (INT8_FLOAT16)`.

---

## 5. Errore di esecuzione script PowerShell: *"L'esecuzione di script è disattivata nel sistema"*

### Causa:
La policy di sicurezza predefinita di Windows (*ExecutionPolicy*) impedisce l'esecuzione di script non firmati.

### Soluzione:
Abilita l'esecuzione degli script per la finestra PowerShell corrente con il comando:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
Questo comando modifica la policy **solo per la finestra aperta**, senza alterare le impostazioni di sicurezza globali di Windows.

---

## 6. Il Proxy Aziendale Blocca `pip` o il Download del Modello

### Causa:
In reti aziendali con proxy o firewall restrittivi (es. Zscaler, Fortinet, BlueCoat), `pip` e Python possono fallire con `WinError 10061` o errori di certificati SSL (`SSLCertVerificationError`).

### Soluzione A: Usa la modalità Docker (Consigliata)
Non serve installare nulla su Windows né configurare Python o `pip`.
1. Avvia Docker Desktop.
2. Fai doppio clic su:
   ```text
   DOCKER-AVVIA.bat
   ```
3. Se necessario, configura il proxy aziendale dentro Docker Desktop (**Settings** ➔ **Resources** ➔ **Proxies**).

### Soluzione B: Configura il Proxy per `pip` su Windows
Se preferisci usare l'installazione Windows nativa, puoi indicare a `pip` il tuo proxy aziendale aprendo il prompt dei comandi:
```cmd
set HTTP_PROXY=http://utente:password@proxy.azienda.lan:8080
set HTTPS_PROXY=http://utente:password@proxy.azienda.lan:8080
```
Se il proxy ispeziona i certificati SSL aziendali, esegui:
```cmd
pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt
```
oppure installa `pip-system-certs` per fare in modo che Python usi direttamente i certificati fidati di Windows:
```cmd
pip install pip-system-certs
```

