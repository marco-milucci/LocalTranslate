# Guida all'Installazione per Windows 10/11: LocalTranslate

Questa guida illustra la procedura passo-passo per installare, configurare ed eseguire **LocalTranslate** sul tuo personal computer Windows.

---

## Requisiti di Sistema

- **Sistema Operativo**: Windows 10 (versione 1909 o successiva) o Windows 11 (64-bit).
- **Processore**: CPU Intel o AMD x86_64 con supporto AVX (o Snapdragon X Elite / ARM64).
- **Memoria RAM**: Minimo 4 GB (consigliati 8 GB o superiori).
- **Spazio su Disco**: Circa 1.5 GB per l'ambiente Python e i pesi del modello.
- **Scheda Video (Opzionale)**: GPU NVIDIA con driver CUDA 11/12 (se assente, il sistema usa la CPU con INT8).
- **Software Prerequisito**: **Python 3.11 o 3.12+** scaricato da [python.org](https://www.python.org/downloads/).
  > ⚠️ **IMPORTANTE**: Durante l'installazione di Python, assicurati di selezionare la casella **"Add python.exe to PATH"**.

---

## 1. Installazione Guidata del Backend

1. Apri il terminale **PowerShell** (anche senza privilegi di amministratore).
2. Spostati nella cartella in cui hai estratto o clonato LocalTranslate:
   ```powershell
   cd C:\percorso\verso\LocalTranslate
   ```
3. Se l'esecuzione degli script è bloccata dalle policy di sicurezza di Windows, abilitala temporaneamente per la sessione corrente:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```
4. Avvia la procedura di installazione automatica:
   ```powershell
   .\windows\install.ps1
   ```

### Cosa fa lo script di installazione:
- Verifica la presenza di Python 3.11+.
- Crea un ambiente virtuale isolato (`.venv\`).
- Installa le dipendenze richieste (`fastapi`, `ctranslate2`, `transformers`, `sentencepiece`, ecc.).
- Scarica il modello `facebook/nllb-200-distilled-600M` e lo converte nel formato ad alte prestazioni CTranslate2 INT8.
- Verifica l'integrità del modello calcolando i checksum crittografici SHA-256.
- Esegue un self-test hardware per confermare il corretto funzionamento.

---

## 2. Installazione dell'Estensione nel Browser

L'estensione funziona in modo identico sia su **Google Chrome** che su **Microsoft Edge**.

### Per Google Chrome:
1. Apri Chrome e digita nella barra degli indirizzi:
   ```
   chrome://extensions
   ```
2. Attiva la levetta **"Modalità sviluppatore"** (*Developer mode*) in alto a destra.
3. Clicca sul pulsante **"Carica estensione non pacchettizzata"** (*Load unpacked*) in alto a sinistra.
4. Nella finestra di dialogo, seleziona la cartella `extension\` presente all'interno del progetto `LocalTranslate`.
5. Clicca su **"Seleziona cartella"**.

### Per Microsoft Edge:
1. Apri Edge e digita nella barra degli indirizzi:
   ```
   edge://extensions
   ```
2. Nel menu laterale a sinistra, attiva la levetta **"Modalità sviluppatore"** (*Developer mode*).
3. Clicca sul pulsante **"Carica non compresso"** (*Load unpacked*).
4. Seleziona la cartella `extension\` all'interno del progetto `LocalTranslate`.
5. Clicca su **"Seleziona cartella"**.

> 💡 **Consiglio**: Clicca sull'icona del tassello del puzzle nella barra degli strumenti del browser e fissa l'icona di **LocalTranslate** (spilla blu) per avere accesso rapido alla finestra principale di traduzione.

---

## 3. Avvio e Utilizzo Quotidiano (Funziona in Qualsiasi Contesto!)

### Avvio Immediato con 1 Clic:
1. **Fai doppio clic sull'icona `LocalTranslate`** creata automaticamente sul tuo **Desktop** (o nel Menu Start).
2. Il launcher avvia silenziosamente il backend e posiziona l'icona nell'**Area di Notifica di Windows (System Tray)** vicino all'orologio.
3. Appare una notifica: *"LocalTranslate Attivo! Premi Ctrl+Alt+T su qualsiasi testo per tradurlo all'istante."*

### Come tradurre in qualsiasi contesto di Windows:
1. **In qualsiasi applicazione (Word, Adobe PDF, Notepad, Discord, Telegram, Terminale, ecc.)**:
   - Evidenzia il testo che desideri tradurre.
   - Premi la scorciatoia globale:
     ```
     Ctrl + Alt + T
     ```
   - Appare immediatamente vicino al cursore il **Quick HUD fluttuante** con:
     - Testo originale e lingua rilevata
     - Traduzione locale ad alta qualità
     - Badge prestazioni (`CPU INT8` / `CUDA` • millisecondi impiegati)
     - Premi **Invio** o clicca **"Copia Traduzione"** per copiare il testo tradotto negli appunti.
     - Premi **Esc** per chiudere il popup.

2. **Nel Browser (Google Chrome o Microsoft Edge)**:
   - Seleziona una porzione di testo su qualsiasi pagina web.
   - Fai clic destro sul testo selezionato.
   - Seleziona **LocalTranslate** → **Traduci in italiano** (o la lingua desiderata).
   - Si aprirà la finestra con il confronto affiancato e le metriche di throughput.

3. **Icona nella Barra delle Applicazioni (System Tray)**:
   - Clic destro sull'icona di LocalTranslate vicino all'orologio:
     - *Traduci Selezione (`Ctrl+Alt+T`)*
     - *Traduci dagli appunti*
     - *Cambia Profilo (Fast / Quality)*
     - *Stato del Motore Locale (127.0.0.1 Online)*
     - *Esci*

---

## 4. Modalità Portabile e Compilazione Eseguibile

Se desideri distribuire o utilizzare LocalTranslate senza richiedere l'installazione manuale di Python o PowerShell, puoi generare un pacchetto standalone portabile:

```powershell
.\windows\build.ps1
```

Questo comando compila il backend con PyInstaller e genera una cartella standalone in:
```
dist\LocalTranslate-Portable\
```

La cartella conterrà l'eseguibile `LocalTranslateBackend.exe` e il file `Avvia_LocalTranslate.bat` per un avvio con un solo clic.

---

## 5. Disinstallazione

Per rimuovere completamente l'ambiente virtuale e i modelli scaricati dal tuo disco rigido:

```powershell
.\windows\uninstall.ps1
```
