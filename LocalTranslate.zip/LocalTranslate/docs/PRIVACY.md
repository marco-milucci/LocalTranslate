# Politica di Privacy e Threat Model: LocalTranslate

La riservatezza del testo dell'utente è il **requisito fondante e non negoziabile** di LocalTranslate. Questo documento illustra le garanzie architetturali, i vincoli operativi e l'analisi del modello di minaccia (*Threat Model*).

---

## 1. Principi Assoluti di Riservatezza

1. **Ascolto Esclusivo su Loopback**: Il server backend ascolta unicamente su `127.0.0.1`. Non viene mai aperto su `0.0.0.0` o su interfacce di rete esterne.
2. **Zero Connessioni Esterne Durante la Traduzione**: Una volta completata l'installazione del modello locale, l'applicazione opera in modalità completamente disconnessa (compatibile con modalità aereo o reti chiuse *air-gapped*).
3. **Nessuna API Key**: Il funzionamento non richiede né accetta token o credenziali verso fornitori di terze parti.
4. **Nessuna Telemetria o Analytics**: Il codice non contiene alcun tracker, pixel di tracciamento, beacon o libreria di monitoraggio (niente Google Analytics, Mixpanel, Segment, Datadog, ecc.).
5. **Nessun Crash Reporting Remoto**: In caso di errore o crash, il report è limitato ai log della console locale dell'utente. Nessun dump viene inviato a servizi come Sentry o Crashlytics.
6. **Zero Retention del Testo**:
   - Il testo dell'utente e le relative traduzioni **non vengono mai scritti su disco**.
   - I job asincroni conservano i risultati temporaneamente nella memoria RAM del processo per un TTL di 10 minuti, dopodiché vengono distrutti. Non esiste alcun database persistente di testi o documenti.
7. **Filtro Rigoroso sui Log di Sistema**: I file di log e lo standard output non contengono mai il testo sorgente né il testo tradotto. Vengono registrati unicamente metadati prestazionali (tempo in millisecondi, numero di caratteri, numero di chunk, dispositivo impiegato).
8. **Nessun Tracciamento di URL**: L'estensione non registra l'URL completo delle pagine visitate né associa le selezioni testuali ai siti web di provenienza.
9. **Nessun Download di Pagine Web**: Il sistema non supporta e non include funzioni per effettuare il fetch di pagine web remote per tradurle, prevenendo exploit di tipo Server-Side Request Forgery (SSRF).
10. **Connessione Internet Ammessa Solo al Setup**: L'accesso alla rete è consentito unicamente durante l'installazione iniziale (`install.ps1`) se l'utente richiede di scaricare e quantizzare automaticamente i pesi del modello. Una volta scaricati i pesi, il modello è autosufficiente.

---

## 2. Flusso di Trasferimento Dati nel Browser

Nei browser moderni (Chrome e Edge con Manifest V3), il passaggio di dati sensibili tra il context menu e la finestra popup presenta potenziali rischi di fuga se implementato tramite query string nell'URL (es. `popup.html?text=...`). I parametri query verrebbero registrati nella cronologia del browser e negli access log HTTP.

### La soluzione di LocalTranslate:
1. Quando l'utente clicca su una voce del menu contestuale, il service worker intercetta `info.selectionText`.
2. Il testo viene salvato in `chrome.storage.session`, un'area di memoria volatile isolata:
   - Risiede unicamente nella memoria RAM del browser.
   - Non viene mai salvata sul disco rigido o sincronizzata su cloud.
   - Viene cancellata automaticamente alla chiusura della sessione del browser.
3. Il popup viene aperto all'URL statico `ui/popup.html` (**senza alcun parametro query**).
4. All'apertura, lo script `popup.js` estrae il testo da `chrome.storage.session` e **lo cancella immediatamente** tramite `chrome.storage.session.remove("pending_translation")`, azzerando la persistenza del dato.

---

## 3. Threat Model (Modello di Minaccia)

Comprendere i confini di sicurezza è fondamentale per una valutazione del rischio realistica e trasparente:

```
+--------------------------------------------------------------------------+
|                              IL TUO COMPUTER                             |
|                                                                          |
|  [Browser: Chrome/Edge]            [Backend Locale]                      |
|       |                                    ^                             |
|       | HTTP (127.0.0.1:8765)              |                             |
|       +------------------------------------+                             |
|                                                                          |
|  ==================== CONFINE DI SICUREZZA ============================  |
|                                                                          |
|  [RETE INTERNET ESTERNA]                                                 |
|  - Google Cloud        \                                                 |
|  - Microsoft Azure      \                                                |
|  - OpenAI / DeepL        > ZERO PACCHETTI INVIATI O RICEVUTI             |
|  - Servizi di Tracking  /                                                |
|  - Sniffer di Rete     /                                                 |
+--------------------------------------------------------------------------+
```

### Minacce Mitigate con Successo:
- **Sorveglianza e Intercettazione di Rete**: Nessun dato attraversa router, provider di connettività (ISP) o reti pubbliche non protette. Anche un attaccante in grado di monitorare il traffico Wi-Fi non vedrà alcun dato relativo alle traduzioni.
- **Data Mining e Addestramento di Terze Parti**: Grandi provider cloud (Google, Microsoft, DeepL, OpenAI) raccolgono abitualmente i testi inviati alle loro API per addestrare modelli linguistici o migliorare i servizi. Con LocalTranslate, nessun testo lascia il terminale dell'utente.
- **Fughe di Dati nei Data Center Remoti**: L'assenza di server centrali elimina il rischio che una violazione di terzi comprometta i documenti riservati dell'utente.
- **Isolamento da Siti Web Malevoli (CORS)**: Il backend respinge richieste originate da pagine web non autorizzate. Solo l'estensione ufficiale (`chrome-extension://*`) e il localhost sono autorizzati a comunicare con il backend.

### Minacce Fuori dal Confine di Controllo (*Out of Scope*):
- **Malware Preesistente sul PC dell'Utente**: L'ascolto su `127.0.0.1` impedisce che il backend invii dati verso host remoti. Tuttavia, **non può proteggere l'utente da un malware, keylogger, trojan o processo malevolo che sia già in esecuzione con privilegi utente o di amministratore sulla macchina locale**. Qualsiasi software con accesso al sistema operativo locale potrebbe teoricamente intercettare la tastiera, leggere la memoria dei processi o accedere allo schermo.
- **Estensioni del Browser Compromesse**: Estensioni di terze parti installate dall'utente con permessi globali di lettura delle pagine potrebbero accedere al testo selezionato nel browser prima che venga attivato LocalTranslate.

### Raccomandazioni per l'Ambiente di Esecuzione:
- Mantenere attivo Windows Defender o una soluzione antivirus accreditata.
- Applicare regolarmente gli aggiornamenti di sicurezza di Windows 10/11.
- Limitare le estensioni del browser non indispensabili e verificare sempre i permessi richiesti.

---

## 4. Test di Verifica della Privacy Automatizzato

Per garantire che nessun aggiornamento futuro possa introdurre chiamate esterne involontarie, la suite di test include un test di audit dei socket:

- **File**: `backend/tests/test_privacy.py`
- **Meccanismo**: Intercetta a livello di interprete Python le funzioni `socket.socket.connect` e `socket.create_connection`.
- **Comportamento**: Se durante un'operazione di traduzione sincrona o asincrona viene registrato un tentativo di connessione verso qualsiasi indirizzo IP o hostname diverso da `127.0.0.1` o `localhost`, il test fallisce immediatamente con un'eccezione di violazione della privacy (`OutboundConnectionAttemptError`).
