/**
 * LocalTranslate Service Worker (Manifest V3)
 * Handles context menu actions and temporary session storage for zero-retention privacy.
 */

const TARGET_LANG_MAP = {
  "lt_translate_it": "ita_Latn",
  "lt_translate_en": "eng_Latn",
  "lt_translate_fr": "fra_Latn",
  "lt_translate_de": "deu_Latn",
  "lt_translate_custom": null,
};

// Initialize context menu on extension installation or update
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    // Root menu item
    chrome.contextMenus.create({
      id: "lt_root",
      title: "LocalTranslate",
      contexts: ["selection"],
    });

    // Sub-items
    chrome.contextMenus.create({
      parentId: "lt_root",
      id: "lt_translate_it",
      title: "Traduci in italiano",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      parentId: "lt_root",
      id: "lt_translate_en",
      title: "Translate to English",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      parentId: "lt_root",
      id: "lt_translate_fr",
      title: "Traduci in francese",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      parentId: "lt_root",
      id: "lt_translate_de",
      title: "Traduci in tedesco",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      parentId: "lt_root",
      id: "lt_translate_custom",
      title: "Traduci in…",
      contexts: ["selection"],
    });
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!info.selectionText) return;

  const targetLang = TARGET_LANG_MAP[info.menuItemId] !== undefined ? TARGET_LANG_MAP[info.menuItemId] : "ita_Latn";

  // PRIVACY: Store text in temporary in-memory session storage ONLY.
  // NEVER pass user text in query parameters or URL strings!
  const payload = {
    text: info.selectionText,
    targetLanguage: targetLang,
    sourceLanguage: "auto",
    timestamp: Date.now(),
  };

  try {
    if (chrome.storage.session) {
      await chrome.storage.session.set({ pending_translation: payload });
    } else {
      // Fallback for environments where session storage is disabled
      await chrome.storage.local.set({ pending_translation: payload });
    }

    // Open dedicated translation window
    const width = 800;
    const height = 620;
    const left = Math.round((screen.availWidth - width) / 2);
    const top = Math.round((screen.availHeight - height) / 2);

    await chrome.windows.create({
      url: chrome.runtime.getURL("ui/popup.html"),
      type: "popup",
      width: width,
      height: height,
      left: left,
      top: top,
      focused: true,
    });
  } catch (err) {
    console.error("LocalTranslate service worker error:", err);
  }
});
