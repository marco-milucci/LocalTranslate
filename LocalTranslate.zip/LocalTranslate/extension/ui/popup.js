/**
 * LocalTranslate UI Controller
 * Manages communication with 127.0.0.1:8765, zero-retention storage consumption, and UI state.
 */

const API_BASE = "http://127.0.0.1:8765";

// DOM Elements
const sourceTextEl = document.getElementById("sourceText");
const targetTextEl = document.getElementById("targetText");
const sourceLangEl = document.getElementById("sourceLang");
const targetLangEl = document.getElementById("targetLang");
const profileSelectEl = document.getElementById("profileSelect");
const translateBtn = document.getElementById("translateBtn");
const cancelBtn = document.getElementById("cancelBtn");
const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");
const closeBtn = document.getElementById("closeBtn");
const swapLangBtn = document.getElementById("swapLangBtn");
const sourceCharCount = document.getElementById("sourceCharCount");
const targetCharCount = document.getElementById("targetCharCount");

const backendBadge = document.getElementById("backendBadge");
const statusBadge = document.getElementById("statusBadge");
const noticeBox = document.getElementById("noticeBox");

const progressContainer = document.getElementById("progressContainer");
const progressBar = document.getElementById("progressBar");
const progressStatus = document.getElementById("progressStatus");
const progressPercent = document.getElementById("progressPercent");

const metricDuration = document.getElementById("metricDuration");
const metricChunks = document.getElementById("metricChunks");
const metricThroughput = document.getElementById("metricThroughput");
const metricBackend = document.getElementById("metricBackend");
const metricCompute = document.getElementById("metricCompute");

let activeJobId = null;
let pollInterval = null;

// Initialize on load
document.addEventListener("DOMContentLoaded", async () => {
  setupEventListeners();
  await checkBackendStatus();
  await consumePendingTranslation();
});

function setupEventListeners() {
  sourceTextEl.addEventListener("input", () => {
    sourceCharCount.textContent = `${sourceTextEl.value.length} caratteri`;
  });

  translateBtn.addEventListener("click", () => {
    executeTranslation();
  });

  cancelBtn.addEventListener("click", () => {
    cancelActiveJob();
  });

  clearBtn.addEventListener("click", () => {
    sourceTextEl.value = "";
    targetTextEl.value = "";
    sourceCharCount.textContent = "0 caratteri";
    targetCharCount.textContent = "0 caratteri";
    clearNotice();
    resetMetrics();
  });

  copyBtn.addEventListener("click", () => {
    const text = targetTextEl.value;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      const orig = copyBtn.textContent;
      copyBtn.textContent = "Copiato!";
      setTimeout(() => (copyBtn.textContent = orig), 1500);
    });
  });

  closeBtn.addEventListener("click", () => {
    window.close();
  });

  swapLangBtn.addEventListener("click", () => {
    if (sourceLangEl.value !== "auto") {
      const tmp = sourceLangEl.value;
      sourceLangEl.value = targetLangEl.value;
      targetLangEl.value = tmp;
    }
  });
}

function showNotice(message, isWarning = false) {
  noticeBox.textContent = message;
  noticeBox.className = `notice-box ${isWarning ? "warning" : ""}`;
  noticeBox.classList.remove("hidden");
}

function clearNotice() {
  noticeBox.classList.add("hidden");
  noticeBox.textContent = "";
}

function resetMetrics() {
  metricDuration.textContent = "-";
  metricChunks.textContent = "-";
  metricThroughput.textContent = "-";
}

async function checkBackendStatus() {
  try {
    const res = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(2000) });
    if (!res.ok) throw new Error("Status " + res.status);
    const data = await res.json();

    statusBadge.textContent = "Online (Localhost)";
    statusBadge.className = "badge badge-online";

    if (!data.model_installed) {
      showNotice("Modello non installato. Avvia l'installazione locale (install.ps1).", true);
    } else {
      clearNotice();
    }

    // Fetch capabilities
    fetchCapabilities();
  } catch (err) {
    statusBadge.textContent = "Backend Offline";
    statusBadge.className = "badge badge-offline";
    backendBadge.textContent = "Nessun servizio";
    showNotice("Backend offline. Avvia LocalTranslate sul tuo PC (run.ps1).", false);
  }
}

async function fetchCapabilities() {
  try {
    const res = await fetch(`${API_BASE}/v1/capabilities`);
    const data = await res.json();
    const hw = data.hardware;
    const dev = hw.selected_device.toUpperCase();
    const comp = hw.selected_compute_type.toUpperCase();
    backendBadge.textContent = `${dev} (${comp})`;
    metricBackend.textContent = "CTranslate2 (" + dev + ")";
    metricCompute.textContent = comp;
  } catch (e) {
    // Ignore secondary capability failure
  }
}

/**
 * PRIVACY: Consumes pending text from in-memory session storage and immediately purges it.
 */
async function consumePendingTranslation() {
  let pending = null;
  try {
    if (chrome.storage && chrome.storage.session) {
      const res = await chrome.storage.session.get("pending_translation");
      pending = res.pending_translation;
      // Immediately delete to ensure zero-retention!
      await chrome.storage.session.remove("pending_translation");
    } else if (chrome.storage && chrome.storage.local) {
      const res = await chrome.storage.local.get("pending_translation");
      pending = res.pending_translation;
      await chrome.storage.local.remove("pending_translation");
    }
  } catch (e) {
    console.error("Storage read error:", e);
  }

  if (pending && pending.text) {
    sourceTextEl.value = pending.text;
    sourceCharCount.textContent = `${pending.text.length} caratteri`;
    if (pending.targetLanguage) {
      targetLangEl.value = pending.targetLanguage;
    }
    // Auto-execute translation
    executeTranslation();
  }
}

async function executeTranslation() {
  const text = sourceTextEl.value.trim();
  if (!text) return;

  clearNotice();
  setLoadingState(true);

  const sourceLang = sourceLangEl.value;
  const targetLang = targetLangEl.value;
  const profile = profileSelectEl.value;

  // Decide synchronous vs asynchronous based on text size (async if > 4000 characters)
  if (text.length > 4000) {
    await executeAsyncJob(text, sourceLang, targetLang, profile);
  } else {
    await executeSyncTranslation(text, sourceLang, targetLang, profile);
  }
}

async function executeSyncTranslation(text, sourceLang, targetLang, profile) {
  try {
    const res = await fetch(`${API_BASE}/v1/translate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: text,
        source_language: sourceLang,
        target_language: targetLang,
        profile: profile,
      }),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.detail || `Errore HTTP ${res.status}`);
    }

    const data = await res.json();
    targetTextEl.value = data.translation;
    targetCharCount.textContent = `${data.translation.length} caratteri`;

    // Update metrics
    metricDuration.textContent = `${data.duration_ms} ms`;
    metricChunks.textContent = `${data.chunks}`;
    metricThroughput.textContent = `${Math.round(data.throughput_chars_per_sec)} c/s`;
    metricBackend.textContent = `CTranslate2 (${data.device})`;
    metricCompute.textContent = data.compute_type;

    if (data.detected_language && sourceLang === "auto") {
      sourceCharCount.textContent = `${text.length} car. (Rilevato: ${data.detected_language} ${Math.round((data.detection_confidence || 0) * 100)}%)`;
    }
  } catch (err) {
    showNotice(err.message, false);
  } finally {
    setLoadingState(false);
  }
}

async function executeAsyncJob(text, sourceLang, targetLang, profile) {
  try {
    progressContainer.classList.remove("hidden");
    cancelBtn.classList.remove("hidden");
    progressBar.style.width = "0%";
    progressStatus.textContent = "Avvio del job asincrono...";

    const res = await fetch(`${API_BASE}/v1/jobs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: text,
        source_language: sourceLang,
        target_language: targetLang,
        profile: profile,
      }),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.detail || `Errore HTTP ${res.status}`);
    }

    const data = await res.json();
    activeJobId = data.job_id;

    // Start polling job status
    pollInterval = setInterval(async () => {
      await pollJobStatus(activeJobId);
    }, 300);
  } catch (err) {
    showNotice(err.message, false);
    setLoadingState(false);
  }
}

async function pollJobStatus(jobId) {
  try {
    const res = await fetch(`${API_BASE}/v1/jobs/${jobId}`);
    if (!res.ok) throw new Error("Job non trovato");

    const data = await res.json();
    progressBar.style.width = `${data.progress}%`;
    progressPercent.textContent = `${Math.round(data.progress)}%`;
    progressStatus.textContent = `Traduzione in corso: ${data.processed_chunks}/${data.total_chunks} chunk...`;

    if (data.status === "completed") {
      clearInterval(pollInterval);
      targetTextEl.value = data.result || "";
      targetCharCount.textContent = `${(data.result || "").length} caratteri`;
      metricDuration.textContent = `${data.duration_ms} ms`;
      metricChunks.textContent = `${data.total_chunks}`;
      const th = data.duration_ms ? (data.characters / (data.duration_ms / 1000)) : 0;
      metricThroughput.textContent = `${Math.round(th)} c/s`;
      setLoadingState(false);
    } else if (data.status === "failed") {
      clearInterval(pollInterval);
      showNotice(data.error_message || "Traduzione fallita", false);
      setLoadingState(false);
    } else if (data.status === "cancelled") {
      clearInterval(pollInterval);
      showNotice("Traduzione annullata.", true);
      setLoadingState(false);
    }
  } catch (e) {
    clearInterval(pollInterval);
    showNotice("Errore durante il monitoraggio del job: " + e.message, false);
    setLoadingState(false);
  }
}

async function cancelActiveJob() {
  if (!activeJobId) return;
  try {
    await fetch(`${API_BASE}/v1/jobs/${activeJobId}`, { method: "DELETE" });
  } catch (e) {
    console.error("Cancel failed:", e);
  }
}

function setLoadingState(loading) {
  translateBtn.disabled = loading;
  if (!loading) {
    progressContainer.classList.add("hidden");
    cancelBtn.classList.add("hidden");
    activeJobId = null;
    if (pollInterval) clearInterval(pollInterval);
  }
}
