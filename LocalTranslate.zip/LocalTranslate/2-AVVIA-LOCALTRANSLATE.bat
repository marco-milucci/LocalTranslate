@echo off
title LocalTranslate - Avvio Silenzioso
cd /d "%~dp0"

echo Avvio di LocalTranslate in background (Area di Notifica / System Tray)...
start "" wscript.exe "LocalTranslate.vbs"

echo.
echo LocalTranslate e' ora attivo!
echo - L'icona si trova in basso a destra vicino all'orologio di Windows.
echo - Seleziona qualsiasi testo in qualsiasi applicazione e premi Ctrl + Alt + T.
echo.
timeout /t 3 >nul
exit
