# LocalTranslate - Suite di Self-Test Offline e Verifica Privacy

[CmdletBinding()]
param (
    [string]$TestFilter = ""
)

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Error "Ambiente virtuale non trovato! Esegui prima .\windows\install.ps1"
    exit 1
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "         LocalTranslate - Self-Test Offline e Privacy     " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$env:PYTHONPATH = $ProjectRoot

# Esegui pytest
$argsList = @("-m", "pytest", "backend/tests", "-v")
if ($TestFilter) {
    $argsList += @("-k", $TestFilter)
}

& $VenvPython @argsList
$exitCode = $LASTEXITCODE

if ($exitCode -eq 0) {
    Write-Host "`nTUTTI I TEST E LE VERIFICHE DI PRIVACY SONO STATI SUPERATI CON SUCCESSO!`n" -ForegroundColor Green
} else {
    Write-Host "`nALCUNI TEST SONO FALLITI (Codice: $exitCode)`n" -ForegroundColor Red
}

exit $exitCode
