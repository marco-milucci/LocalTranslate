# LocalTranslate - Procedura di Installazione per Windows 10/11
# Privacy Garantita: Questo script scarica il modello locale SOLO durante l'installazione iniziale.

[CmdletBinding()]
param (
    [switch]$SkipModelDownload,
    [string]$PythonPath = "python"
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "         LocalTranslate - Installazione Windows           " -ForegroundColor Cyan
Write-Host "   Traduzione Locale 100% Offline • Zero Dati nel Cloud   " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Verifica Python
Write-Host "`n[1/7] Verifica versione Python..." -ForegroundColor Yellow
if (-not (Get-Command $PythonPath -ErrorAction SilentlyContinue)) {
    if (Get-Command "py" -ErrorAction SilentlyContinue) {
        $PythonPath = "py"
    }
}
try {
    $pythonVersionOutput = & $PythonPath --version 2>&1
    Write-Host "      Trovato: $pythonVersionOutput" -ForegroundColor Green
    
    # Verifica che sia almeno Python 3.11
    $versionMatch = [regex]::Match($pythonVersionOutput, "(\d+)\.(\d+)")
    if ($versionMatch.Success) {
        $major = [int]$versionMatch.Groups[1].Value
        $minor = [int]$versionMatch.Groups[2].Value
        if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 11)) {
            Write-Error "LocalTranslate richiede Python 3.11 o superiore. Versione attuale non supportata."
            exit 1
        }
    }
} catch {
    Write-Error "Python non trovato sul sistema. Installa Python 3.11+ da python.org o dal Microsoft Store e assicurati di spuntare 'Add python.exe to PATH'."
    exit 1
}

# 2. Creazione Virtual Environment
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"

Write-Host "`n[2/7] Configurazione Virtual Environment (.venv)..." -ForegroundColor Yellow
if (-not (Test-Path $VenvPython)) {
    Write-Host "      Creazione ambiente virtuale in $VenvDir..."
    & $PythonPath -m venv $VenvDir
    Write-Host "      Ambiente virtuale creato con successo." -ForegroundColor Green
} else {
    Write-Host "      Ambiente virtuale esistente rilevato." -ForegroundColor Green
}

# 3. Aggiornamento pip e strumenti di installazione
Write-Host "`n[3/7] Aggiornamento strumenti pip..." -ForegroundColor Yellow
& $VenvPython -m pip install --upgrade pip setuptools wheel

# 4. Installazione dipendenze di produzione
Write-Host "`n[4/7] Installazione dipendenze (FastAPI, CTranslate2, Transformers, SentencePiece)..." -ForegroundColor Yellow
$ReqFile = Join-Path $ProjectRoot "requirements.txt"
& $VenvPython -m pip install -r $ReqFile

# 5. Download e Conversione del modello NLLB in CTranslate2 INT8
Write-Host "`n[5/7] Configurazione del Modello Locale (NLLB-200 Distilled 600M INT8)..." -ForegroundColor Yellow
if ($SkipModelDownload) {
    Write-Host "      Download modello saltato (--SkipModelDownload specificato)." -ForegroundColor Cyan
} else {
    $ConverterScript = Join-Path $ProjectRoot "backend\scripts\download_and_convert.py"
    Write-Host "      Esecuzione download e quantizzazione INT8..."
    Write-Host "      (Questa operazione richiede alcuni minuti a seconda della connessione)" -ForegroundColor Gray
    & $VenvPython $ConverterScript
}

# 6. Verifica Integrità del Modello
Write-Host "`n[6/7] Verifica checksum e manifest del modello..." -ForegroundColor Yellow
$VerifyCode = @"
import sys
from pathlib import Path
sys.path.insert(0, r'$ProjectRoot')
from backend.app.engine.model_manager import ModelManager
from backend.app.config import settings

manager = ModelManager(settings.default_model_dir)
status = manager.status()
print(f'Status: Installed={status[\"installed\"]}, ChecksumValid={status[\"checksum_valid\"]}')
if not status[\"installed\"]:
    print('[!] Modello non presente.')
    sys.exit(2)
if not status[\"checksum_valid\"]:
    print('[!] Checksum manifest fallito.')
    sys.exit(3)
print('[OK] Modello verificato con successo.')
"@

$VerifyResult = & $VenvPython -c $VerifyCode
Write-Host "      $VerifyResult"

# 7. Self-test iniziale
Write-Host "`n[7/7] Esecuzione self-test di sistema..." -ForegroundColor Yellow
$SelfTestCode = @"
import sys
sys.path.insert(0, r'$ProjectRoot')
from backend.app.core.hardware import HardwareDetector
hw = HardwareDetector.detect()
print(f'Hardware: CPU={hw.cpu_arch} | Cores={hw.physical_cores} | Threads={hw.logical_threads} | CUDA={hw.cuda_available}')
print(f'Dispositivo selezionato: {hw.selected_device.upper()} ({hw.selected_compute_type})')
"@
& $VenvPython -c $SelfTestCode

# 8. Creazione icona Desktop e Menu Start
Write-Host "`n[8/8] Creazione icona ufficiale sul Desktop e Menu Start..." -ForegroundColor Yellow
$ShortcutScript = Join-Path $PSScriptRoot "create-desktop-shortcut.ps1"
if (Test-Path $ShortcutScript) {
    & powershell.exe -ExecutionPolicy Bypass -File $ShortcutScript
}

Write-Host "`n==========================================================" -ForegroundColor Green
Write-Host "         INSTALLAZIONE COMPLETATA CON SUCCESSO!           " -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "`nAvvio Immediato in Qualsiasi Contesto:"
Write-Host "  👉 Fai doppio clic sull'icona 'LocalTranslate' creata sul tuo Desktop!" -ForegroundColor Cyan
Write-Host "  Oppure avvia da console con: .\windows\run.ps1" -ForegroundColor Gray
Write-Host "`nFunzionamento Globale:"
Write-Host "  1. Seleziona qualsiasi testo in QUALSIASI applicazione (Word, PDF, Notepad, Browser, ecc.)"
Write-Host "  2. Premi la scorciatoia globale: Ctrl + Alt + T" -ForegroundColor Yellow
Write-Host "  3. Apparirà all'istante il Quick HUD fluttuante con la traduzione locale!"
Write-Host "`nPer il menu contestuale con tasto destro in Chrome o Edge:"
Write-Host "  1. Apri chrome://extensions (o edge://extensions)"
Write-Host "  2. Abilita 'Modalità sviluppatore' e clicca 'Carica estensione non pacchettizzata'"
Write-Host "  3. Seleziona la cartella: $ProjectRoot\extension" -ForegroundColor Cyan
Write-Host "`nBuona traduzione privata e offline!`n"
