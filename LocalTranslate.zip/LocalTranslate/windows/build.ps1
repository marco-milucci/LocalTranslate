# LocalTranslate - Script di Build PyInstaller per Windows 10/11
# Genera il pacchetto standalone eseguibile in dist/

[CmdletBinding()]
param (
    [switch]$Clean
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "         LocalTranslate - Build Standalone Windows        " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Error "Ambiente virtuale non trovato! Esegui prima .\windows\install.ps1"
    exit 1
}

# Assicura pyinstaller installato
Write-Host "`n[1/3] Verifica PyInstaller..." -ForegroundColor Yellow
& $VenvPython -m pip install --upgrade pyinstaller

$DistDir = Join-Path $ProjectRoot "dist"
$BuildDir = Join-Path $ProjectRoot "build"
$SpecFile = Join-Path $ProjectRoot "backend\localtranslate.spec"

if ($Clean) {
    Write-Host "Pulizia cartelle dist e build precedenti..." -ForegroundColor Gray
    if (Test-Path $DistDir) { Remove-Item -Recurse -Force $DistDir }
    if (Test-Path $BuildDir) { Remove-Item -Recurse -Force $BuildDir }
}

# Esegui compilazione PyInstaller
Write-Host "`n[2/3] Compilazione backend con PyInstaller..." -ForegroundColor Yellow
Push-Location (Join-Path $ProjectRoot "backend")
try {
    & $VenvPython -m PyInstaller localtranslate.spec --distpath $DistDir --workpath $BuildDir
} finally {
    Pop-Location
}

# Copia l'estensione nella cartella portable di distribuzione
Write-Host "`n[3/3] Impacchettamento cartella Portable..." -ForegroundColor Yellow
$PortableDir = Join-Path $DistDir "LocalTranslate-Portable"
if (-not (Test-Path $PortableDir)) {
    New-Item -ItemType Directory -Path $PortableDir | Out-Null
}

$BackendDist = Join-Path $DistDir "LocalTranslateBackend"
if (Test-Path $BackendDist) {
    Copy-Item -Recurse -Force $BackendDist (Join-Path $PortableDir "backend")
}

$ExtensionSrc = Join-Path $ProjectRoot "extension"
Copy-Item -Recurse -Force $ExtensionSrc (Join-Path $PortableDir "extension")

$LauncherBat = Join-Path $PortableDir "Avvia_LocalTranslate.bat"
@"
@echo off
title LocalTranslate - Backend Locale
echo Avvio di LocalTranslate Backend in 127.0.0.1:8765...
start "" "%~dp0backend\LocalTranslateBackend.exe"
echo Backend avviato. Puoi usare l'estensione Chrome o Microsoft Edge.
pause
"@ | Set-Content -Path $LauncherBat -Encoding ASCII

Write-Host "`n==========================================================" -ForegroundColor Green
Write-Host "         BUILD COMPLETATA CON SUCCESSO!                   " -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "Pacchetto portabile generato in: $PortableDir`n" -ForegroundColor Cyan
