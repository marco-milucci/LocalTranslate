# LocalTranslate - Script di Build PyInstaller per Windows 10/11
# Genera il pacchetto portabile Plug-and-Play distribuibile a tutti i PC senza installare dipendenze

[CmdletBinding()]
param (
    [switch]$Clean,
    [bool]$IncludeModel = $true
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "     LocalTranslate - Creazione Pacchetto Portabile       " -ForegroundColor Cyan
Write-Host "    Zero Dipendenze * Nessun Python Richiesto * No Docker " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

# Usa python del virtualenv o python di sistema
if (Test-Path $VenvPython) {
    $PythonExe = $VenvPython
} else {
    $PythonExe = "python.exe"
}

# 1. Verifica PyInstaller
Write-Host "`n[1/4] Verifica e installazione di PyInstaller..." -ForegroundColor Yellow
& $PythonExe -m pip install --upgrade pyinstaller

$DistDir = Join-Path $ProjectRoot "dist"
$BuildDir = Join-Path $ProjectRoot "build"
$SpecFile = Join-Path $ProjectRoot "backend\localtranslate.spec"

if ($Clean) {
    Write-Host "Pulizia cartelle dist e build precedenti..." -ForegroundColor Gray
    if (Test-Path $DistDir) { Remove-Item -Recurse -Force $DistDir }
    if (Test-Path $BuildDir) { Remove-Item -Recurse -Force $BuildDir }
}

# 2. Compilazione binaria PyInstaller
Write-Host "`n[2/4] Compilazione eseguibile nativo LocalTranslate.exe..." -ForegroundColor Yellow
Push-Location (Join-Path $ProjectRoot "backend")
try {
    & $PythonExe -m PyInstaller localtranslate.spec --distpath $DistDir --workpath $BuildDir
} finally {
    Pop-Location
}

# 3. Composizione cartella Portable
Write-Host "`n[3/4] Assemblaggio cartella Plug-and-Play (LocalTranslate-Portable)..." -ForegroundColor Yellow
$PortableDir = Join-Path $DistDir "LocalTranslate-Portable"
if (Test-Path $PortableDir) { Remove-Item -Recurse -Force $PortableDir }
New-Item -ItemType Directory -Path $PortableDir | Out-Null

# Copia i file compilati di LocalTranslate
$CompiledApp = Join-Path $DistDir "LocalTranslate"
Copy-Item -Recurse -Force "$CompiledApp\*" $PortableDir

# Copia l'estensione browser Chrome/Edge
$ExtensionSrc = Join-Path $ProjectRoot "extension"
Copy-Item -Recurse -Force $ExtensionSrc (Join-Path $PortableDir "extension")

# Copia gli asset e l'icona
$AssetsSrc = Join-Path $ProjectRoot "assets"
if (Test-Path $AssetsSrc) {
    Copy-Item -Recurse -Force $AssetsSrc (Join-Path $PortableDir "assets")
}

# Copia il modello se presente ed è richiesto
if ($IncludeModel) {
    $ModelsSrc = Join-Path $ProjectRoot "backend\models"
    if (Test-Path $ModelsSrc) {
        Write-Host "Copia del modello locale incorporato..." -ForegroundColor Gray
        Copy-Item -Recurse -Force $ModelsSrc (Join-Path $PortableDir "backend\models")
        Copy-Item -Recurse -Force $ModelsSrc (Join-Path $PortableDir "models")
        $InternalBackend = Join-Path $PortableDir "_internal\backend"
        if (Test-Path $InternalBackend) {
            Copy-Item -Recurse -Force $ModelsSrc (Join-Path $InternalBackend "models")
        }
    }
}

# 4. Creazione archivio ZIP finale per la distribuzione
Write-Host "`n[4/4] Creazione archivio ZIP distribuibile..." -ForegroundColor Yellow
$ZipOutput = Join-Path $DistDir "LocalTranslate-Portable-Windows.zip"
if (Test-Path $ZipOutput) { Remove-Item -Force $ZipOutput }

Compress-Archive -Path "$PortableDir\*" -DestinationPath $ZipOutput -CompressionLevel Optimal

Write-Host "`n==========================================================" -ForegroundColor Green
Write-Host "         PACCHETTO PLUG-AND-PLAY CREATO CON SUCCESSO!     " -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "Cartella portabile: $PortableDir" -ForegroundColor Cyan
Write-Host "Archivio ZIP pronto per la distribuzione: $ZipOutput" -ForegroundColor Green
Write-Host "`nCome distribuire agli altri PC:"
Write-Host "  1. Copia 'LocalTranslate-Portable-Windows.zip' su qualsiasi PC Windows."
Write-Host "  2. Estrai lo ZIP."
Write-Host "  3. Fai doppio clic su 'LocalTranslate.exe'."
Write-Host "  -> Funziona all'istante senza installare Python, pip o Docker!`n"
