# LocalTranslate - Creazione Scorciatoia Desktop e Menu Start con Icona Ufficiale

[CmdletBinding()]
param (
    [switch]$IncludeStartMenu = $true
)

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$IconFile = Join-Path $ProjectRoot "assets\LocalTranslate.ico"
$TargetVbs = Join-Path $ProjectRoot "LocalTranslate.vbs"

if (-not (Test-Path $TargetVbs)) {
    Write-Error "File di avvio non trovato in $TargetVbs"
    exit 1
}

$WshShell = New-Object -ComObject WScript.Shell

# 1. Crea collegamento sul Desktop dell'utente
$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$DesktopShortcutPath = Join-Path $DesktopPath "LocalTranslate.lnk"

Write-Host "Creazione icona sul Desktop: $DesktopShortcutPath" -ForegroundColor Cyan
$Shortcut = $WshShell.CreateShortcut($DesktopShortcutPath)
$Shortcut.TargetPath = "wscript.exe"
$Shortcut.Arguments = "`"$TargetVbs`""
$Shortcut.WorkingDirectory = $ProjectRoot
$Shortcut.Description = "LocalTranslate - Traduzione Istantanea Locale 100% Offline (Ctrl+Alt+T)"
if (Test-Path $IconFile) {
    $Shortcut.IconLocation = "$IconFile,0"
}
$Shortcut.Save()
Write-Host "[OK] Icona creata sul Desktop con successo!" -ForegroundColor Green

# 2. Crea collegamento nel Menu Start
if ($IncludeStartMenu) {
    $StartMenuPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Programs)
    $StartMenuShortcutPath = Join-Path $StartMenuPath "LocalTranslate.lnk"
    
    Write-Host "Creazione icona nel Menu Start: $StartMenuShortcutPath" -ForegroundColor Cyan
    $StartShortcut = $WshShell.CreateShortcut($StartMenuShortcutPath)
    $StartShortcut.TargetPath = "wscript.exe"
    $StartShortcut.Arguments = "`"$TargetVbs`""
    $StartShortcut.WorkingDirectory = $ProjectRoot
    $StartShortcut.Description = "LocalTranslate - Traduzione Istantanea Locale 100% Offline"
    if (Test-Path $IconFile) {
        $StartShortcut.IconLocation = "$IconFile,0"
    }
    $StartShortcut.Save()
    Write-Host "[OK] Icona creata nel Menu Start con successo!" -ForegroundColor Green
}
