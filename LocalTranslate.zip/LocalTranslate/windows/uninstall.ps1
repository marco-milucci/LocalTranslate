# LocalTranslate - Procedura di Disinstallazione per Windows 10/11

[CmdletBinding()]
param (
    [switch]$KeepModels,
    [switch]$Force
)

Write-Host "==========================================================" -ForegroundColor Red
Write-Host "         LocalTranslate - Disinstallazione                " -ForegroundColor Red
Write-Host "==========================================================" -ForegroundColor Red

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvDir = Join-Path $ProjectRoot ".venv"
$ModelsDir = Join-Path $ProjectRoot "backend\models"

if (-not $Force) {
    $confirm = Read-Host "Sei sicuro di voler rimuovere l'ambiente virtuale e le dipendenze di LocalTranslate? (s/N)"
    if ($confirm -ne "s" -and $confirm -ne "S") {
        Write-Host "Disinstallazione annullata." -ForegroundColor Yellow
        exit 0
    }
}

# 1. Termina eventuali processi backend attivi
Write-Host "`n[1/3] Chiusura processi attivi di LocalTranslate..." -ForegroundColor Yellow
try {
    Get-Process -Name "python", "pythonw" -ErrorAction SilentlyContinue | Where-Object {
        $_.Path -like "*LocalTranslate*"
    } | Stop-Process -Force -ErrorAction SilentlyContinue
} catch {}

# 2. Rimozione ambiente virtuale .venv
Write-Host "`n[2/3] Rimozione virtual environment (.venv)..." -ForegroundColor Yellow
if (Test-Path $VenvDir) {
    Remove-Item -Recurse -Force $VenvDir
    Write-Host "      .venv rimosso con successo." -ForegroundColor Green
} else {
    Write-Host "      .venv non presente." -ForegroundColor Gray
}

# 3. Rimozione modelli (se non specificato -KeepModels)
Write-Host "`n[3/3] Gestione modelli scaricati..." -ForegroundColor Yellow
if ($KeepModels) {
    Write-Host "      Modelli conservati in $ModelsDir come richiesto." -ForegroundColor Cyan
} else {
    if (Test-Path $ModelsDir) {
        Remove-Item -Recurse -Force $ModelsDir
        Write-Host "      Cartella modelli rimossa con successo." -ForegroundColor Green
    }
}

Write-Host "`nLocalTranslate è stato disinstallato con successo." -ForegroundColor Green
Write-Host "Nota: Se avevi caricato l'estensione nel browser, puoi rimuoverla da chrome://extensions.`n"
