# LocalTranslate - Avvio del Backend Locale su Windows 10/11
# Ascolta tassativamente su 127.0.0.1:8765

[CmdletBinding()]
param (
    [int]$Port = 8765,
    [switch]$Background
)

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Error "Ambiente virtuale non trovato! Esegui prima .\windows\install.ps1"
    exit 1
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "         LocalTranslate - Avvio Backend Locale            " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "In ascolto esclusivamente su: 127.0.0.1:$Port" -ForegroundColor Green
Write-Host "Zero chiamate di rete esterne • Privacy totale`n" -ForegroundColor Green

$env:PYTHONPATH = $ProjectRoot
$env:LOCALTRANSLATE_PORT = "$Port"

if ($Background) {
    Write-Host "Avvio in background..." -ForegroundColor Yellow
    Start-Process -FilePath $VenvPython -ArgumentList "-m", "backend.app.main" -WindowStyle Hidden
} else {
    Write-Host "Avvio in console (premi Ctrl+C per arrestare)..." -ForegroundColor Yellow
    & $VenvPython -m backend.app.main
}
