# LocalTranslate 🌐🔒

> **Utility professionale di traduzione locale per Windows 10/11.**  
> Traduzione istantanea nel browser (Chrome ed Edge) con **privacy assoluta**, esecuzione **100% offline** su hardware locale e **zero dati inviati al cloud**.

---

## 📋 Panoramica

**LocalTranslate** funziona **in qualsiasi contesto di Windows**:

1. **In qualsiasi applicazione (Word, PDF, Notepad, Discord, Terminale, ecc.)**:
   - Fai doppio clic sull'icona **LocalTranslate** sul Desktop per avviare il servizio.
   - Seleziona qualsiasi testo ovunque e premi:
     ```
     Ctrl + Alt + T
     ```
   - Appare all'istante il **Quick Translation HUD fluttuante** con la traduzione locale, metadati hardware e copia con 1 clic!

2. **Nel Browser (Google Chrome e Microsoft Edge)**:
   - Seleziona testo in qualsiasi pagina web:
     ```
     Tasto destro sul testo selezionato → LocalTranslate → Traduci in italiano
     ```

Tutto il processo di inferenza avviene **esclusivamente sul tuo computer**, senza che il testo venga mai trasmesso a Google, Microsoft, OpenAI, DeepL o qualsiasi altro server remoto.

---

## ⚡ Caratteristiche Principali

- **Avvio Immediato con 1 Clic**: Icona desktop con grafica ufficiale (`LocalTranslate.ico`) e avvio silenzioso in background (`LocalTranslate.vbs`) senza fastidiose finestre di terminale.
- **Funziona in Qualsiasi Contesto**: Scorciatoia globale di sistema `Ctrl+Alt+T` per tradurre testi in qualsiasi applicazione Windows con Quick HUD fluttuante moderno.
- **System Tray Icon**: Posizionata nell'area di notifica di Windows (vicino all'orologio) con menu rapido, cambio profilo in tempo reale (Fast/Quality) e stato del motore.
- **Privacy Radicale**: Binding esclusivo su `127.0.0.1`. Nessuna richiesta Internet durante la traduzione, nessuna API key, nessuna telemetria, nessun tracciamento o analytics.
- **Zero Retention**: Il testo selezionato non viene mai salvato su disco né inviato tramite query string URL. I log di sistema contengono esclusivamente metriche tecniche (tempo, chunk, throughput).
- **Auto-rilevamento Hardware**:
  - Rileva automaticamente CPU (Intel, AMD, ARM64), numero di core fisici, thread logici e RAM.
  - Sfrutta automaticamente GPU NVIDIA (CUDA) se disponibile.
  - Su CPU senza GPU attiva l'accelerazione INT8 avanzata via CTranslate2 con ottimizzazione thread per prevenire l'oversubscription.
- **Motore di Inferenza CTranslate2 INT8**:
  - Modello base universale: `facebook/nllb-200-distilled-600M` convertito in CTranslate2 INT8.
  - Modello residente in memoria: caricato una sola volta all'avvio per latenze minime (~30-80ms per frase su CPU moderna).
  - Cache LRU in memoria per frasi duplicate nella stessa sessione.
- **Chunking Intelligente**:
  - Preserva struttura di paragrafi (`\n\n`), righe vuote e spaziature.
  - Protegge da suddivisioni arbitrarie: URL, email, numeri decimali, codice sorgente e abbreviazioni comuni.
- **Profili di Traduzione**:
  - **Fast**: Massima velocità, batch aggressivo, beam search ridotta (throughput prioritario).
  - **Quality**: Massima accuratezza del modello, beam search estesa.
- **Rilevamento Lingua 100% Locale**: Rilevatore statistico offline con calcolo di confidenza. Se il testo è ambiguo o breve, non inventa la lingua e solicita la selezione manuale.
- **Supporto Testi Massivi**: Job asincroni con UUID casuale, aggiornamento del progresso in tempo reale (0-100%), possibilità di cancellazione e TTL automatico in RAM.
- **Estensione Manifest V3**: Piena compatibilità con Google Chrome e Microsoft Edge, interfaccia grafica moderna con badge hardware e throughput in tempo reale.

---

## 🏛️ Architettura del Sistema

```
  +-----------------------------------------------------------+
  |                   Google Chrome / MS Edge                 |
  |  [Selezione Testo] -> Tasto Destro -> LocalTranslate     |
  |  Service Worker MV3 -> chrome.storage.session (RAM pura)  |
  +-----------------------------+-----------------------------+
                                | HTTP POST (127.0.0.1:8765)
                                v
  +-----------------------------------------------------------+
  |              Backend Locale (FastAPI + Uvicorn)           |
  |                                                           |
  |  +-------------------+        +------------------------+  |
  |  | Security & Filter |        |   Intelligent Chunker  |  |
  |  +---------+---------+        +-----------+------------+  |
  |            |                              |               |
  |            v                              v               |
  |  +-------------------+        +------------------------+  |
  |  | Language Detector |        |   Batch & Job Manager  |  |
  |  +-------------------+        +-----------+------------+  |
  |                                           |               |
  |                                           v               |
  |                       +--------------------------------+  |
  |                       |  CTranslate2 Resident Engine   |  |
  |                       |  (NLLB-200 INT8 / CUDA / CPU)  |  |
  |                       +--------------------------------+  |
  +-----------------------------------------------------------+
```

---

## 🚀 Guida Rapida all'Installazione su Windows 10/11

### Prerequisiti
1. **Windows 10 o Windows 11** (64-bit).
2. **Python 3.11 o 3.12+** installato sul sistema (con l'opzione *"Add python.exe to PATH"* spuntata).

### 1. Installazione con PowerShell
Apri PowerShell nella cartella del progetto ed esegui lo script di setup guidato:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\windows\install.ps1
```

Lo script automatizza:
- Controllo dell'ambiente Python.
- Creazione del virtual environment `.venv`.
- Installazione di tutte le librerie necessarie (`fastapi`, `ctranslate2`, `transformers`, `sentencepiece`, ecc.).
- Download del modello NLLB e conversione in formato CTranslate2 INT8.
- Verifica crittografica (SHA-256) del manifest del modello.
- Esecuzione del self-test hardware e funzionale.

### 2. Avvio del Backend Locale
Per avviare il servizio:

```powershell
.\windows\run.ps1
```

Il backend ascolta esclusivamente su `http://127.0.0.1:8765`.

### 🐳 Alternativa con Docker (Ideale per reti aziendali o proxy restrittivi)
Se il tuo proxy blocca `pip` su Windows o preferisci non installare Python:
1. Avvia Docker Desktop.
2. Fai doppio clic su `DOCKER-AVVIA.bat` (oppure esegui `docker compose up -d`).
3. Per i dettagli, consulta la [Guida Docker](docs/DOCKER.md).

### 3. Installazione dell'Estensione nel Browser
1. Apri **Chrome** (visita `chrome://extensions`) o **Edge** (visita `edge://extensions`).
2. Attiva l'interruttore **Modalità sviluppatore** (Developer mode) in alto a destra.
3. Clicca su **Carica estensione non pacchettizzata** (Load unpacked).
4. Seleziona la cartella `extension\` all'interno di questo repository.
5. Fatto! L'icona di LocalTranslate apparirà nella barra degli strumenti e il menu contestuale sarà subito attivo.

---

## 🧪 Esecuzione dei Test e Verifica Privacy

Il repository include una suite di test completa con verifica dell'isolamento di rete:

```powershell
.\windows\offline-self-test.ps1
```

Oppure via pytest:
```bash
pytest backend/tests -v
```

Il test di privacy (`test_privacy.py`) intercetta le socket di rete a livello di sistema operativo per certificare che **zero connessioni esterne** vengano tentate durante la traduzione.

---

## 📚 Documentazione Completa

Consulta i documenti dedicati nella cartella `docs/`:

- [ARCHITECTURE.md](docs/ARCHITECTURE.md) - Architettura interna, design pattern e pipeline di inferenza.
- [PRIVACY.md](docs/PRIVACY.md) - Threat model, confini di sicurezza e conformità privacy.
- [MODEL.md](docs/MODEL.md) - Dettagli su NLLB-200, quantizzazione INT8, licenza e sostituzione modelli.
- [INSTALL_WINDOWS.md](docs/INSTALL_WINDOWS.md) - Guida dettagliata all'installazione su Windows.
- [DEVELOPMENT.md](docs/DEVELOPMENT.md) - Guida per sviluppatori, estensione API e nuovi provider.
- [BENCHMARK.md](docs/BENCHMARK.md) - Istruzioni di benchmark e misurazione del throughput locale.
- [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - Risoluzione problemi frequenti.

---

## ⚖️ Licenza

Questo software è rilasciato sotto licenza MIT.  
I pesi del modello NLLB-200 appartengono a Meta AI e sono regolati dalla licenza `CC-BY-NC 4.0`. Consulta [MODEL.md](docs/MODEL.md) per i dettagli.
