@echo off
title LocalTranslate - Installazione Automatica Windows
color 0B
cd /d "%~dp0"

echo ================================================================
echo            LocalTranslate - Installazione Automatica
echo          100%% Offline Traduzione Locale - Zero Cloud
echo ================================================================
echo.
echo Avvio della procedura di configurazione guidata...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "windows\install.ps1"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ================================================================
    echo [SUCCESSO] Installazione completata!
    echo L'icona "LocalTranslate" e' stata creata sul tuo Desktop.
    echo.
    echo Puoi avviare LocalTranslate facendo doppio clic sull'icona 
    echo creata sul Desktop oppure facendo doppio clic su:
    echo "2-AVVIA-LOCALTRANSLATE.bat"
    echo ================================================================
) else (
    echo.
    echo [ERRORE] Si e' verificato un problema durante l'installazione.
    echo Assicurati di avere Python 3.11+ installato e connessione Internet attiva.
)

echo.
pause
