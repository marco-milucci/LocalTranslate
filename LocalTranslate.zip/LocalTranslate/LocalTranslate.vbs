' LocalTranslate - Avvio Silenzioso per Windows (Nessuna finestra di comando)
Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

strScriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)
strVenvPythonw = strScriptDir & "\.venv\Scripts\pythonw.exe"
strSysPythonw = "pythonw.exe"

' Controlla se esiste il virtualenv, altrimenti prova pythonw di sistema
If FSO.FileExists(strVenvPythonw) Then
    strExe = strVenvPythonw
Else
    strExe = strSysPythonw
End If

' Avvia il desktop launcher con finestra completamente nascosta (0)
strCommand = """" & strExe & """ -m backend.app.desktop.app_launcher"
WshShell.CurrentDirectory = strScriptDir
WshShell.Run strCommand, 0, False
