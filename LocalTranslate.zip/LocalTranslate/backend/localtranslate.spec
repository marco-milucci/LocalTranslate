# -*- mode: python ; coding: utf-8 -*-
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Collect CTranslate2, SentencePiece, and Transformers metadata
ctranslate2_datas = collect_data_files('ctranslate2')
transformers_datas = collect_data_files('transformers')

ico_file = Path('../assets/LocalTranslate.ico')
if not ico_file.exists():
    ico_file = Path('assets/LocalTranslate.ico')
assets_datas = [(str(ico_file), 'assets')] if ico_file.exists() else []

a = Analysis(
    ['app/desktop/app_launcher.py'],
    pathex=['.', '..'],
    binaries=[],
    datas=ctranslate2_datas + transformers_datas + assets_datas,
    hiddenimports=[
        'uvicorn.logging',
        'uvicorn.loops',
        'uvicorn.loops.auto',
        'uvicorn.protocols',
        'uvicorn.protocols.http',
        'uvicorn.protocols.http.auto',
        'uvicorn.protocols.websockets',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.lifespans',
        'uvicorn.lifespans.on',
        'ctranslate2',
        'sentencepiece',
        'psutil',
        'pystray',
        'pystray._win32',
        'PIL',
        'PIL.Image',
        'tkinter',
        'backend.app.main',
        'backend.app.config',
        'backend.app.api.routes_health',
        'backend.app.api.routes_capabilities',
        'backend.app.api.routes_translate',
        'backend.app.api.routes_jobs',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['torch', 'torchvision', 'torchaudio', 'scipy', 'matplotlib'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LocalTranslate',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=str(ico_file) if ico_file.exists() else None,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='LocalTranslate',
)
