"""Download and convert NLLB-200 model to CTranslate2 INT8 format."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# Add project root to sys.path
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.config import settings
from backend.app.engine.model_manager import ModelManager


def calculate_sha256(filepath: Path) -> str:
    sha = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(1024 * 1024):
            sha.update(chunk)
    return sha.hexdigest()


def download_and_convert(
    model_id: str = "facebook/nllb-200-distilled-600M",
    output_dir: Path | None = None,
    quantization: str = "int8",
    force: bool = False,
) -> Path:
    out = output_dir or settings.default_model_dir
    out = Path(out)

    if out.exists() and not force:
        manager = ModelManager(out)
        if manager.verify():
            print(f"[LocalTranslate] Modello già presente e verificato in: {out}")
            return out
        else:
            print("[LocalTranslate] Modello esistente ma incompleto/non verificato. Riconversione...")

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp_out = out.parent / f"{out.name}_tmp"
    if tmp_out.exists():
        shutil.rmtree(tmp_out)

    print(f"[LocalTranslate] Avvio download e conversione di {model_id} in formato CTranslate2 ({quantization})...")
    print("Nota: Questa operazione richiede connessione Internet e avviene ESCLUSIVAMENTE durante l'installazione.")

    # Call ct2-transformers-converter
    cmd = [
        sys.executable,
        "-m",
        "ctranslate2.converters.transformers",
        "--model",
        model_id,
        "--output_dir",
        str(tmp_out),
        "--quantization",
        quantization,
        "--copy_files",
        "tokenizer.json",
        "sentencepiece.bpe.model",
        "special_tokens_map.json",
        "tokenizer_config.json",
    ]

    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"[LocalTranslate] ERRORE durante la conversione con CTranslate2: {e}", file=sys.stderr)
        try:
            import torch
            print(f"[LocalTranslate] PyTorch rilevato: {torch.__version__}")
        except ImportError:
            print("[LocalTranslate] ERRORE CRITICO: PyTorch (torch) non e' installato nel runtime Python!", file=sys.stderr)
            print("[LocalTranslate] CTranslate2 richiede PyTorch durante la conversione. Esegui: pip install torch", file=sys.stderr)
        if tmp_out.exists():
            shutil.rmtree(tmp_out)
        sys.exit(1)

    # Move tmp to target
    if out.exists():
        shutil.rmtree(out)
    shutil.move(str(tmp_out), str(out))

    # Generate manifest.json
    print("[LocalTranslate] Generazione manifest e calcolo checksum SHA-256...")
    files_info = {}
    for item in out.iterdir():
        if item.is_file() and item.name != "manifest.json":
            files_info[item.name] = {
                "sha256": calculate_sha256(item),
                "size_bytes": item.stat().st_size,
            }

    manifest = {
        "model_id": model_id,
        "version": "1.0.0",
        "quantization": quantization,
        "framework": "ctranslate2",
        "files": files_info,
    }

    with open(out / "manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    print(f"[LocalTranslate] Installazione completata con successo! Percorso: {out}")
    return out


def main():
    parser = argparse.ArgumentParser(description="Scarica e converte il modello NLLB per LocalTranslate")
    parser.add_argument("--model-id", default="facebook/nllb-200-distilled-600M", help="ID HuggingFace del modello")
    parser.add_argument("--output-dir", default=str(settings.default_model_dir), help="Cartella di destinazione")
    parser.add_argument("--quantization", default="int8", help="Tipo di quantizzazione (int8, float16, float32)")
    parser.add_argument("--force", action="store_true", help="Forza la riconversione anche se già presente")
    args = parser.parse_args()

    download_and_convert(
        model_id=args.model_id,
        output_dir=Path(args.output_dir),
        quantization=args.quantization,
        force=args.force,
    )


if __name__ == "__main__":
    main()
