"""Local performance benchmark measuring latency, throughput, memory, and hardware."""

import argparse
import sys
import time
from pathlib import Path
import psutil

# Add project root to sys.path
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.config import settings
from backend.app.core.chunker import IntelligentChunker
from backend.app.core.hardware import HardwareDetector
from backend.app.core.profiles import get_profile
from backend.app.engine.batch_manager import BatchManager
from backend.app.engine.ctranslate2_engine import CTranslate2TranslationEngine
from backend.app.engine.model_manager import ModelManager


# Benchmark test texts
SHORT_TEXT = "Hello world! This is a fast privacy test."

MEDIUM_TEXT = (
    "LocalTranslate is a professional Windows translation utility. "
    "It operates entirely on local hardware without sending any data over the Internet. "
    "All translations are processed locally using CTranslate2 INT8 quantization. "
    "It protects your privacy and works completely offline."
)

LARGE_TEXT = (
    ("Artificial intelligence has revolutionized natural language processing over the past decade. "
     "Early statistical machine translation systems relied on phrase-based models and complex bilingual dictionaries. "
     "With the advent of deep learning and the transformer architecture, neural machine translation achieved human-level fluency across multiple domains.\n\n"
     "However, traditional translation services require uploading sensitive user data to cloud servers. "
     "This poses severe privacy risks for enterprises, healthcare providers, legal professionals, and individual users.\n\n"
     "LocalTranslate solves this critical challenge by executing translation models directly on the client workstation. "
     "By utilizing INT8 quantization and hardware-accelerated kernels, it achieves high throughput without requiring expensive server clusters.") * 5
)

BATCH_TEXTS = [
    f"Sentence number {i}: The quick brown fox jumps over the lazy dog and tests local throughput."
    for i in range(1, 33)
]


def run_benchmark(model_dir: Path | None = None, profile_name: str = "fast"):
    hardware = HardwareDetector.detect()
    print("=" * 70)
    print("           LOCALTRANSLATE PERFORMANCE BENCHMARK")
    print("=" * 70)
    print(f"CPU Arch:         {hardware.cpu_arch}")
    print(f"Physical Cores:   {hardware.physical_cores}")
    print(f"Logical Threads:  {hardware.logical_threads}")
    print(f"RAM Total:        {hardware.total_ram_gb:.1f} GB (Available: {hardware.available_ram_gb:.1f} GB)")
    print(f"CUDA Available:   {hardware.cuda_available} ({hardware.cuda_device_name or 'N/A'})")
    print(f"Selected Device:  {hardware.selected_device}")
    print(f"Compute Type:     {hardware.selected_compute_type}")
    print(f"Profile:          {profile_name.upper()}")
    print("=" * 70)

    target_dir = model_dir or settings.default_model_dir
    engine = CTranslate2TranslationEngine(hardware=hardware)
    manager = ModelManager(model_dir=target_dir, engine=engine)

    if not manager.provider.is_available():
        print(f"[!] Errore: {manager.MISSING_MODEL_MESSAGE}")
        print("    Esegui prima: python backend/scripts/download_and_convert.py")
        sys.exit(1)

    # Measure RAM before loading
    process = psutil.Process()
    ram_before_mb = process.memory_info().rss / (1024 * 1024)

    print("\n[+] Caricamento modello residente in memoria...")
    t0 = time.perf_counter()
    manager.load()
    load_time_sec = time.perf_counter() - t0
    ram_after_mb = process.memory_info().rss / (1024 * 1024)
    model_ram_mb = ram_after_mb - ram_before_mb

    print(f"    Tempo caricamento: {load_time_sec:.2f} s")
    print(f"    RAM occupata modello: {model_ram_mb:.1f} MB (Totale processo: {ram_after_mb:.1f} MB)")

    batch_mgr = BatchManager(engine=engine)
    profile = get_profile(profile_name)

    scenarios = [
        ("1. TESTO BREVE", SHORT_TEXT),
        ("2. TESTO MEDIO", MEDIUM_TEXT),
        ("3. TESTO GRANDE (Documento multiriga)", LARGE_TEXT),
    ]

    print("\n" + "-" * 70)
    print(f"{'Scenario':<35} | {'Latenza (ms)':<12} | {'Caratteri':<10} | {'Throughput (c/s)':<16}")
    print("-" * 70)

    for name, sample_text in scenarios:
        chunks = IntelligentChunker.chunk_text(sample_text)
        # Warmup single
        if name == scenarios[0][0]:
            batch_mgr.translate_chunks(chunks, "eng_Latn", "ita_Latn", profile)

        t_start = time.perf_counter()
        result = batch_mgr.translate_chunks(chunks, "eng_Latn", "ita_Latn", profile)
        elapsed_ms = (time.perf_counter() - t_start) * 1000.0
        chars = len(sample_text)
        throughput_cps = (chars / (elapsed_ms / 1000.0)) if elapsed_ms > 0 else 0

        print(f"{name:<35} | {elapsed_ms:<12.1f} | {chars:<10} | {throughput_cps:<16.1f}")

    # 4. Batch Benchmark
    print("-" * 70)
    print("\n[+] Esecuzione benchmark BATCH (32 frasi simultanee)...")
    t_start = time.perf_counter()
    batch_results = engine.translate_batch(
        texts=BATCH_TEXTS,
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
    )
    batch_elapsed_ms = (time.perf_counter() - t_start) * 1000.0
    total_batch_chars = sum(len(t) for t in BATCH_TEXTS)
    batch_throughput = (total_batch_chars / (batch_elapsed_ms / 1000.0)) if batch_elapsed_ms > 0 else 0
    approx_tokens = total_batch_chars / 4.0
    tokens_per_sec = (approx_tokens / (batch_elapsed_ms / 1000.0)) if batch_elapsed_ms > 0 else 0

    print(f"    Tempo totale batch:    {batch_elapsed_ms:.1f} ms")
    print(f"    Caratteri totali:      {total_batch_chars}")
    print(f"    Throughput caratteri:  {batch_throughput:.1f} chars/sec")
    print(f"    Throughput stimato:    ~{tokens_per_sec:.1f} tokens/sec")
    print("=" * 70)
    print("Benchmark completato.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Benchmark locale per LocalTranslate")
    parser.add_argument("--profile", default="fast", choices=["fast", "quality"], help="Profilo di traduzione")
    parser.add_argument("--model-dir", default=None, help="Directory del modello")
    args = parser.parse_args()

    run_benchmark(model_dir=Path(args.model_dir) if args.model_dir else None, profile_name=args.profile)
