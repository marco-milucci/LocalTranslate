"""Tests for hardware auto-detection and execution parameters."""

from backend.app.core.hardware import HardwareDetector, HardwareProfile


def test_hardware_detection_basic():
    hw = HardwareDetector.detect()
    assert isinstance(hw, HardwareProfile)
    assert hw.physical_cores >= 1
    assert hw.logical_threads >= hw.physical_cores
    assert hw.total_ram_gb > 0
    assert hw.selected_device in ("cpu", "cuda")
    assert hw.selected_compute_type != ""
    assert len(hw.supported_compute_types) > 0


def test_thread_allocation_no_oversubscription():
    hw = HardwareDetector.detect()
    if hw.selected_device == "cpu":
        # Ensure total compute threads does not exceed physical cores (oversubscription prevention)
        total_threads = hw.inter_threads * hw.intra_threads
        assert total_threads <= max(hw.physical_cores, 1)
        assert hw.inter_threads >= 1
        assert hw.intra_threads >= 1


def test_hardware_profile_serialization():
    hw = HardwareDetector.detect()
    d = hw.to_dict()
    assert "cpu_arch" in d
    assert "physical_cores" in d
    assert "logical_threads" in d
    assert "selected_device" in d
    assert "selected_compute_type" in d
    assert "supported_compute_types" in d
    assert isinstance(d["supported_compute_types"], list)
