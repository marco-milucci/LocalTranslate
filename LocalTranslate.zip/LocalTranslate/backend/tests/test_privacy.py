"""Strict privacy verification tests: audit network sockets and ensure zero outbound traffic."""

import socket
from pathlib import Path
import pytest
from backend.app.config import settings


class OutboundConnectionAttemptError(RuntimeError):
    """Raised when an attempt to connect outside localhost is detected."""
    pass


def test_strict_localhost_binding():
    """Verify backend host configuration is strictly 127.0.0.1."""
    assert settings.host == "127.0.0.1", "Backend MUST bind strictly to 127.0.0.1"
    assert settings.host != "0.0.0.0", "Binding to 0.0.0.0 violates privacy principles"


def test_zero_outbound_network_calls_during_translation(client, monkeypatch):
    """Network audit: intercept all socket connections during translation and fail on any external target."""
    original_connect = socket.socket.connect

    def guarded_connect(sock, address):
        host = address[0] if isinstance(address, tuple) and len(address) > 0 else str(address)
        # Allowed local destinations
        if host in ("127.0.0.1", "localhost", "::1", "testserver"):
            return original_connect(sock, address)
        raise OutboundConnectionAttemptError(
            f"PRIVACY VIOLATION: LocalTranslate attempted an external network connection to: {host}"
        )

    monkeypatch.setattr(socket.socket, "connect", guarded_connect)

    # Perform synchronous translation
    res = client.post(
        "/v1/translate",
        json={
            "text": "Highly confidential enterprise data that must never leave the workstation.",
            "source_language": "eng_Latn",
            "target_language": "ita_Latn",
            "profile": "fast",
        },
    )
    assert res.status_code == 200

    # Perform batch translation
    res_batch = client.post(
        "/v1/translate/batch",
        json={
            "texts": [
                "Sensitive medical record patient notes.",
                "Confidential intellectual property patent draft.",
            ],
            "source_language": "eng_Latn",
            "target_language": "ita_Latn",
        },
    )
    assert res_batch.status_code == 200


def test_no_telemetry_or_remote_endpoints_in_codebase():
    """Inspect codebase for forbidden external service URLs or telemetry endpoints."""
    forbidden = [
        "google-analytics.com",
        "telemetry",
        "sentry.io",
        "segment.io",
        "mixpanel.com",
        "api.openai.com",
        "api.deepl.com",
        "datadoghq.com",
    ]

    import backend
    app_path = Path(backend.__file__).parent / "app"

    for py_file in app_path.rglob("*.py"):
        content = py_file.read_text(encoding="utf-8", errors="ignore").lower()
        for forbidden_term in forbidden:
            assert forbidden_term not in content, (
                f"Forbidden remote service/telemetry term '{forbidden_term}' found in {py_file}"
            )
