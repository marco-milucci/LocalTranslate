"""Tests validating Manifest V3 extension structure and privacy properties."""

import json
from pathlib import Path


def test_extension_manifest_v3_structure():
    project_root = Path(__file__).resolve().parent.parent.parent
    manifest_path = project_root / "extension" / "manifest.json"
    assert manifest_path.exists(), "extension/manifest.json must exist"

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    assert manifest.get("manifest_version") == 3
    assert "contextMenus" in manifest.get("permissions", [])
    assert "storage" in manifest.get("permissions", [])

    host_perms = manifest.get("host_permissions", [])
    assert any("127.0.0.1" in p for p in host_perms), "Must have host_permission for 127.0.0.1"

    # Verify background worker file exists
    sw_rel = manifest["background"]["service_worker"]
    sw_path = project_root / "extension" / sw_rel
    assert sw_path.exists()

    # Verify popup file exists
    popup_rel = manifest["action"]["default_popup"]
    popup_path = project_root / "extension" / popup_rel
    assert popup_path.exists()

    # Verify icons exist
    icons_dict = manifest.get("icons", {})
    for size, icon_rel in icons_dict.items():
        icon_path = project_root / "extension" / icon_rel
        assert icon_path.exists(), f"Icon {size} must exist at {icon_path}"


def test_service_worker_no_url_query_parameters():
    """Verify service worker never passes sensitive text in URL query strings."""
    project_root = Path(__file__).resolve().parent.parent.parent
    sw_path = project_root / "extension" / "background" / "service_worker.js"
    content = sw_path.read_text(encoding="utf-8")

    # Should use storage.session or storage.local
    assert "chrome.storage.session" in content or "chrome.storage.local" in content
    # Should NOT append ?text= or query params to popup URL
    assert "?text=" not in content
    assert "?q=" not in content
    assert "?selection=" not in content

    # Should register selection context menu
    assert '"selection"' in content
    assert "Traduci in italiano" in content
    assert "Translate to English" in content
    assert "Traduci in francese" in content
    assert "Traduci in tedesco" in content
    assert "Traduci in…" in content
