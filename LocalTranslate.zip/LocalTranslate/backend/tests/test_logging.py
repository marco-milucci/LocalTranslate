"""Tests verifying that user text or translations are never written to logs."""

import logging
from backend.app.core.logging_filter import log_job_metric, log_translation_metric, logger


def test_zero_user_text_in_translation_logs(client, caplog):
    """Verify that during a translation, sensitive user text never appears in logs."""
    canary_text = "CANARY_CONFIDENTIAL_SECRET_TOKEN_XYZ_987654"
    caplog.set_level(logging.DEBUG)

    res = client.post(
        "/v1/translate",
        json={
            "text": canary_text,
            "source_language": "eng_Latn",
            "target_language": "ita_Latn",
            "profile": "fast",
        },
    )
    assert res.status_code == 200

    # Inspect all logged messages
    all_log_text = " ".join([record.getMessage() for record in caplog.records])
    assert canary_text not in all_log_text, (
        f"CRITICAL PRIVACY VIOLATION: User text '{canary_text}' was found in the application logs!"
    )


def test_translation_metric_logger_contains_only_technical_data(caplog):
    """Ensure technical metric logging records only metadata."""
    caplog.set_level(logging.INFO)

    log_translation_metric(
        duration_ms=45.2,
        characters=120,
        chunks=3,
        device="cpu",
        compute_type="int8",
        profile="fast",
    )

    last_record = caplog.records[-1].getMessage()
    assert "Event=TRANSLATE" in last_record
    assert "duration_ms=45.2" in last_record
    assert "chars=120" in last_record
    assert "chunks=3" in last_record
    assert "device=cpu" in last_record
    assert "compute_type=int8" in last_record


def test_job_metric_logger_contains_only_technical_data(caplog):
    """Ensure async job metric logging records only metadata."""
    caplog.set_level(logging.INFO)

    log_job_metric(
        job_id="test-job-uuid-1234",
        event="completed",
        duration_ms=150.0,
        chunks=5,
        characters=450,
    )

    last_record = caplog.records[-1].getMessage()
    assert "Event=JOB_COMPLETED" in last_record
    assert "job_id=test-job-uuid-1234" in last_record
    assert "chunks=5" in last_record
    assert "chars=450" in last_record
    assert "duration_ms=150.0" in last_record
