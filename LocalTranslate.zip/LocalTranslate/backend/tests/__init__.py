"""Test package for LocalTranslate."""
