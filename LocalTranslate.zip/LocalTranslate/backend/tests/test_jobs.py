"""Tests for asynchronous translation jobs, progress, cancellation, and TTL."""

import time
from backend.app.core.profiles import get_profile
from backend.app.engine.batch_manager import BatchManager
from backend.app.engine.job_manager import JobManager


def test_job_lifecycle_completion(mock_engine):
    batch_mgr = BatchManager(engine=mock_engine)
    job_mgr = JobManager(batch_manager=batch_mgr)
    profile = get_profile("fast")

    text = "Hello world! This is a test sentence for the async job runner."
    job_id = job_mgr.create_job(
        text=text,
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
    )

    assert job_id is not None

    # Wait for completion (fast with mock engine)
    for _ in range(50):
        job = job_mgr.get_job(job_id)
        assert job is not None
        if job.status == "completed":
            break
        time.sleep(0.05)

    assert job.status == "completed"
    assert job.progress == 100.0
    assert job.result is not None
    assert "Traduzione:" in job.result
    assert job.duration_ms is not None
    assert job.characters == len(text)


def test_job_cancellation(mock_engine, monkeypatch):
    orig_translate = mock_engine.translate_batch
    def slow_translate(*args, **kwargs):
        time.sleep(0.05)
        return orig_translate(*args, **kwargs)
    monkeypatch.setattr(mock_engine, "translate_batch", slow_translate)

    batch_mgr = BatchManager(engine=mock_engine)
    job_mgr = JobManager(batch_manager=batch_mgr)
    profile = get_profile("fast")

    large_text = "\n\n".join([f"Paragraph {i} content text." for i in range(20)])
    job_id = job_mgr.create_job(
        text=large_text,
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
    )

    time.sleep(0.01)
    cancelled = job_mgr.cancel_job(job_id)
    assert cancelled is True

    job = job_mgr.get_job(job_id)
    assert job.status in ("cancelled", "processing")


def test_job_ttl_cleanup(mock_engine, monkeypatch):
    from backend.app.config import settings
    monkeypatch.setattr(settings, "job_ttl_seconds", 0.1)

    batch_mgr = BatchManager(engine=mock_engine)
    job_mgr = JobManager(batch_manager=batch_mgr)
    profile = get_profile("fast")

    job_id = job_mgr.create_job(
        text="Short text",
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
    )

    # Wait for job completion
    for _ in range(20):
        j = job_mgr.get_job(job_id)
        if j.status == "completed":
            break
        time.sleep(0.02)

    # Wait for TTL expiry
    time.sleep(0.2)
    cleaned = job_mgr.cleanup_expired_jobs()
    assert cleaned >= 1
    assert job_mgr.get_job(job_id) is None
