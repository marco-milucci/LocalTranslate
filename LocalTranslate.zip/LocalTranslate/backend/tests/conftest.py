"""Pytest fixtures for LocalTranslate testing suite."""

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional
import pytest
from starlette.testclient import TestClient

from backend.app.core.hardware import HardwareDetector, HardwareProfile
from backend.app.core.profiles import ProfileConfig, get_profile
from backend.app.engine.base import BaseModelProvider, BaseTranslationEngine
from backend.app.engine.batch_manager import BatchManager
from backend.app.engine.job_manager import JobManager
from backend.app.engine.model_manager import ModelManager
from backend.app.engine.router import ModelRouter
from backend.app.main import create_app


class MockTranslationEngine(BaseTranslationEngine):
    """Deterministic mock translation engine for fast and offline unit/integration testing."""

    def __init__(self, hardware: Optional[HardwareProfile] = None):
        self.hardware = hardware or HardwareDetector.detect()
        self._loaded = True
        self.provider: Optional[BaseModelProvider] = None

    def load(self, provider: BaseModelProvider) -> None:
        self.provider = provider
        self._loaded = True

    def unload(self) -> None:
        self._loaded = False
        self.provider = None

    def is_loaded(self) -> bool:
        return self._loaded

    def translate_batch(
        self,
        texts: List[str],
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
    ) -> List[str]:
        if not self._loaded:
            raise RuntimeError("Engine not loaded.")
        # Produce high quality deterministic output for testing
        results = []
        for t in texts:
            if target_lang.startswith("ita"):
                results.append(f"Traduzione: {t}")
            elif target_lang.startswith("eng"):
                results.append(f"Translation: {t}")
            else:
                results.append(f"[{target_lang}] {t}")
        return results

    def get_device_info(self) -> Dict[str, str]:
        return {
            "device": "cpu",
            "compute_type": "int8_float32",
            "backend": "CTranslate2 (Mock)",
        }


@pytest.fixture
def mock_engine() -> MockTranslationEngine:
    return MockTranslationEngine()


@pytest.fixture
def temp_model_dir():
    """Create a temporary valid model directory with manifest and valid mock spm files."""
    temp_dir = tempfile.mkdtemp(prefix="localtranslate_model_test_")
    p = Path(temp_dir)

    # Create mock model.bin
    model_bin = p / "model.bin"
    with open(model_bin, "wb") as f:
        f.write(b"LOCALTRANSLATE_MOCK_MODEL_DATA_FOR_UNIT_TESTS")

    # Create a real, valid tiny SentencePiece model
    spm_model = p / "spm.model"
    corpus_file = p / "corpus.txt"
    corpus_file.write_text("Hello world testing local translate sentences\n", encoding="utf-8")
    try:
        import sentencepiece as spm
        spm_prefix = str(p / "tiny_spm")
        spm.SentencePieceTrainer.train(
            input=str(corpus_file),
            model_prefix=spm_prefix,
            vocab_size=16,
            model_type="bpe",
        )
        shutil.move(f"{spm_prefix}.model", str(spm_model))
    except Exception:
        # Fallback if sentencepiece training is not available
        with open(spm_model, "wb") as f:
            f.write(b"MOCK_SPM_DATA")

    # Generate manifest
    bin_sha = hashlib.sha256(model_bin.read_bytes()).hexdigest()
    spm_sha = hashlib.sha256(spm_model.read_bytes()).hexdigest()

    manifest = {
        "model_id": "facebook/nllb-200-distilled-600M",
        "version": "1.0.0",
        "quantization": "int8",
        "framework": "ctranslate2",
        "files": {
            "model.bin": {"sha256": bin_sha, "size_bytes": model_bin.stat().st_size},
            "spm.model": {"sha256": spm_sha, "size_bytes": spm_model.stat().st_size},
        },
    }
    with open(p / "manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    yield p

    # Cleanup
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def test_app(temp_model_dir, mock_engine):
    """FastAPI test app instance configured with mock engine and temporary valid model."""
    app = create_app()

    hw = HardwareDetector.detect()
    app.state.hardware = hw
    app.state.engine = mock_engine

    model_manager = ModelManager(model_dir=temp_model_dir, engine=mock_engine)
    model_manager.load()
    app.state.model_manager = model_manager

    batch_manager = BatchManager(engine=mock_engine)
    app.state.batch_manager = batch_manager

    job_manager = JobManager(batch_manager=batch_manager)
    app.state.job_manager = job_manager

    router = ModelRouter(default_engine=mock_engine, hardware=hw)
    app.state.router = router

    return app


@pytest.fixture
def client(test_app) -> TestClient:
    return TestClient(test_app)
