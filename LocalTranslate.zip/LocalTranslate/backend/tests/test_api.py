"""Tests for FastAPI endpoints."""

import time


def test_health_endpoint(client):
    res = client.get("/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "ok"
    assert data["version"] == "1.0.0"
    assert "model_installed" in data
    assert "device" in data
    assert "compute_type" in data


def test_capabilities_endpoint(client):
    res = client.get("/v1/capabilities")
    assert res.status_code == 200
    data = res.json()
    assert "hardware" in data
    assert "supported_languages" in data
    assert "profiles" in data
    assert "fast" in data["profiles"]
    assert "quality" in data["profiles"]
    assert any(lang["code"] == "ita_Latn" for lang in data["supported_languages"])


def test_translate_endpoint_success(client):
    payload = {
        "text": "Hello world! This is a test.",
        "source_language": "eng_Latn",
        "target_language": "ita_Latn",
        "profile": "fast",
    }
    res = client.post("/v1/translate", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "translation" in data
    assert "Traduzione:" in data["translation"]
    assert data["source_language"] == "eng_Latn"
    assert data["target_language"] == "ita_Latn"
    assert data["duration_ms"] > 0
    assert data["characters"] == len(payload["text"])


def test_translate_auto_language_detection(client):
    payload = {
        "text": "This is an English test with many standard stopwords.",
        "source_language": "auto",
        "target_language": "ita_Latn",
        "profile": "quality",
    }
    res = client.post("/v1/translate", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["source_language"] == "eng_Latn"
    assert data["detected_language"] == "eng_Latn"
    assert data["detection_confidence"] is not None


def test_translate_batch_endpoint(client):
    payload = {
        "texts": [
            "First sentence.",
            "Second sentence.",
            "Third sentence.",
        ],
        "source_language": "eng_Latn",
        "target_language": "ita_Latn",
        "profile": "fast",
    }
    res = client.post("/v1/translate/batch", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert len(data["translations"]) == 3
    assert data["total_texts"] == 3
    assert data["total_characters"] > 0


def test_jobs_workflow(client):
    # 1. Create job
    create_payload = {
        "text": "Sentence for async job testing.\n\nAnother paragraph here.",
        "source_language": "eng_Latn",
        "target_language": "ita_Latn",
        "profile": "fast",
    }
    res_create = client.post("/v1/jobs", json=create_payload)
    assert res_create.status_code == 202
    data_create = res_create.json()
    job_id = data_create["job_id"]
    assert job_id is not None

    # 2. Poll job status
    for _ in range(50):
        res_get = client.get(f"/v1/jobs/{job_id}")
        assert res_get.status_code == 200
        data_get = res_get.json()
        if data_get["status"] == "completed":
            break
        time.sleep(0.05)

    assert data_get["status"] == "completed"
    assert data_get["result"] is not None
    assert "Traduzione:" in data_get["result"]


def test_input_size_limit_rejection(client):
    from backend.app.config import settings
    # Send text exceeding limit
    oversized = "A" * (settings.max_input_characters + 10)
    res = client.post(
        "/v1/translate",
        json={"text": oversized, "source_language": "eng_Latn", "target_language": "ita_Latn"}
    )
    assert res.status_code == 413
