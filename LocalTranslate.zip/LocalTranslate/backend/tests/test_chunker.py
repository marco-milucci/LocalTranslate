"""Tests for intelligent text chunking and reconstruction."""

from backend.app.core.chunker import IntelligentChunker, TextChunk
from backend.app.core.reconstructor import TextReconstructor


def test_empty_and_whitespace_input():
    chunks = IntelligentChunker.chunk_text("")
    assert chunks == []
    reconstructed = TextReconstructor.reconstruct(chunks, {})
    assert reconstructed == ""

    chunks = IntelligentChunker.chunk_text("   \n\n  \t  ")
    assert len(chunks) > 0
    # Reconstructed should preserve exact layout
    reconstructed = TextReconstructor.reconstruct(chunks, {})
    assert reconstructed == "   \n\n  \t  "


def test_single_character():
    chunks = IntelligentChunker.chunk_text("A")
    assert len(chunks) == 1
    assert chunks[0].text == "A"
    assert chunks[0].is_translatable is True
    reconstructed = TextReconstructor.reconstruct(chunks, {0: "Tradotto"})
    assert reconstructed == "Tradotto"


def test_paragraph_and_empty_lines_preservation():
    raw_text = "Primo paragrafo qui.\n\nSecondo paragrafo qui.\n\n\nTerzo paragrafo con riga extra."
    chunks = IntelligentChunker.chunk_text(raw_text)

    # Simulate translation
    trans_map = {}
    for c in chunks:
        if c.is_translatable:
            trans_map[c.chunk_id] = f"TRAD_{c.text}"

    reconstructed = TextReconstructor.reconstruct(chunks, trans_map)
    assert "\n\n" in reconstructed
    assert "\n\n\n" in reconstructed
    assert "TRAD_Primo paragrafo qui." in reconstructed
    assert "TRAD_Secondo paragrafo qui." in reconstructed
    assert "TRAD_Terzo paragrafo con riga extra." in reconstructed


def test_urls_and_emails_preservation():
    raw_text = (
        "Visit our site at https://www.example.com/docs/api?version=2.0 for details. "
        "Contact support at user.support@domain.org if you need help."
    )
    chunks = IntelligentChunker.chunk_text(raw_text)
    texts = [c.text for c in chunks]

    # Verify URL and email were not mangled or split internally
    combined = " ".join(texts)
    assert "https://www.example.com/docs/api?version=2.0" in combined
    assert "user.support@domain.org" in combined


def test_abbreviations_and_numbers_not_split():
    raw_text = (
        "The constant pi is approximately 3.14159 in mathematics. "
        "Dr. Smith explained e.g. how neural nets work."
    )
    chunks = IntelligentChunker.chunk_text(raw_text)
    # Shouldn't split at 3. or e.g. or Dr.
    for c in chunks:
        if "3.14159" in c.text:
            assert "3.14159" in c.text
        if "Dr. Smith" in c.text:
            assert "Dr. Smith" in c.text


def test_code_block_preservation():
    code_text = "Ecco il codice sorgente:\n\n```python\ndef add(a, b):\n    return a + b\n```\n\nFine codice."
    chunks = IntelligentChunker.chunk_text(code_text)

    trans_map = {}
    for c in chunks:
        if c.is_translatable:
            trans_map[c.chunk_id] = f"[{c.text}]"

    reconstructed = TextReconstructor.reconstruct(chunks, trans_map)
    assert "```python\ndef add(a, b):\n    return a + b\n```" in reconstructed


def test_huge_input_chunking_and_order():
    # Generate 50 paragraphs with numbered sentences
    paragraphs = []
    for i in range(1, 51):
        para = f"Paragraph {i} starts here. This is sentence two of paragraph {i}. Here is sentence three."
        paragraphs.append(para)

    large_text = "\n\n".join(paragraphs)
    chunks = IntelligentChunker.chunk_text(large_text, max_chunk_chars=120)

    assert len(chunks) > 50

    # Ensure chunk_ids are strictly monotonically increasing
    ids = [c.chunk_id for c in chunks]
    assert ids == list(range(len(chunks)))

    # Reconstruct with identity translation
    trans_map = {c.chunk_id: c.text for c in chunks if c.is_translatable}
    reconstructed = TextReconstructor.reconstruct(chunks, trans_map)
    assert reconstructed == large_text
