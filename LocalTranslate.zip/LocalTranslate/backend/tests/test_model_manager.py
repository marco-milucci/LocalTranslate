"""Tests for ModelManager lifecycle, validation, and missing model messages."""

from pathlib import Path
import pytest
from backend.app.engine.model_manager import (
    ModelChecksumError,
    ModelManager,
    ModelNotInstalledError,
)


def test_missing_model_raises_clean_message(tmp_path, mock_engine):
    empty_dir = tmp_path / "non_existent_model"
    manager = ModelManager(model_dir=empty_dir, engine=mock_engine)

    assert manager.provider.is_available() is False
    status = manager.status()
    assert status["installed"] is False
    assert status["loaded"] is False
    assert status["message"] == "Modello non installato. Avvia l'installazione del modello locale."

    # Loading should raise ModelNotInstalledError with exact required text
    with pytest.raises(ModelNotInstalledError) as exc_info:
        manager.load()
    assert "Modello non installato. Avvia l'installazione del modello locale." in str(exc_info.value)


def test_model_verification_and_corrupt_detection(temp_model_dir, mock_engine):
    manager = ModelManager(model_dir=temp_model_dir, engine=mock_engine)
    assert manager.provider.is_available() is True
    assert manager.verify() is True

    # Corrupt model.bin
    model_bin = temp_model_dir / "model.bin"
    with open(model_bin, "ab") as f:
        f.write(b"CORRUPT_BYTES")

    # verify should now fail
    assert manager.verify() is False

    with pytest.raises(ModelChecksumError):
        manager.load()


def test_model_load_and_unload_lifecycle(temp_model_dir, mock_engine):
    manager = ModelManager(model_dir=temp_model_dir, engine=mock_engine)
    manager.load()
    assert mock_engine.is_loaded() is True

    manager.unload()
    assert mock_engine.is_loaded() is False
