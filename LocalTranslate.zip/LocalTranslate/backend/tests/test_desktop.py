"""Tests for desktop integration: global hotkey, selection capture, system tray, and quick HUD."""

import threading
from pathlib import Path
from backend.app.desktop.hotkey import GlobalHotkeyListener, capture_active_selection, get_clipboard_text
from backend.app.desktop.quick_hud import QuickTranslationHUD
from backend.app.desktop.tray import SystemTrayApp, create_default_icon_image


def test_hotkey_listener_manual_trigger():
    triggered_texts = []

    def on_hotkey(text):
        triggered_texts.append(text)

    listener = GlobalHotkeyListener(callback=on_hotkey)
    listener.start()
    assert listener._running is True

    # Test manual trigger
    listener.trigger_manually("Text selected in external app")
    assert len(triggered_texts) == 1
    assert triggered_texts[0] == "Text selected in external app"

    listener.stop()
    assert listener._running is False


def test_system_tray_initialization_and_menu():
    actions = []

    def on_trans_sel():
        actions.append("selection")

    def on_trans_clip():
        actions.append("clipboard")

    def on_exit():
        actions.append("exit")

    tray = SystemTrayApp(
        on_translate_selection=on_trans_sel,
        on_translate_clipboard=on_trans_clip,
        on_exit=on_exit,
    )

    assert tray.profile == "fast"
    tray.set_profile("quality")
    assert tray.profile == "quality"

    # Verify default icon image creation
    img = create_default_icon_image()
    assert img.size == (64, 64)


def test_quick_hud_headless_safe():
    hud = QuickTranslationHUD()
    # In headless / test environment, show() should gracefully handle missing display without throwing
    hud.show(
        original_text="English source",
        translated_text="Traduzione italiana",
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        device="cpu",
        compute_type="int8",
        duration_ms=45.0,
    )


def test_desktop_app_server_lifecycle(monkeypatch):
    from backend.app.desktop.app_launcher import LocalTranslateDesktopApp

    app = LocalTranslateDesktopApp(port=8766)
    assert app.port == 8766
    assert app.hud is not None
    assert app.hotkey_listener is not None
    assert app.tray is not None


def test_find_available_port():
    from backend.app.desktop.app_launcher import find_available_port
    port = find_available_port(start_port=8765, max_attempts=15)
    assert isinstance(port, int)
    assert 8765 <= port <= 8780


def test_desktop_app_missing_model_feedback(monkeypatch):
    from backend.app.desktop.app_launcher import LocalTranslateDesktopApp

    shown_messages = []

    app = LocalTranslateDesktopApp(port=8767)
    # Mock hud.show
    monkeypatch.setattr(
        app.hud,
        "show",
        lambda original_text, translated_text, **kwargs: shown_messages.append(translated_text),
    )

    # Trigger captured text when model is not installed
    app._handle_captured_text("Hello world")
    assert len(shown_messages) == 1
    assert "1-INSTALLA-SUBITO.bat" in shown_messages[0]

