"""Tests for local offline language detector."""

from backend.app.core.language_detector import LocalLanguageDetector


def test_detect_italian():
    res = LocalLanguageDetector.detect("Questo è un test importante con molte parole in italiano per verificare il sistema.")
    assert res.is_reliable is True
    assert res.language == "ita_Latn"
    assert res.confidence >= 0.60


def test_detect_english():
    res = LocalLanguageDetector.detect("This is an important test with many common words in the English language.")
    assert res.is_reliable is True
    assert res.language == "eng_Latn"
    assert res.confidence >= 0.60


def test_detect_french():
    res = LocalLanguageDetector.detect("C'est un test important avec des phrases en français pour le système.")
    assert res.is_reliable is True
    assert res.language == "fra_Latn"


def test_detect_german():
    res = LocalLanguageDetector.detect("Das ist ein wichtiger Test für das System mit deutschen Wörtern und Sätzen.")
    assert res.is_reliable is True
    assert res.language == "deu_Latn"


def test_detect_spanish():
    res = LocalLanguageDetector.detect("Esta es una prueba importante para verificar la traducción en español con palabras comunes.")
    assert res.is_reliable is True
    assert res.language == "spa_Latn"


def test_detect_japanese():
    res = LocalLanguageDetector.detect("こんにちは世界。これはローカル翻訳のテストです。")
    assert res.is_reliable is True
    assert res.language == "jpn_Jpan"


def test_detect_chinese():
    res = LocalLanguageDetector.detect("这是一个用于测试本地翻译系统的中文文本示例。")
    assert res.is_reliable is True
    assert res.language == "zho_Hans"


def test_detect_russian_and_ukrainian():
    res_ru = LocalLanguageDetector.detect("Это важный тест на русском языке с проверкой обычных слов.")
    assert res_ru.is_reliable is True
    assert res_ru.language == "rus_Cyrl"

    res_uk = LocalLanguageDetector.detect("Це важливий тестовий приклад для перевірки української мови.")
    assert res_uk.is_reliable is True
    assert res_uk.language == "ukr_Cyrl"


def test_detect_arabic():
    res = LocalLanguageDetector.detect("هذا نص تجريبي لاختبار الترجمة المحلية باللغة العربية.")
    assert res.is_reliable is True
    assert res.language == "arb_Arab"


def test_detect_short_or_ambiguous_text():
    # Very short text
    res = LocalLanguageDetector.detect("Hi")
    assert res.is_reliable is False
    assert res.language is None
    assert "troppo breve" in res.message

    # Pure numbers or gibberish
    res_num = LocalLanguageDetector.detect("12345 67890 998877")
    assert res_num.is_reliable is False
    assert res_num.language is None
