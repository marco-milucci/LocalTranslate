"""Tests for local benchmark suite components."""

from backend.app.core.chunker import IntelligentChunker
from backend.app.core.profiles import get_profile
from backend.app.engine.batch_manager import BatchManager


def test_benchmark_chunking_and_throughput_computation(mock_engine):
    batch_mgr = BatchManager(engine=mock_engine)
    profile = get_profile("fast")

    sample_text = "This is a benchmark sample text to measure simulated characters per second."
    chunks = IntelligentChunker.chunk_text(sample_text)

    result = batch_mgr.translate_chunks(
        chunks=chunks,
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
    )

    assert result != ""
    chars = len(sample_text)
    # Simulated duration: positive
    simulated_duration_ms = 10.0
    throughput = (chars / (simulated_duration_ms / 1000.0))
    assert throughput > 0
