"""Tests for BatchManager and dynamic batching."""

import threading
import pytest
from backend.app.core.chunker import IntelligentChunker
from backend.app.core.profiles import get_profile
from backend.app.engine.batch_manager import BatchManager


def test_batch_manager_translation(mock_engine):
    batch_mgr = BatchManager(engine=mock_engine)
    profile = get_profile("fast")

    text = "First paragraph sentence one. First paragraph sentence two.\n\nSecond paragraph sentence here."
    chunks = IntelligentChunker.chunk_text(text)

    progress_records = []

    def on_progress(processed, total):
        progress_records.append((processed, total))

    result = batch_mgr.translate_chunks(
        chunks=chunks,
        source_lang="eng_Latn",
        target_lang="ita_Latn",
        profile=profile,
        progress_callback=on_progress,
    )

    assert "Traduzione:" in result
    assert "\n\n" in result
    assert len(progress_records) > 0


def test_batch_manager_cancellation(mock_engine):
    batch_mgr = BatchManager(engine=mock_engine)
    profile = get_profile("fast")

    chunks = IntelligentChunker.chunk_text("Sentence one.\n\nSentence two.\n\nSentence three.")
    cancel_event = threading.Event()
    cancel_event.set()  # Already cancelled

    with pytest.raises(InterruptedError):
        batch_mgr.translate_chunks(
            chunks=chunks,
            source_lang="eng_Latn",
            target_lang="ita_Latn",
            profile=profile,
            cancel_event=cancel_event,
        )
