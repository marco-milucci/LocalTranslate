"""Health check endpoint."""

from fastapi import APIRouter, Request
from .schemas import HealthResponse

router = APIRouter(tags=["Health"])


@router.get("/health", response_model=HealthResponse)
async def get_health(request: Request) -> HealthResponse:
    """Check backend operational health, model status, and device."""
    model_manager = getattr(request.app.state, "model_manager", None)
    engine = getattr(request.app.state, "engine", None)
    hardware = getattr(request.app.state, "hardware", None)

    model_installed = model_manager.provider.is_available() if model_manager else False
    model_loaded = engine.is_loaded() if engine else False
    device = engine.get_device_info().get("device", "cpu") if engine and engine.is_loaded() else (hardware.selected_device if hardware else "cpu")
    compute_type = engine.get_device_info().get("compute_type", "int8") if engine and engine.is_loaded() else (hardware.selected_compute_type if hardware else "int8")

    return HealthResponse(
        status="ok",
        version="1.0.0",
        model_installed=model_installed,
        model_loaded=model_loaded,
        device=device,
        compute_type=compute_type,
    )
