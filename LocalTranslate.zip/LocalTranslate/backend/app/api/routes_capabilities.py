"""Capabilities endpoint exposing hardware, active backend, and language options."""

from fastapi import APIRouter, Request
from .schemas import CapabilitiesResponse

router = APIRouter(tags=["Capabilities"])


@router.get("/v1/capabilities", response_model=CapabilitiesResponse)
async def get_capabilities(request: Request) -> CapabilitiesResponse:
    """Return runtime hardware detection, supported languages, and engine capabilities."""
    model_manager = getattr(request.app.state, "model_manager", None)
    if model_manager:
        caps = model_manager.capabilities()
    else:
        from ..core.hardware import HardwareDetector
        from ..core.languages import UI_LANGUAGES
        hw = HardwareDetector.detect()
        caps = {
            "model_status": {"installed": False, "loaded": False},
            "hardware": hw.to_dict(),
            "supported_languages": [
                {"code": code, "name": info["name"], "iso": info["iso"]}
                for code, info in UI_LANGUAGES.items()
            ],
            "profiles": ["fast", "quality"],
            "features": {
                "dynamic_batching": True,
                "async_jobs": True,
                "intelligent_chunking": True,
                "offline_language_detection": True,
            },
        }

    return CapabilitiesResponse(**caps)
