"""Asynchronous translation job endpoints for large documents."""

from fastapi import APIRouter, HTTPException, Request, status
from ..core.language_detector import LocalLanguageDetector
from ..core.languages import normalize_language_code
from ..core.profiles import get_profile
from ..core.security import SecurityValidator
from .schemas import JobCreateRequest, JobCreateResponse, JobStatusResponse

router = APIRouter(prefix="/v1", tags=["Jobs"])


@router.post("/jobs", response_model=JobCreateResponse, status_code=status.HTTP_202_ACCEPTED)
async def create_translation_job(req: JobCreateRequest, request: Request) -> JobCreateResponse:
    """Create a new asynchronous translation job for large text."""
    clean_text = SecurityValidator.validate_text_input(req.text)
    profile = get_profile(req.profile)

    source_lang = req.source_language.strip()
    if source_lang.lower() == "auto":
        detection = LocalLanguageDetector.detect(clean_text)
        if not detection.is_reliable or not detection.language:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=detection.message or "Impossibile rilevare la lingua sorgente per il job. Selezionala manualmente.",
            )
        source_lang = detection.language
    else:
        source_lang = normalize_language_code(source_lang)

    target_lang = normalize_language_code(req.target_language)

    job_manager = getattr(request.app.state, "job_manager", None)
    model_manager = getattr(request.app.state, "model_manager", None)
    engine = getattr(request.app.state, "engine", None)

    if not model_manager or not model_manager.provider.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Modello non installato. Avvia l'installazione del modello locale.",
        )

    if not engine or not engine.is_loaded():
        model_manager.load()

    job_id = job_manager.create_job(
        text=clean_text,
        source_lang=source_lang,
        target_lang=target_lang,
        profile=profile,
    )

    return JobCreateResponse(
        job_id=job_id,
        status="queued",
        characters=len(clean_text),
    )


@router.get("/jobs/{job_id}", response_model=JobStatusResponse)
async def get_job_status(job_id: str, request: Request) -> JobStatusResponse:
    """Get status, progress, and result of an asynchronous translation job."""
    job_manager = getattr(request.app.state, "job_manager", None)
    if not job_manager:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Job manager non inizializzato.")

    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Job {job_id} non trovato o scaduto.")

    return JobStatusResponse(**job.to_dict())


@router.delete("/jobs/{job_id}")
async def cancel_job(job_id: str, request: Request) -> dict[str, str]:
    """Cancel an active or queued translation job."""
    job_manager = getattr(request.app.state, "job_manager", None)
    if not job_manager:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Job manager non inizializzato.")

    cancelled = job_manager.cancel_job(job_id)
    if not cancelled:
        job = job_manager.get_job(job_id)
        if not job:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Job {job_id} non trovato.")
        return {"status": job.status, "message": f"Il job è già nello stato '{job.status}' e non può essere annullato."}

    return {"status": "cancelled", "message": f"Job {job_id} annullato con successo."}
