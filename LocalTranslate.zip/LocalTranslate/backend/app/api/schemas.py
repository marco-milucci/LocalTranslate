"""Pydantic v2 schemas for API requests and responses."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class TranslateRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Text to translate locally")
    source_language: str = Field(default="auto", description="Source language NLLB code or 'auto'")
    target_language: str = Field(default="ita_Latn", description="Target language NLLB code")
    profile: str = Field(default="fast", description="Profile: 'fast' or 'quality'")


class TranslateResponse(BaseModel):
    translation: str
    source_language: str
    target_language: str
    device: str
    compute_type: str
    duration_ms: float
    characters: int
    chunks: int
    detected_language: Optional[str] = None
    detection_confidence: Optional[float] = None
    throughput_chars_per_sec: float = 0.0


class BatchTranslateRequest(BaseModel):
    texts: List[str] = Field(..., min_length=1, description="List of texts to translate")
    source_language: str = Field(default="auto", description="Source language NLLB code or 'auto'")
    target_language: str = Field(default="ita_Latn", description="Target language NLLB code")
    profile: str = Field(default="fast", description="Profile: 'fast' or 'quality'")


class BatchTranslateResponse(BaseModel):
    translations: List[str]
    source_language: str
    target_language: str
    device: str
    compute_type: str
    duration_ms: float
    total_characters: int
    total_texts: int
    throughput_chars_per_sec: float = 0.0


class JobCreateRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Large text to translate asynchronously")
    source_language: str = Field(default="auto", description="Source language NLLB code or 'auto'")
    target_language: str = Field(default="ita_Latn", description="Target language NLLB code")
    profile: str = Field(default="fast", description="Profile: 'fast' or 'quality'")


class JobCreateResponse(BaseModel):
    job_id: str
    status: str
    characters: int


class JobStatusResponse(BaseModel):
    job_id: str
    status: str  # queued, processing, completed, failed, cancelled
    progress: float
    processed_chunks: int
    total_chunks: int
    characters: int
    source_language: str
    target_language: str
    profile: str
    result: Optional[str] = None
    error_message: Optional[str] = None
    duration_ms: Optional[float] = None
    device: Optional[str] = None
    compute_type: Optional[str] = None
    created_at: float


class HealthResponse(BaseModel):
    status: str
    version: str
    model_installed: bool
    model_loaded: bool
    device: str
    compute_type: str


class CapabilitiesResponse(BaseModel):
    model_status: Dict[str, Any]
    hardware: Dict[str, Any]
    supported_languages: List[Dict[str, str]]
    profiles: List[str]
    features: Dict[str, bool]
