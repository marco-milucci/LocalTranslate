"""Synchronous translation API endpoints."""

import time
from fastapi import APIRouter, HTTPException, Request, status
from ..core.chunker import IntelligentChunker
from ..core.language_detector import LocalLanguageDetector
from ..core.languages import normalize_language_code
from ..core.logging_filter import log_translation_metric
from ..core.profiles import get_profile
from ..core.security import SecurityValidator
from ..engine.model_manager import ModelNotInstalledError
from .schemas import (
    BatchTranslateRequest,
    BatchTranslateResponse,
    TranslateRequest,
    TranslateResponse,
)

router = APIRouter(prefix="/v1", tags=["Translation"])


@router.post("/translate", response_model=TranslateResponse)
async def translate_text(req: TranslateRequest, request: Request) -> TranslateResponse:
    """Translate text synchronously on local hardware with zero external calls."""
    start_time = time.perf_counter()

    # Input validation
    clean_text = SecurityValidator.validate_text_input(req.text)
    profile = get_profile(req.profile)

    # Resolve source language
    detected_lang = None
    confidence = None
    source_lang = req.source_language.strip()

    if source_lang.lower() == "auto":
        detection = LocalLanguageDetector.detect(clean_text)
        if not detection.is_reliable or not detection.language:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=detection.message or "Impossibile rilevare la lingua sorgente con sufficiente confidenza. Selezionala manualmente.",
            )
        source_lang = detection.language
        detected_lang = detection.language
        confidence = detection.confidence
    else:
        source_lang = normalize_language_code(source_lang)

    target_lang = normalize_language_code(req.target_language)

    # Check model readiness
    engine = getattr(request.app.state, "engine", None)
    batch_manager = getattr(request.app.state, "batch_manager", None)
    model_manager = getattr(request.app.state, "model_manager", None)

    if not model_manager or not model_manager.provider.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=ModelManager.MISSING_MODEL_MESSAGE if "ModelManager" in globals() else "Modello non installato. Avvia l'installazione del modello locale.",
        )

    if not engine or not engine.is_loaded():
        # Attempt to load model into memory if available
        try:
            model_manager.load()
        except ModelNotInstalledError:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=model_manager.MISSING_MODEL_MESSAGE,
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Errore durante l'inizializzazione del modello locale: {e}",
            )

    # Chunk and batch translation
    chunks = IntelligentChunker.chunk_text(clean_text)
    translatable_chunks = [c for c in chunks if c.is_translatable and c.text.strip()]
    chunk_count = max(1, len(translatable_chunks))

    translated_text = batch_manager.translate_chunks(
        chunks=chunks,
        source_lang=source_lang,
        target_lang=target_lang,
        profile=profile,
    )

    duration_ms = (time.perf_counter() - start_time) * 1000.0
    dev_info = engine.get_device_info()
    device = dev_info.get("device", "cpu")
    compute_type = dev_info.get("compute_type", "int8")

    char_count = len(clean_text)
    throughput = (char_count / (duration_ms / 1000.0)) if duration_ms > 0 else 0.0

    # Privacy logging: log ONLY performance metrics, never user text
    log_translation_metric(
        duration_ms=duration_ms,
        characters=char_count,
        chunks=chunk_count,
        device=device,
        compute_type=compute_type,
        profile=profile.name,
    )

    return TranslateResponse(
        translation=translated_text,
        source_language=source_lang,
        target_language=target_lang,
        device=device,
        compute_type=compute_type,
        duration_ms=round(duration_ms, 1),
        characters=char_count,
        chunks=chunk_count,
        detected_language=detected_lang,
        detection_confidence=confidence,
        throughput_chars_per_sec=round(throughput, 1),
    )


@router.post("/translate/batch", response_model=BatchTranslateResponse)
async def translate_batch(req: BatchTranslateRequest, request: Request) -> BatchTranslateResponse:
    """Translate multiple texts in a single batch request."""
    start_time = time.perf_counter()

    if not req.texts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La lista dei testi non può essere vuota.",
        )

    for t in req.texts:
        SecurityValidator.validate_text_input(t)

    profile = get_profile(req.profile)
    source_lang = req.source_language.strip()

    # Detect language using first non-empty text if auto
    if source_lang.lower() == "auto":
        sample = next((t for t in req.texts if len(t.strip()) >= 4), "")
        detection = LocalLanguageDetector.detect(sample)
        if not detection.is_reliable or not detection.language:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=detection.message or "Impossibile rilevare la lingua sorgente per il batch. Selezionala manualmente.",
            )
        source_lang = detection.language
    else:
        source_lang = normalize_language_code(source_lang)

    target_lang = normalize_language_code(req.target_language)

    engine = getattr(request.app.state, "engine", None)
    model_manager = getattr(request.app.state, "model_manager", None)

    if not model_manager or not model_manager.provider.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Modello non installato. Avvia l'installazione del modello locale.",
        )

    if not engine or not engine.is_loaded():
        model_manager.load()

    # Perform batch translation
    translations = engine.translate_batch(
        texts=req.texts,
        source_lang=source_lang,
        target_lang=target_lang,
        profile=profile,
    )

    duration_ms = (time.perf_counter() - start_time) * 1000.0
    total_chars = sum(len(t) for t in req.texts)
    throughput = (total_chars / (duration_ms / 1000.0)) if duration_ms > 0 else 0.0

    dev_info = engine.get_device_info()
    device = dev_info.get("device", "cpu")
    compute_type = dev_info.get("compute_type", "int8")

    log_translation_metric(
        duration_ms=duration_ms,
        characters=total_chars,
        chunks=len(req.texts),
        device=device,
        compute_type=compute_type,
        profile=profile.name,
    )

    return BatchTranslateResponse(
        translations=translations,
        source_language=source_lang,
        target_language=target_lang,
        device=device,
        compute_type=compute_type,
        duration_ms=round(duration_ms, 1),
        total_characters=total_chars,
        total_texts=len(req.texts),
        throughput_chars_per_sec=round(throughput, 1),
    )
