import os
from pathlib import Path
from pydantic import BaseModel, Field

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
DEFAULT_MODEL_DIR = MODELS_DIR / "nllb-200-distilled-600M-int8"

class Settings(BaseModel):
    """LocalTranslate backend configuration."""
    
    app_name: str = "LocalTranslate"
    version: str = "1.0.0"
    
    # Strictly localhost only
    host: str = Field(default="127.0.0.1", description="Strictly bind to 127.0.0.1 for local privacy")
    port: int = Field(default=int(os.getenv("LOCALTRANSLATE_PORT", "8765")), description="Backend listening port")
    
    # Model configuration
    models_dir: Path = Path(os.getenv("LOCALTRANSLATE_MODELS_DIR", str(MODELS_DIR)))
    default_model_dir: Path = Path(os.getenv("LOCALTRANSLATE_MODEL_PATH", str(DEFAULT_MODEL_DIR)))
    default_model_id: str = "facebook/nllb-200-distilled-600M"
    
    # Security limits
    max_input_characters: int = 500_000
    request_timeout_seconds: float = 120.0
    
    # Asynchronous jobs
    job_ttl_seconds: int = 600  # 10 minutes in-memory retention
    job_cleanup_interval_seconds: int = 60
    
    # Batch processing
    max_batch_size_fast: int = 16
    max_batch_size_quality: int = 4
    
    # CORS: Allow only browser extensions and local origins
    cors_origins: list[str] = [
        "chrome-extension://*",
        "moz-extension://*",
        "edge-extension://*",
        "http://127.0.0.1",
        "http://localhost",
        "http://127.0.0.1:8765",
        "http://localhost:8765",
    ]


settings = Settings()
