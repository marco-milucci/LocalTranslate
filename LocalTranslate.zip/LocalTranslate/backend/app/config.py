import os
import sys
from pathlib import Path
from pydantic import BaseModel, Field

# Base directories and dynamic model resolution
if getattr(sys, "frozen", False):
    EXE_DIR = Path(sys.executable).resolve().parent
    BASE_DIR = EXE_DIR
else:
    BASE_DIR = Path(__file__).resolve().parent.parent
    EXE_DIR = BASE_DIR.parent

def resolve_model_dir() -> Path:
    """Find the NLLB-200 INT8 model directory across any folder layout."""
    env_path = os.getenv("LOCALTRANSLATE_MODEL_PATH")
    if env_path:
        p = Path(env_path)
        if (p / "model.bin").exists():
            return p
        if (p / "nllb-200-distilled-600M-int8" / "model.bin").exists():
            return p / "nllb-200-distilled-600M-int8"

    candidates = [
        EXE_DIR / "models" / "nllb-200-distilled-600M-int8",
        EXE_DIR / "models",
        EXE_DIR / "backend" / "models" / "nllb-200-distilled-600M-int8",
        EXE_DIR / "backend" / "models",
        EXE_DIR / "_internal" / "backend" / "models" / "nllb-200-distilled-600M-int8",
        EXE_DIR / "_internal" / "models" / "nllb-200-distilled-600M-int8",
        BASE_DIR / "models" / "nllb-200-distilled-600M-int8",
        BASE_DIR / "models",
    ]
    for c in candidates:
        if (c / "model.bin").exists():
            return c

    # Recursive search if not in standard locations
    try:
        for p in EXE_DIR.glob("**/model.bin"):
            return p.parent
    except Exception:
        pass

    return EXE_DIR / "models" / "nllb-200-distilled-600M-int8"

DEFAULT_MODEL_DIR = resolve_model_dir()
MODELS_DIR = DEFAULT_MODEL_DIR.parent


class Settings(BaseModel):
    """LocalTranslate backend configuration."""
    
    app_name: str = "LocalTranslate"
    version: str = "1.0.0"
    
    # Strictly localhost only
    host: str = Field(default="127.0.0.1", description="Strictly bind to 127.0.0.1 for local privacy")
    port: int = Field(default=int(os.getenv("LOCALTRANSLATE_PORT", "8765")), description="Backend listening port")
    
    # Model configuration
    models_dir: Path = Path(os.getenv("LOCALTRANSLATE_MODELS_DIR", str(MODELS_DIR)))
    default_model_dir: Path = Path(os.getenv("LOCALTRANSLATE_MODEL_PATH", str(DEFAULT_MODEL_DIR)))
    default_model_id: str = "facebook/nllb-200-distilled-600M"
    
    # Security limits
    max_input_characters: int = 500_000
    request_timeout_seconds: float = 120.0
    
    # Asynchronous jobs
    job_ttl_seconds: int = 600  # 10 minutes in-memory retention
    job_cleanup_interval_seconds: int = 60
    
    # Batch processing
    max_batch_size_fast: int = 16
    max_batch_size_quality: int = 4
    
    # CORS: Allow only browser extensions and local origins
    cors_origins: list[str] = [
        "chrome-extension://*",
        "moz-extension://*",
        "edge-extension://*",
        "http://127.0.0.1",
        "http://localhost",
        "http://127.0.0.1:8765",
        "http://localhost:8765",
    ]


settings = Settings()
