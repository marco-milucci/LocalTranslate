"""Engine package for LocalTranslate inference and model lifecycle."""
