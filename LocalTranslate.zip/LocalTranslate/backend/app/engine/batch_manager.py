"""Dynamic batch manager for scaling translations across chunks."""

import threading
from typing import Callable, Dict, List, Optional
from ..core.chunker import TextChunk
from ..core.profiles import ProfileConfig
from ..core.reconstructor import TextReconstructor
from .base import BaseTranslationEngine


class BatchManager:
    """Manages chunk batching, worker execution, and translation reconstruction."""

    def __init__(self, engine: BaseTranslationEngine):
        self.engine = engine

    def translate_chunks(
        self,
        chunks: List[TextChunk],
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        cancel_event: Optional[threading.Event] = None,
    ) -> str:
        """Translate a collection of TextChunks using dynamic batching, returning reconstructed text."""
        if not chunks:
            return ""

        # Filter translatable chunks
        translatable = [c for c in chunks if c.is_translatable and c.text.strip()]
        total_translatable = len(translatable)

        translated_map: Dict[int, str] = {}
        processed_count = 0

        # Batch size from profile
        batch_size = max(1, profile.batch_size)

        for i in range(0, total_translatable, batch_size):
            # Check cancellation between batches
            if cancel_event is not None and cancel_event.is_set():
                raise InterruptedError("Operazione di traduzione annullata dall'utente.")

            batch_chunk_items = translatable[i : i + batch_size]
            batch_texts = [c.text for c in batch_chunk_items]

            batch_translations = self.engine.translate_batch(
                texts=batch_texts,
                source_lang=source_lang,
                target_lang=target_lang,
                profile=profile,
            )

            for chunk_item, trans_text in zip(batch_chunk_items, batch_translations):
                translated_map[chunk_item.chunk_id] = trans_text

            processed_count += len(batch_chunk_items)
            if progress_callback is not None:
                progress_callback(processed_count, total_translatable)

        # Reconstruct full document
        return TextReconstructor.reconstruct(chunks, translated_map)
