"""Model provider implementation for NLLB-200 and SentencePiece tokenization."""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from .base import BaseModelProvider
from ..core.languages import normalize_language_code, UI_LANGUAGES

try:
    import sentencepiece as spm
    SENTENCEPIECE_AVAILABLE = True
except ImportError:
    spm = None
    SENTENCEPIECE_AVAILABLE = False


class NLLBModelProvider(BaseModelProvider):
    """Provides model files and tokenization for NLLB-200 models converted to CTranslate2."""

    def __init__(self, model_dir: Path | str):
        self.model_dir = Path(model_dir)
        self.sp_processor: Optional[Any] = None
        self._metadata: Dict[str, Any] = {}
        self._load_metadata()

    def _load_metadata(self) -> None:
        manifest_file = self.model_dir / "manifest.json"
        if manifest_file.exists():
            try:
                with open(manifest_file, "r", encoding="utf-8") as f:
                    self._metadata = json.load(f)
            except Exception:
                self._metadata = {}
        else:
            self._metadata = {
                "model_id": "facebook/nllb-200-distilled-600M",
                "quantization": "int8",
                "version": "1.0.0",
                "framework": "ctranslate2",
            }

    def get_model_path(self) -> str:
        return str(self.model_dir)

    def is_available(self) -> bool:
        """Check if necessary model files exist in model directory."""
        if not self.model_dir.exists() or not self.model_dir.is_dir():
            return False

        model_bin = self.model_dir / "model.bin"
        spm_model = self._find_spm_file()
        return model_bin.exists() and spm_model is not None

    def _find_spm_file(self) -> Optional[Path]:
        for candidate in ["spm.model", "sentencepiece.bpe.model", "source.spm"]:
            path = self.model_dir / candidate
            if path.exists():
                return path
        return None

    def load_tokenizer(self) -> None:
        """Initialize SentencePiece tokenizer."""
        spm_path = self._find_spm_file()
        if spm_path and SENTENCEPIECE_AVAILABLE:
            try:
                self.sp_processor = spm.SentencePieceProcessor()
                self.sp_processor.load(str(spm_path))
            except Exception:
                self.sp_processor = None

    def get_metadata(self) -> Dict[str, Any]:
        return self._metadata

    def tokenize(self, text: str, source_lang: str) -> List[str]:
        norm_lang = normalize_language_code(source_lang)
        if self.sp_processor is not None:
            # NLLB standard tokenization: [source_lang] + encoded pieces
            pieces = self.sp_processor.encode(text, out_type=str)
            return [norm_lang] + pieces
        # Fallback word-level pieces for testing if tokenizer not initialized
        words = text.split()
        return [norm_lang] + [f" {w}" for w in words]

    def detokenize(self, tokens: List[str]) -> str:
        if not tokens:
            return ""

        # Remove language tags if present at start
        cleaned_tokens = [t for t in tokens if not (len(t) >= 7 and "_" in t)]

        if self.sp_processor is not None:
            return self.sp_processor.decode(cleaned_tokens)

        # Basic detokenization fallback
        text = "".join(cleaned_tokens).replace(" ", " ").strip()
        return text
