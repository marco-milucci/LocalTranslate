"""CTranslate2 resident inference engine with INT8 quantization."""

import collections
from typing import Dict, List, Optional
from ..core.hardware import HardwareDetector, HardwareProfile
from ..core.languages import normalize_language_code
from ..core.logging_filter import logger
from ..core.profiles import ProfileConfig
from .base import BaseModelProvider, BaseTranslationEngine

try:
    import ctranslate2
    CTRANSLATE2_AVAILABLE = True
except ImportError:
    ctranslate2 = None
    CTRANSLATE2_AVAILABLE = False


class CTranslate2TranslationEngine(BaseTranslationEngine):
    """Production translation engine utilizing resident CTranslate2 with INT8 quantization."""

    CACHE_MAX_ENTRIES = 2048

    def __init__(self, hardware: Optional[HardwareProfile] = None):
        self.hardware = hardware or HardwareDetector.detect()
        self.translator: Optional[Any] = None
        self.provider: Optional[BaseModelProvider] = None
        self._device = self.hardware.selected_device
        self._compute_type = self.hardware.selected_compute_type
        # In-memory LRU cache for duplicate sentences in the same session
        self._cache: collections.OrderedDict[tuple[str, str, str, str], str] = collections.OrderedDict()

    def load(self, provider: BaseModelProvider) -> None:
        """Load CTranslate2 translator into resident memory."""
        self.provider = provider
        model_path = provider.get_model_path()

        if not CTRANSLATE2_AVAILABLE:
            raise RuntimeError("CTranslate2 package is not available in runtime.")

        logger.info(
            f"Loading CTranslate2 model from {model_path} onto {self._device} "
            f"({self._compute_type}) with {self.hardware.inter_threads} inter-threads and "
            f"{self.hardware.intra_threads} intra-threads..."
        )

        inter_threads = max(1, min(4, self.hardware.inter_threads))
        intra_threads = max(1, min(8, self.hardware.intra_threads))

        try:
            self.translator = ctranslate2.Translator(
                model_path,
                device=self._device,
                compute_type=self._compute_type,
                inter_threads=inter_threads,
                intra_threads=intra_threads,
            )
        except Exception as e:
            # Fallback to CPU if CUDA initialization fails
            if self._device == "cuda":
                logger.warning(f"CUDA initialization failed ({e}). Falling back to CPU INT8...")
                self._device = "cpu"
                self._compute_type = "int8"
                self.translator = ctranslate2.Translator(
                    model_path,
                    device="cpu",
                    compute_type="int8",
                    inter_threads=inter_threads,
                    intra_threads=intra_threads,
                )
            else:
                raise e

        logger.info(f"CTranslate2 resident model initialized and ready on {self._device} ({self._compute_type}).")

    def unload(self) -> None:
        """Release resident CTranslate2 model."""
        self.translator = None
        self.provider = None
        self._cache.clear()

    def is_loaded(self) -> bool:
        return self.translator is not None

    def get_device_info(self) -> Dict[str, str]:
        return {
            "device": self._device,
            "compute_type": self._compute_type,
            "backend": "CTranslate2",
        }

    def translate_batch(
        self,
        texts: List[str],
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
    ) -> List[str]:
        """Translate a batch of texts using CTranslate2."""
        if not texts:
            return []

        if not self.is_loaded() or self.provider is None:
            raise RuntimeError("Translation engine is not loaded.")

        norm_src = normalize_language_code(source_lang)
        norm_tgt = normalize_language_code(target_lang)

        # Check cache and separate uncached items
        results: List[Optional[str]] = [None] * len(texts)
        uncached_indices: List[int] = []
        uncached_texts: List[str] = []

        for idx, text in enumerate(texts):
            cache_key = (text, norm_src, norm_tgt, profile.name)
            if cache_key in self._cache:
                # Move to end (LRU)
                self._cache.move_to_end(cache_key)
                results[idx] = self._cache[cache_key]
            else:
                uncached_indices.append(idx)
                uncached_texts.append(text)

        if not uncached_texts:
            return [r for r in results if r is not None]

        # Tokenize uncached texts
        tokenized_batch = [
            self.provider.tokenize(t, norm_src) for t in uncached_texts
        ]

        # Target prefix for NLLB (forces generation in target language)
        target_prefix = [[norm_tgt] for _ in uncached_texts]

        # Run CTranslate2 batch inference
        translations = self.translator.translate_batch(
            tokenized_batch,
            target_prefix=target_prefix,
            beam_size=profile.beam_size,
            patience=profile.patience,
            repetition_penalty=profile.repetition_penalty,
            length_penalty=profile.length_penalty,
            max_decoding_length=profile.max_decoding_length,
            num_hypotheses=profile.num_hypotheses,
        )

        # Detokenize results
        for u_idx, trans in zip(uncached_indices, translations):
            hyp = trans.hypotheses[0] if trans.hypotheses else []
            decoded = self.provider.detokenize(hyp)

            # Store in cache
            orig_text = texts[u_idx]
            cache_key = (orig_text, norm_src, norm_tgt, profile.name)
            if len(self._cache) >= self.CACHE_MAX_ENTRIES:
                self._cache.popitem(last=False)
            self._cache[cache_key] = decoded

            results[u_idx] = decoded

        return [r if r is not None else "" for r in results]
