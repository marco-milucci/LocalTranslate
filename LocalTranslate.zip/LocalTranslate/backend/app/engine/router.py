"""Multi-model router for pairing, resource limits, and specialized models."""

from dataclasses import dataclass
from typing import Dict, List, Optional
from ..core.hardware import HardwareDetector, HardwareProfile
from ..core.languages import normalize_language_code
from .base import BaseTranslationEngine


@dataclass
class ModelRoute:
    model_id: str
    source_languages: List[str]  # Empty means universal
    target_languages: List[str]  # Empty means universal
    min_ram_gb: float
    requires_cuda: bool
    is_specialized: bool


class ModelRouter:
    """Routes translation requests to the best available model based on languages and hardware."""

    def __init__(self, default_engine: BaseTranslationEngine, hardware: Optional[HardwareProfile] = None):
        self.default_engine = default_engine
        self.hardware = hardware or HardwareDetector.detect()
        self.routes: Dict[str, ModelRoute] = {
            "nllb-200-distilled-600M": ModelRoute(
                model_id="facebook/nllb-200-distilled-600M",
                source_languages=[],  # Universal: 200 languages
                target_languages=[],
                min_ram_gb=2.0,
                requires_cuda=False,
                is_specialized=False,
            )
        }

    def register_route(self, route_key: str, route: ModelRoute) -> None:
        """Register a new specialized model route."""
        self.routes[route_key] = route

    def select_engine(
        self,
        source_lang: str,
        target_lang: str,
        profile_name: str,
    ) -> tuple[str, BaseTranslationEngine]:
        """Select appropriate model and engine for language pair and hardware."""
        norm_src = normalize_language_code(source_lang)
        norm_tgt = normalize_language_code(target_lang)

        # Check for specialized models if registered and compatible
        for route_key, route in self.routes.items():
            if not route.is_specialized:
                continue

            # Check language match
            if route.source_languages and norm_src not in route.source_languages:
                continue
            if route.target_languages and norm_tgt not in route.target_languages:
                continue

            # Check hardware requirements
            if route.requires_cuda and not self.hardware.cuda_available:
                continue
            if self.hardware.available_ram_gb < route.min_ram_gb:
                continue

            # Match found
            return route.model_id, self.default_engine

        # Universal fallback: NLLB
        return self.routes["nllb-200-distilled-600M"].model_id, self.default_engine
