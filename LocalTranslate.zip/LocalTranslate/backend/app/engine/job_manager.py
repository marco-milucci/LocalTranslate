"""Asynchronous job manager for large translations with in-memory TTL and cancellation."""

import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from ..config import settings
from ..core.chunker import IntelligentChunker
from ..core.logging_filter import log_job_metric, logger
from ..core.profiles import ProfileConfig
from .batch_manager import BatchManager


@dataclass
class TranslationJob:
    job_id: str
    status: str  # queued, processing, completed, failed, cancelled
    progress: float = 0.0  # 0.0 - 100.0
    processed_chunks: int = 0
    total_chunks: int = 0
    characters: int = 0
    source_language: str = ""
    target_language: str = ""
    profile: str = "fast"
    result: Optional[str] = None
    error_message: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    duration_ms: Optional[float] = None
    device: str = "cpu"
    compute_type: str = "int8"
    cancel_event: threading.Event = field(default_factory=threading.Event)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id,
            "status": self.status,
            "progress": round(self.progress, 1),
            "processed_chunks": self.processed_chunks,
            "total_chunks": self.total_chunks,
            "characters": self.characters,
            "source_language": self.source_language,
            "target_language": self.target_language,
            "profile": self.profile,
            "result": self.result,
            "error_message": self.error_message,
            "duration_ms": round(self.duration_ms, 1) if self.duration_ms is not None else None,
            "device": self.device,
            "compute_type": self.compute_type,
            "created_at": self.created_at,
        }


class JobManager:
    """Manages asynchronous translation jobs with TTL and worker thread pooling."""

    def __init__(self, batch_manager: BatchManager, max_workers: int = 2):
        self.batch_manager = batch_manager
        self.jobs: Dict[str, TranslationJob] = {}
        self.lock = threading.Lock()
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="LocalTranslateJobWorker")

    def cleanup_expired_jobs(self) -> int:
        """Remove completed or failed jobs older than job_ttl_seconds."""
        now = time.time()
        expired_ids = []
        with self.lock:
            for j_id, job in self.jobs.items():
                if job.status in ("completed", "failed", "cancelled"):
                    if now - job.updated_at > settings.job_ttl_seconds:
                        expired_ids.append(j_id)
            for j_id in expired_ids:
                del self.jobs[j_id]
        return len(expired_ids)

    def create_job(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
    ) -> str:
        """Create and queue a new asynchronous translation job."""
        self.cleanup_expired_jobs()

        job_id = str(uuid.uuid4())
        job = TranslationJob(
            job_id=job_id,
            status="queued",
            characters=len(text),
            source_language=source_lang,
            target_language=target_lang,
            profile=profile.name,
        )

        with self.lock:
            self.jobs[job_id] = job

        log_job_metric(job_id, "created", characters=len(text))

        # Submit to worker pool
        self.executor.submit(
            self._run_job,
            job_id=job_id,
            text=text,
            source_lang=source_lang,
            target_lang=target_lang,
            profile=profile,
        )

        return job_id

    def get_job(self, job_id: str) -> Optional[TranslationJob]:
        """Retrieve job by id."""
        self.cleanup_expired_jobs()
        with self.lock:
            return self.jobs.get(job_id)

    def cancel_job(self, job_id: str) -> bool:
        """Signal job cancellation."""
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return False

            if job.status in ("completed", "failed", "cancelled"):
                return False

            job.cancel_event.set()
            job.status = "cancelled"
            job.updated_at = time.time()
            log_job_metric(job_id, "cancelled")
            return True

    def _run_job(
        self,
        job_id: str,
        text: str,
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
    ) -> None:
        """Worker thread function executing translation."""
        with self.lock:
            job = self.jobs.get(job_id)
            if not job or job.cancel_event.is_set():
                return
            job.status = "processing"
            job.updated_at = time.time()

        start_time = time.perf_counter()
        try:
            chunks = IntelligentChunker.chunk_text(text)
            translatable_chunks = [c for c in chunks if c.is_translatable and c.text.strip()]
            total_translatable = len(translatable_chunks)

            with self.lock:
                job.total_chunks = total_translatable

            def on_progress(processed: int, total: int):
                with self.lock:
                    if job_id in self.jobs:
                        j = self.jobs[job_id]
                        j.processed_chunks = processed
                        j.progress = (processed / total * 100.0) if total > 0 else 100.0
                        j.updated_at = time.time()

            result = self.batch_manager.translate_chunks(
                chunks=chunks,
                source_lang=source_lang,
                target_lang=target_lang,
                profile=profile,
                progress_callback=on_progress,
                cancel_event=job.cancel_event,
            )

            duration_ms = (time.perf_counter() - start_time) * 1000.0
            dev_info = self.batch_manager.engine.get_device_info()

            with self.lock:
                if job.cancel_event.is_set():
                    job.status = "cancelled"
                else:
                    job.status = "completed"
                    job.progress = 100.0
                    job.result = result
                    job.duration_ms = duration_ms
                    job.device = dev_info.get("device", "cpu")
                    job.compute_type = dev_info.get("compute_type", "int8")
                job.updated_at = time.time()

            log_job_metric(
                job_id,
                "completed" if job.status == "completed" else "cancelled",
                duration_ms=duration_ms,
                chunks=total_translatable,
                characters=len(text),
            )

        except InterruptedError:
            with self.lock:
                job.status = "cancelled"
                job.updated_at = time.time()
            log_job_metric(job_id, "interrupted")
        except Exception as e:
            duration_ms = (time.perf_counter() - start_time) * 1000.0
            logger.error(f"Job {job_id} encountered error: {e}")
            with self.lock:
                job.status = "failed"
                job.error_message = str(e)
                job.duration_ms = duration_ms
                job.updated_at = time.time()
            log_job_metric(job_id, "failed", duration_ms=duration_ms)
