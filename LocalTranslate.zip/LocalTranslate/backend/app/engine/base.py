"""Abstract base interfaces for ModelProvider and TranslationEngine."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from ..core.profiles import ProfileConfig


class BaseModelProvider(ABC):
    """Interface for resolving and accessing model assets and tokenizers."""

    @abstractmethod
    def get_model_path(self) -> str:
        """Return the filesystem path to the model directory."""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if model files exist and are verified."""
        pass

    @abstractmethod
    def get_metadata(self) -> Dict[str, Any]:
        """Return model metadata, supported languages, quantization info."""
        pass

    @abstractmethod
    def tokenize(self, text: str, source_lang: str) -> List[str]:
        """Tokenize text into tokens for the translation engine."""
        pass

    @abstractmethod
    def detokenize(self, tokens: List[str]) -> str:
        """Convert engine output tokens back into clean text."""
        pass


class BaseTranslationEngine(ABC):
    """Interface for model inference engines."""

    @abstractmethod
    def load(self, provider: BaseModelProvider) -> None:
        """Load model into resident memory."""
        pass

    @abstractmethod
    def unload(self) -> None:
        """Unload model and release memory."""
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        """Check if model is currently resident in memory."""
        pass

    @abstractmethod
    def translate_batch(
        self,
        texts: List[str],
        source_lang: str,
        target_lang: str,
        profile: ProfileConfig,
    ) -> List[str]:
        """Perform batch translation."""
        pass

    @abstractmethod
    def get_device_info(self) -> Dict[str, str]:
        """Return currently utilized device and compute type."""
        pass
