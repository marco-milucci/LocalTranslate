"""Model lifecycle manager: install, verify, load, unload, checksum, capabilities."""

import gc
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any, Dict, Optional
from ..config import settings
from ..core.hardware import HardwareDetector, HardwareProfile
from ..core.languages import UI_LANGUAGES
from ..core.logging_filter import logger
from .base import BaseTranslationEngine
from .model_provider import NLLBModelProvider


class ModelNotInstalledError(RuntimeError):
    """Raised when translation is requested but local model is missing."""
    pass


class ModelChecksumError(RuntimeError):
    """Raised when model files are corrupted or fail SHA-256 validation."""
    pass


class ModelManager:
    """Manages local translation model files, validation, and lifecycle."""

    MISSING_MODEL_MESSAGE = "Modello non installato. Avvia l'installazione del modello locale."

    def __init__(self, model_dir: Optional[Path] = None, engine: Optional[BaseTranslationEngine] = None):
        self.model_dir = Path(model_dir or settings.default_model_dir)
        self.provider = NLLBModelProvider(self.model_dir)
        self.engine = engine
        self._hardware: HardwareProfile = HardwareDetector.detect()

    @staticmethod
    def calculate_checksum(file_path: Path | str) -> str:
        """Calculate SHA-256 hash of a file."""
        p = Path(file_path)
        if not p.is_file():
            raise FileNotFoundError(f"File not found: {p}")

        sha256 = hashlib.sha256()
        with open(p, "rb") as f:
            while chunk := f.read(1024 * 1024):  # 1MB buffer
                sha256.update(chunk)
        return sha256.hexdigest()

    def install(self, source_path: Path | str, model_id: str = "facebook/nllb-200-distilled-600M") -> Dict[str, Any]:
        """Install converted CTranslate2 model into application models directory and generate manifest."""
        src = Path(source_path)
        if not src.exists() or not src.is_dir():
            raise FileNotFoundError(f"Source directory does not exist: {src}")

        self.model_dir.parent.mkdir(parents=True, exist_ok=True)

        # Copy or sync files
        if src.resolve() != self.model_dir.resolve():
            if self.model_dir.exists():
                shutil.rmtree(self.model_dir)
            shutil.copytree(src, self.model_dir)

        # Compute checksums for all files
        manifest_files = {}
        for item in self.model_dir.iterdir():
            if item.is_file() and item.name != "manifest.json":
                manifest_files[item.name] = {
                    "sha256": self.calculate_checksum(item),
                    "size_bytes": item.stat().st_size,
                }

        manifest = {
            "model_id": model_id,
            "version": "1.0.0",
            "quantization": "int8",
            "framework": "ctranslate2",
            "files": manifest_files,
        }

        manifest_path = self.model_dir / "manifest.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        # Refresh provider
        self.provider = NLLBModelProvider(self.model_dir)
        logger.info(f"Model {model_id} installed successfully at {self.model_dir}")
        return manifest

    def verify(self) -> bool:
        """Verify model files exist and match manifest checksums."""
        if not self.provider.is_available():
            return False

        manifest_path = self.model_dir / "manifest.json"
        if not manifest_path.exists():
            # Files exist but manifest is absent: check model.bin presence
            return (self.model_dir / "model.bin").is_file()

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)

            files_dict = manifest.get("files", {})
            for filename, meta in files_dict.items():
                expected_sha = meta.get("sha256")
                target_file = self.model_dir / filename
                if not target_file.exists():
                    return False
                if expected_sha and self.calculate_checksum(target_file) != expected_sha:
                    return False

            return True
        except Exception as e:
            logger.error(f"Model verification failed: {e}")
            return False

    def load(self) -> None:
        """Load model into memory resident engine."""
        if not self.provider.is_available():
            raise ModelNotInstalledError(self.MISSING_MODEL_MESSAGE)

        if not self.verify():
            raise ModelChecksumError(
                "I file del modello locale sono corrotti o non corrispondono al manifest. "
                "Ripeti l'installazione del modello."
            )

        self.provider.load_tokenizer()

        if self.engine is not None:
            self.engine.load(self.provider)
            dev_info = self.engine.get_device_info()
            logger.info(
                f"Model resident in memory. Device: {dev_info.get('device')} "
                f"Compute: {dev_info.get('compute_type')}"
            )

    def unload(self) -> None:
        """Unload model from memory and reclaim RAM/VRAM."""
        if self.engine is not None and self.engine.is_loaded():
            self.engine.unload()
            gc.collect()
            logger.info("Model unloaded from memory.")

    def status(self) -> Dict[str, Any]:
        """Return installation, loading, and integrity status."""
        installed = self.provider.is_available()
        loaded = (self.engine.is_loaded() if self.engine else False) if installed else False
        meta = self.provider.get_metadata()

        return {
            "installed": installed,
            "loaded": loaded,
            "model_dir": str(self.model_dir),
            "model_id": meta.get("model_id", settings.default_model_id),
            "quantization": meta.get("quantization", "int8"),
            "version": meta.get("version", "1.0.0"),
            "checksum_valid": self.verify() if installed else False,
            "message": None if installed else self.MISSING_MODEL_MESSAGE,
        }

    def capabilities(self) -> Dict[str, Any]:
        """Return full system capabilities, supported languages, and hardware."""
        self._hardware = HardwareDetector.detect()
        status_info = self.status()

        return {
            "model_status": status_info,
            "hardware": self._hardware.to_dict(),
            "supported_languages": [
                {"code": code, "name": info["name"], "iso": info["iso"]}
                for code, info in UI_LANGUAGES.items()
            ],
            "profiles": ["fast", "quality"],
            "features": {
                "dynamic_batching": True,
                "async_jobs": True,
                "intelligent_chunking": True,
                "offline_language_detection": True,
            },
        }

    def version(self) -> str:
        """Return model version."""
        meta = self.provider.get_metadata()
        return meta.get("version", "1.0.0")

    def checksum(self, filename: str = "model.bin") -> str:
        """Return SHA-256 of a specific model file."""
        target = self.model_dir / filename
        return self.calculate_checksum(target)
