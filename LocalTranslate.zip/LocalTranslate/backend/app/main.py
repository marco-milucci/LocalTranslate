"""FastAPI application entry point for LocalTranslate."""

import sys
from contextlib import asynccontextmanager
from typing import AsyncGenerator
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from .api.routes_capabilities import router as capabilities_router
from .api.routes_health import router as health_router
from .api.routes_jobs import router as jobs_router
from .api.routes_translate import router as translate_router
from .config import settings
from .core.hardware import HardwareDetector
from .core.logging_filter import logger
from .engine.batch_manager import BatchManager
from .engine.ctranslate2_engine import CTranslate2TranslationEngine
from .engine.job_manager import JobManager
from .engine.model_manager import ModelManager, ModelNotInstalledError
from .engine.router import ModelRouter


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan managing hardware detection, resident model loading, and cleanup."""
    logger.info("Initializing LocalTranslate backend...")

    # Hardware detection
    hardware = HardwareDetector.detect()
    app.state.hardware = hardware
    logger.info(
        f"Hardware detected: CPU={hardware.cpu_arch} (cores={hardware.physical_cores}, threads={hardware.logical_threads}) "
        f"RAM={hardware.total_ram_gb:.1f}GB CUDA={hardware.cuda_available} Device={hardware.selected_device} "
        f"Compute={hardware.selected_compute_type}"
    )

    # Initialize translation engine
    engine = CTranslate2TranslationEngine(hardware=hardware)
    app.state.engine = engine

    # Initialize model manager
    model_manager = ModelManager(model_dir=settings.default_model_dir, engine=engine)
    app.state.model_manager = model_manager

    # Initialize batch & job managers
    batch_manager = BatchManager(engine=engine)
    app.state.batch_manager = batch_manager

    job_manager = JobManager(batch_manager=batch_manager)
    app.state.job_manager = job_manager

    # Initialize router
    router = ModelRouter(default_engine=engine, hardware=hardware)
    app.state.router = router

    # Attempt to load resident model if already installed
    if model_manager.provider.is_available():
        try:
            model_manager.load()
            logger.info("Local translation model resident in memory and ready.")
        except Exception as e:
            logger.warning(f"Could not load model on startup: {e}")
    else:
        logger.info(
            "Local model not yet installed. Translation will be available once "
            "install.ps1 / download_and_convert.py is executed."
        )

    yield

    # Shutdown: unload resident model and cleanup workers
    logger.info("Shutting down LocalTranslate backend...")
    if hasattr(app.state, "job_manager") and app.state.job_manager:
        app.state.job_manager.executor.shutdown(wait=False)
    if hasattr(app.state, "model_manager") and app.state.model_manager:
        app.state.model_manager.unload()
    logger.info("LocalTranslate backend stopped cleanly.")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        version=settings.version,
        description="Local, offline translation backend listening strictly on 127.0.0.1",
        lifespan=lifespan,
    )

    # Configure CORS for browser extensions and localhost
    app.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r"^(chrome-extension://.*|moz-extension://.*|edge-extension://.*|http://127\.0\.0\.1(:\d+)?|http://localhost(:\d+)?)$",
        allow_credentials=True,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # Register routers
    app.include_router(health_router)
    app.include_router(capabilities_router)
    app.include_router(translate_router)
    app.include_router(jobs_router)

    return app


app = create_app()


def main() -> None:
    """CLI entry point to launch the local backend."""
    logger.info(f"Starting LocalTranslate server on {settings.host}:{settings.port}...")
    uvicorn.run(
        "backend.app.main:app",
        host=settings.host,
        port=settings.port,
        reload=False,
        log_level="info",
        access_log=True,
    )


if __name__ == "__main__":
    main()
