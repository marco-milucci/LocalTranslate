"""LocalTranslate: Privacy-first offline translation utility for Windows 10/11."""

__version__ = "1.0.0"
