"""Strict privacy-preserving logging configuration and filters."""

import logging
import re
from typing import Any


class PrivacyLogFilter(logging.Filter):
    """Logging filter ensuring NO user text, translations, cookies, or sensitive query strings appear in logs."""

    # Regex to sanitize query strings from URLs in access logs
    QUERY_PARAM_REGEX = re.compile(r"(\?[^\s\"'>]+)")

    def filter(self, record: logging.LogRecord) -> bool:
        # Sanitize query parameters in access log messages (e.g. GET /foo?bar=123)
        if isinstance(record.msg, str):
            record.msg = self.QUERY_PARAM_REGEX.sub("?[REDACTED_QUERY]", record.msg)

        if record.args:
            # Check args for tuple/dict strings containing query params
            sanitized_args = []
            for arg in record.args if isinstance(record.args, tuple) else [record.args]:
                if isinstance(arg, str):
                    arg = self.QUERY_PARAM_REGEX.sub("?[REDACTED_QUERY]", arg)
                sanitized_args.append(arg)
            record.args = tuple(sanitized_args) if isinstance(record.args, tuple) else sanitized_args[0]

        return True


def setup_privacy_logging(level: int = logging.INFO) -> logging.Logger:
    """Configure system-wide privacy-safe logger."""
    logger = logging.getLogger("localtranslate")
    logger.setLevel(level)

    # Avoid duplicate handlers if reconfigured
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            fmt="[%(asctime)s] [%(levelname)s] [LocalTranslate] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        handler.addFilter(PrivacyLogFilter())
        logger.addHandler(handler)

    # Apply privacy filter to uvicorn access logs
    for uvicorn_logger_name in ("uvicorn", "uvicorn.access", "uvicorn.error"):
        uv_logger = logging.getLogger(uvicorn_logger_name)
        uv_logger.addFilter(PrivacyLogFilter())

    return logger


logger = setup_privacy_logging()


def log_translation_metric(
    duration_ms: float,
    characters: int,
    chunks: int,
    device: str,
    compute_type: str,
    profile: str,
) -> None:
    """Log ONLY technical metadata for a translation event."""
    logger.info(
        f"Event=TRANSLATE duration_ms={duration_ms:.1f} chars={characters} chunks={chunks} "
        f"device={device} compute_type={compute_type} profile={profile}"
    )


def log_job_metric(
    job_id: str,
    event: str,
    duration_ms: float | None = None,
    chunks: int | None = None,
    characters: int | None = None,
) -> None:
    """Log ONLY technical metadata for an async translation job."""
    msg = f"Event=JOB_{event.upper()} job_id={job_id}"
    if chunks is not None:
        msg += f" chunks={chunks}"
    if characters is not None:
        msg += f" chars={characters}"
    if duration_ms is not None:
        msg += f" duration_ms={duration_ms:.1f}"
    logger.info(msg)
