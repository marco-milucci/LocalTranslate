"""Core functionality for LocalTranslate: hardware, chunking, privacy logging, language."""
