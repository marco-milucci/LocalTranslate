import os
import platform
from dataclasses import dataclass
from typing import Any
import psutil

try:
    import ctranslate2
    CTRANSLATE2_AVAILABLE = True
except ImportError:
    ctranslate2 = None
    CTRANSLATE2_AVAILABLE = False


@dataclass
class HardwareProfile:
    """Hardware profile representation."""
    cpu_arch: str
    physical_cores: int
    logical_threads: int
    total_ram_gb: float
    available_ram_gb: float
    cuda_available: bool
    cuda_device_count: int
    cuda_device_name: str | None
    selected_device: str
    selected_compute_type: str
    supported_compute_types: list[str]
    inter_threads: int
    intra_threads: int
    max_recommended_batch_size: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "cpu_arch": self.cpu_arch,
            "physical_cores": self.physical_cores,
            "logical_threads": self.logical_threads,
            "total_ram_gb": round(self.total_ram_gb, 2),
            "available_ram_gb": round(self.available_ram_gb, 2),
            "cuda_available": self.cuda_available,
            "cuda_device_count": self.cuda_device_count,
            "cuda_device_name": self.cuda_device_name,
            "selected_device": self.selected_device,
            "selected_compute_type": self.selected_compute_type,
            "supported_compute_types": self.supported_compute_types,
            "inter_threads": self.inter_threads,
            "intra_threads": self.intra_threads,
            "max_recommended_batch_size": self.max_recommended_batch_size,
        }


class HardwareDetector:
    """Detects system hardware and computes optimal CTranslate2 execution parameters."""

    @staticmethod
    def detect() -> HardwareProfile:
        cpu_arch = platform.machine() or "unknown"
        logical_threads = psutil.cpu_count(logical=True) or os.cpu_count() or 4
        physical_cores = psutil.cpu_count(logical=False) or max(1, logical_threads // 2)

        mem = psutil.virtual_memory()
        total_ram_gb = mem.total / (1024 ** 3)
        available_ram_gb = mem.available / (1024 ** 3)

        cuda_available = False
        cuda_device_count = 0
        cuda_device_name = None

        if CTRANSLATE2_AVAILABLE:
            try:
                cuda_device_count = ctranslate2.get_cuda_device_count()
                cuda_available = cuda_device_count > 0
                if cuda_available:
                    # In Windows/Linux CUDA environments
                    cuda_device_name = f"NVIDIA CUDA Device 0 ({cuda_device_count} total)"
            except Exception:
                cuda_available = False
                cuda_device_count = 0

        # Choose execution device
        if cuda_available:
            selected_device = "cuda"
        else:
            selected_device = "cpu"

        # Determine compute types
        supported_compute_types: list[str] = []
        if CTRANSLATE2_AVAILABLE:
            try:
                types_set = ctranslate2.get_supported_compute_types(selected_device)
                supported_compute_types = sorted(list(types_set))
            except Exception:
                supported_compute_types = ["int8", "float32"] if selected_device == "cpu" else ["float16", "int8_float16"]
        else:
            supported_compute_types = ["int8", "float32"]

        # Optimal compute type selection
        if selected_device == "cuda":
            if "int8_float16" in supported_compute_types:
                selected_compute_type = "int8_float16"
            elif "float16" in supported_compute_types:
                selected_compute_type = "float16"
            elif "int8" in supported_compute_types:
                selected_compute_type = "int8"
            else:
                selected_compute_type = "float32"
        else:
            # CPU
            if "int8_float32" in supported_compute_types:
                selected_compute_type = "int8_float32"
            elif "int8" in supported_compute_types:
                selected_compute_type = "int8"
            else:
                selected_compute_type = "float32"

        # Thread sizing to prevent oversubscription
        # Rule: inter_threads * intra_threads <= physical_cores
        if selected_device == "cuda":
            inter_threads = 1
            intra_threads = min(4, max(1, physical_cores))
            max_batch = 32 if available_ram_gb >= 8.0 else 16
        else:
            if physical_cores >= 8:
                intra_threads = 4
                inter_threads = max(1, physical_cores // 4)
            elif physical_cores >= 4:
                intra_threads = 2
                inter_threads = max(1, physical_cores // 2)
            else:
                intra_threads = max(1, physical_cores)
                inter_threads = 1

            if available_ram_gb >= 16.0:
                max_batch = 32
            elif available_ram_gb >= 8.0:
                max_batch = 16
            else:
                max_batch = 8

        return HardwareProfile(
            cpu_arch=cpu_arch,
            physical_cores=physical_cores,
            logical_threads=logical_threads,
            total_ram_gb=total_ram_gb,
            available_ram_gb=available_ram_gb,
            cuda_available=cuda_available,
            cuda_device_count=cuda_device_count,
            cuda_device_name=cuda_device_name,
            selected_device=selected_device,
            selected_compute_type=selected_compute_type,
            supported_compute_types=supported_compute_types,
            inter_threads=inter_threads,
            intra_threads=intra_threads,
            max_recommended_batch_size=max_batch,
        )
