"""Translation profile configurations (Fast vs Quality)."""

from dataclasses import dataclass
from typing import Literal

ProfileType = Literal["fast", "quality"]


@dataclass
class ProfileConfig:
    name: ProfileType
    description: str
    beam_size: int
    batch_size: int
    max_decoding_length: int
    patience: float
    repetition_penalty: float
    length_penalty: float
    num_hypotheses: int


PROFILES: dict[ProfileType, ProfileConfig] = {
    "fast": ProfileConfig(
        name="fast",
        description="Massima velocità, batch aggressivo, greedy/beam ridotto, INT8, throughput elevato.",
        beam_size=1,
        batch_size=16,
        max_decoding_length=256,
        patience=1.0,
        repetition_penalty=1.05,
        length_penalty=1.0,
        num_hypotheses=1,
    ),
    "quality": ProfileConfig(
        name="quality",
        description="Massima qualità disponibile, beam search estesa, batch conservativo.",
        beam_size=4,
        batch_size=4,
        max_decoding_length=512,
        patience=1.2,
        repetition_penalty=1.1,
        length_penalty=1.0,
        num_hypotheses=1,
    ),
}


def get_profile(name: str = "fast") -> ProfileConfig:
    """Retrieve profile config by name with default fallback to fast."""
    clean = (name or "fast").lower().strip()
    return PROFILES.get(clean, PROFILES["fast"])
