"""100% offline local language detector with confidence scoring."""

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class DetectionResult:
    language: Optional[str]
    confidence: float
    is_reliable: bool
    message: Optional[str] = None


class LocalLanguageDetector:
    """Local, offline language detection based on character scripts and n-gram/stopword frequencies.
    
    Zero remote network calls.
    """

    MIN_CONFIDENCE_THRESHOLD = 0.60
    MIN_TEXT_LENGTH = 4

    # Script regexes
    RE_ARABIC = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]")
    RE_JAPANESE = re.compile(r"[\u3040-\u309F\u30A0-\u30FF]")  # Hiragana & Katakana
    RE_KOREAN = re.compile(r"[\uAC00-\uD7AF\u1100-\u11FF]")    # Hangul
    RE_CHINESE = re.compile(r"[\u4E00-\u9FFF]")                # Hanzi
    RE_CYRILLIC = re.compile(r"[\u0400-\u04FF]")

    # Ukrainian-specific letters: і, ї, є, ґ
    RE_UKRAINIAN_EXCLUSIVE = re.compile(r"[іїєґІЇЄҐ]")
    # Russian-specific letters: ы, э, ъ, ё
    RE_RUSSIAN_EXCLUSIVE = re.compile(r"[ыэъёЫЭЪЁ]")

    # Common distinctive stopwords for Latin script languages
    STOPWORDS = {
        "ita_Latn": {
            "il", "lo", "la", "i", "gli", "le", "un", "uno", "una",
            "di", "a", "da", "in", "con", "su", "per", "tra", "fra",
            "che", "non", "sono", "questo", "questa", "anche", "come", "della", "degli"
        },
        "eng_Latn": {
            "the", "be", "to", "of", "and", "a", "in", "that", "have",
            "it", "for", "not", "on", "with", "as", "you", "do", "at",
            "this", "but", "his", "from", "they", "we", "say", "her", "she", "or", "an"
        },
        "fra_Latn": {
            "le", "la", "les", "un", "une", "des", "du", "de", "et", "est",
            "dans", "en", "que", "qui", "pour", "pas", "sur", "ce", "cette",
            "avec", "sont", "plus", "par", "mais", "nous", "vous"
        },
        "deu_Latn": {
            "der", "die", "das", "und", "ist", "in", "den", "von", "zu",
            "mit", "sich", "des", "auf", "für", "ist", "im", "dem", "nicht",
            "ein", "eine", "einer", "als", "auch", "es", "an", "werden", "aus"
        },
        "spa_Latn": {
            "el", "la", "los", "las", "un", "una", "unos", "unas", "de",
            "en", "que", "y", "a", "por", "para", "con", "no", "es", "son",
            "como", "este", "esta", "del", "al", "pero", "sus"
        },
        "por_Latn": {
            "o", "a", "os", "as", "um", "uma", "uns", "umas", "de", "em",
            "que", "e", "para", "com", "não", "é", "são", "como", "este",
            "esta", "do", "da", "dos", "das", "pelo", "pela"
        },
        "nld_Latn": {
            "de", "het", "een", "en", "van", "ik", "te", "dat", "die", "in",
            "is", "niet", "op", "aan", "met", "voor", "er", "maar", "om", "ook"
        },
        "pol_Latn": {
            "w", "z", "i", "na", "do", "nie", "się", "to", "o", "że", "jak",
            "dla", "od", "ale", "po", "tak", "jego", "jej", "jest", "są"
        },
    }

    @classmethod
    def detect(cls, text: str) -> DetectionResult:
        """Detect language offline. Returns DetectionResult with confidence."""
        if not text or len(text.strip()) < cls.MIN_TEXT_LENGTH:
            return DetectionResult(
                language=None,
                confidence=0.0,
                is_reliable=False,
                message="Testo troppo breve per rilevare la lingua in modo affidabile."
            )

        clean = text.strip()
        total_len = len(clean)

        # 1. Non-Latin scripts check
        # Japanese (Hiragana/Katakana)
        jp_chars = len(cls.RE_JAPANESE.findall(clean))
        if jp_chars > 0 and jp_chars / total_len > 0.05:
            conf = min(0.99, max(0.70, (jp_chars / total_len) * 3))
            return DetectionResult(language="jpn_Jpan", confidence=conf, is_reliable=conf >= cls.MIN_CONFIDENCE_THRESHOLD)

        # Korean
        kr_chars = len(cls.RE_KOREAN.findall(clean))
        if kr_chars > 0 and kr_chars / total_len > 0.05:
            conf = min(0.99, max(0.70, (kr_chars / total_len) * 3))
            return DetectionResult(language="kor_Hang", confidence=conf, is_reliable=conf >= cls.MIN_CONFIDENCE_THRESHOLD)

        # Chinese (Hanzi without Japanese Kana)
        zh_chars = len(cls.RE_CHINESE.findall(clean))
        if zh_chars > 0 and zh_chars / total_len > 0.10:
            conf = min(0.99, max(0.70, (zh_chars / total_len) * 2))
            return DetectionResult(language="zho_Hans", confidence=conf, is_reliable=conf >= cls.MIN_CONFIDENCE_THRESHOLD)

        # Arabic
        ar_chars = len(cls.RE_ARABIC.findall(clean))
        if ar_chars > 0 and ar_chars / total_len > 0.10:
            conf = min(0.99, max(0.70, (ar_chars / total_len) * 2))
            return DetectionResult(language="arb_Arab", confidence=conf, is_reliable=conf >= cls.MIN_CONFIDENCE_THRESHOLD)

        # Cyrillic
        cyrillic_chars = len(cls.RE_CYRILLIC.findall(clean))
        if cyrillic_chars > 0 and cyrillic_chars / total_len > 0.15:
            # Differentiate Ukrainian vs Russian
            ukr_markers = len(cls.RE_UKRAINIAN_EXCLUSIVE.findall(clean))
            rus_markers = len(cls.RE_RUSSIAN_EXCLUSIVE.findall(clean))
            if ukr_markers > rus_markers:
                return DetectionResult(language="ukr_Cyrl", confidence=0.88, is_reliable=True)
            elif rus_markers > ukr_markers:
                return DetectionResult(language="rus_Cyrl", confidence=0.88, is_reliable=True)
            else:
                return DetectionResult(language="rus_Cyrl", confidence=0.75, is_reliable=True)

        # 2. Latin script word token matching
        words = re.findall(r"\b[a-zA-Zàèéìòùáéíóúäöüßñçãõâêîôû'’]+\b", clean.lower())
        if not words:
            return DetectionResult(
                language=None,
                confidence=0.0,
                is_reliable=False,
                message="Nessun termine linguistico riconoscibile trovato."
            )

        scores: dict[str, float] = {lang: 0.0 for lang in cls.STOPWORDS}
        for word in words:
            for lang, sw in cls.STOPWORDS.items():
                if word in sw:
                    scores[lang] += 1.0

        best_lang = max(scores, key=scores.get)
        best_score = scores[best_lang]

        if best_score == 0:
            return DetectionResult(
                language=None,
                confidence=0.0,
                is_reliable=False,
                message="Lingua sorgente non identificata con certezza. Selezionala manualmente."
            )

        total_words = len(words)
        ratio = best_score / total_words

        # Compute separation margin over 2nd best
        sorted_scores = sorted(scores.values(), reverse=True)
        margin = (sorted_scores[0] - sorted_scores[1]) if len(sorted_scores) > 1 else sorted_scores[0]

        # Calculate confidence
        confidence = min(0.98, round(0.40 + (ratio * 0.40) + min(0.20, margin * 0.05), 2))

        if confidence < cls.MIN_CONFIDENCE_THRESHOLD:
            return DetectionResult(
                language=None,
                confidence=confidence,
                is_reliable=False,
                message=f"Riconoscimento ambiguo (confidenza {int(confidence*100)}%). Seleziona la lingua manualmente."
            )

        return DetectionResult(
            language=best_lang,
            confidence=confidence,
            is_reliable=True
        )
