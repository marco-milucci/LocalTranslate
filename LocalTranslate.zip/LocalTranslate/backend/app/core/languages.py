"""NLLB-200 language codes and mapping utilities."""

# Common UI language mapping
UI_LANGUAGES = {
    "ita_Latn": {"name": "Italiano", "iso": "it", "flag": "🇮🇹"},
    "eng_Latn": {"name": "English", "iso": "en", "flag": "🇬🇧"},
    "fra_Latn": {"name": "Français", "iso": "fr", "flag": "🇫🇷"},
    "deu_Latn": {"name": "Deutsch", "iso": "de", "flag": "🇩🇪"},
    "spa_Latn": {"name": "Español", "iso": "es", "flag": "🇪🇸"},
    "por_Latn": {"name": "Português", "iso": "pt", "flag": "🇵🇹"},
    "nld_Latn": {"name": "Nederlands", "iso": "nl", "flag": "🇳🇱"},
    "pol_Latn": {"name": "Polski", "iso": "pl", "flag": "🇵🇱"},
    "rus_Cyrl": {"name": "Русский", "iso": "ru", "flag": "🇷🇺"},
    "ukr_Cyrl": {"name": "Українська", "iso": "uk", "flag": "🇺🇦"},
    "zho_Hans": {"name": "中文 (Semplificato)", "iso": "zh", "flag": "🇨🇳"},
    "zho_Hant": {"name": "中文 (Tradizionale)", "iso": "zh-tw", "flag": "🇹🇼"},
    "jpn_Jpan": {"name": "日本語", "iso": "ja", "flag": "🇯🇵"},
    "kor_Hang": {"name": "한국어", "iso": "ko", "flag": "🇰🇷"},
    "arb_Arab": {"name": "العربية", "iso": "ar", "flag": "🇸🇦"},
}

# ISO 639-1 / 2 code to default NLLB-200 mapping
ISO_TO_NLLB = {
    "it": "ita_Latn",
    "ita": "ita_Latn",
    "en": "eng_Latn",
    "eng": "eng_Latn",
    "fr": "fra_Latn",
    "fra": "fra_Latn",
    "de": "deu_Latn",
    "deu": "deu_Latn",
    "es": "spa_Latn",
    "spa": "spa_Latn",
    "pt": "por_Latn",
    "por": "por_Latn",
    "nl": "nld_Latn",
    "nld": "nld_Latn",
    "pl": "pol_Latn",
    "pol": "pol_Latn",
    "ru": "rus_Cyrl",
    "rus": "rus_Cyrl",
    "uk": "ukr_Cyrl",
    "ukr": "ukr_Cyrl",
    "zh": "zho_Hans",
    "zho": "zho_Hans",
    "ja": "jpn_Jpan",
    "jpn": "jpn_Jpan",
    "ko": "kor_Hang",
    "kor": "kor_Hang",
    "ar": "arb_Arab",
    "ara": "arb_Arab",
}


def normalize_language_code(code: str) -> str:
    """Normalize any user/ISO/NLLB language string to standard NLLB format."""
    clean = code.strip().replace("-", "_")
    if clean.lower() == "auto":
        return "auto"

    # Already valid NLLB code?
    if "_" in clean and len(clean) >= 7:
        parts = clean.split("_")
        if len(parts) == 2 and len(parts[0]) == 3 and len(parts[1]) == 4:
            return f"{parts[0].lower()}_{parts[1].capitalize()}"

    # Try ISO lookup
    iso_key = clean.lower()
    if iso_key in ISO_TO_NLLB:
        return ISO_TO_NLLB[iso_key]

    # Return as-is if unrecognized, letting NLLB tokenizer validate or reject
    return clean


def get_language_display_name(code: str) -> str:
    """Return friendly display name for language code."""
    norm = normalize_language_code(code)
    if norm in UI_LANGUAGES:
        return UI_LANGUAGES[norm]["name"]
    return code


def is_supported_language(code: str) -> bool:
    """Check if code is in known UI languages or matches NLLB format."""
    norm = normalize_language_code(code)
    if norm in UI_LANGUAGES:
        return True
    # General NLLB code format: 3 letters language + '_' + 4 letters script
    parts = norm.split("_")
    return len(parts) == 2 and len(parts[0]) == 3 and len(parts[1]) == 4
