"""Intelligent text chunker preserving paragraphs, URLs, code, emails, and layout."""

import re
from dataclasses import dataclass
from typing import List


@dataclass
class TextChunk:
    chunk_id: int
    paragraph_idx: int
    text: str
    prefix_ws: str = ""
    suffix_ws: str = ""
    is_translatable: bool = True


class IntelligentChunker:
    """Intelligently splits large text into translation units while preserving document structure.
    
    Protects:
    - Paragraphs and empty lines (\n\n)
    - Sentence boundaries
    - URLs (http://, https://)
    - Email addresses
    - Code blocks and inline code
    - Numbers and decimals (e.g. 3.14)
    - Common abbreviations (Dr., e.g., i.e., vs., etc.)
    """

    DEFAULT_MAX_CHUNK_CHARS = 400

    # Common abbreviations to prevent false sentence splits
    ABBREVIATIONS = (
        r"\b(?:e\.g|i\.e|etc|vs|dr|mr|mrs|ms|prof|fig|tab|sig|dott|avv|ing)\."
    )

    # Patterns to preserve without splitting
    URL_PATTERN = re.compile(r"https?://[^\s<>\"']+|www\.[^\s<>\"']+")
    EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b")
    CODE_BLOCK_PATTERN = re.compile(r"```[\s\S]*?```|`[^`\n]+`")

    @classmethod
    def chunk_text(cls, text: str, max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS) -> List[TextChunk]:
        """Split text into an ordered list of TextChunk objects."""
        if not text:
            return []

        chunks: List[TextChunk] = []
        chunk_id = 0

        # Split into paragraphs preserving blank lines
        # We split by double or multiple newlines
        raw_paragraphs = re.split(r"(\r?\n\s*\r?\n)", text)

        for p_idx, part in enumerate(raw_paragraphs):
            # Check if this part is just paragraph separator (whitespace/newlines)
            if re.fullmatch(r"(\r?\n\s*\r?\n)", part) or not part:
                chunks.append(
                    TextChunk(
                        chunk_id=chunk_id,
                        paragraph_idx=p_idx,
                        text=part,
                        is_translatable=False,
                    )
                )
                chunk_id += 1
                continue

            # Process actual paragraph content
            para_chunks = cls._split_paragraph(part, p_idx, chunk_id, max_chunk_chars)
            chunks.extend(para_chunks)
            chunk_id += len(para_chunks)

        return chunks

    @classmethod
    def _split_paragraph(
        cls, paragraph: str, p_idx: int, start_chunk_id: int, max_chars: int
    ) -> List[TextChunk]:
        """Split a single paragraph into sentences/chunks."""
        # Check if entire paragraph fits in one chunk
        trimmed = paragraph.strip()
        if not trimmed:
            return [
                TextChunk(
                    chunk_id=start_chunk_id,
                    paragraph_idx=p_idx,
                    text=paragraph,
                    is_translatable=False,
                )
            ]

        # Extract leading and trailing whitespace of the paragraph
        leading_ws = paragraph[: len(paragraph) - len(paragraph.lstrip())]
        trailing_ws = paragraph[len(paragraph.rstrip()) :]

        # If it's a code block or URL alone, keep intact
        if cls.CODE_BLOCK_PATTERN.fullmatch(trimmed) or cls.URL_PATTERN.fullmatch(trimmed):
            return [
                TextChunk(
                    chunk_id=start_chunk_id,
                    paragraph_idx=p_idx,
                    text=trimmed,
                    prefix_ws=leading_ws,
                    suffix_ws=trailing_ws,
                    is_translatable=not cls.URL_PATTERN.fullmatch(trimmed),
                )
            ]

        if len(trimmed) <= max_chars:
            return [
                TextChunk(
                    chunk_id=start_chunk_id,
                    paragraph_idx=p_idx,
                    text=trimmed,
                    prefix_ws=leading_ws,
                    suffix_ws=trailing_ws,
                    is_translatable=True,
                )
            ]

        # Paragraph needs sentence splitting
        sentences = cls._split_into_sentences(trimmed)
        result: List[TextChunk] = []
        current_chunk = ""
        current_id = start_chunk_id

        for s_idx, sent in enumerate(sentences):
            sent_clean = sent.strip()
            if not sent_clean:
                continue

            # If single sentence exceeds max_chars, split on punctuation/clause
            if len(sent_clean) > max_chars:
                if current_chunk:
                    result.append(
                        TextChunk(
                            chunk_id=current_id,
                            paragraph_idx=p_idx,
                            text=current_chunk.strip(),
                            prefix_ws=leading_ws if len(result) == 0 else " ",
                            suffix_ws="",
                            is_translatable=True,
                        )
                    )
                    current_id += 1
                    current_chunk = ""

                sub_chunks = cls._split_long_sentence(sent_clean, max_chars)
                for sc in sub_chunks:
                    result.append(
                        TextChunk(
                            chunk_id=current_id,
                            paragraph_idx=p_idx,
                            text=sc.strip(),
                            prefix_ws=leading_ws if len(result) == 0 else " ",
                            suffix_ws="",
                            is_translatable=True,
                        )
                    )
                    current_id += 1
                continue

            # Group sentences up to max_chars
            if current_chunk and (len(current_chunk) + len(sent_clean) + 1 > max_chars):
                result.append(
                    TextChunk(
                        chunk_id=current_id,
                        paragraph_idx=p_idx,
                        text=current_chunk.strip(),
                        prefix_ws=leading_ws if len(result) == 0 else " ",
                        suffix_ws="",
                        is_translatable=True,
                    )
                )
                current_id += 1
                current_chunk = sent_clean
            else:
                if current_chunk:
                    current_chunk += " " + sent_clean
                else:
                    current_chunk = sent_clean

        if current_chunk:
            result.append(
                TextChunk(
                    chunk_id=current_id,
                    paragraph_idx=p_idx,
                    text=current_chunk.strip(),
                    prefix_ws=leading_ws if len(result) == 0 else " ",
                    suffix_ws=trailing_ws,
                    is_translatable=True,
                )
            )

        if result:
            result[-1].suffix_ws = trailing_ws

        return result

    @classmethod
    def _split_into_sentences(cls, text: str) -> List[str]:
        """Split text into sentences without breaking abbreviations, decimals, or URLs."""
        # Protect URLs by masking them temporarily
        urls: List[str] = []

        def mask_url(m):
            urls.append(m.group(0))
            return f"__URL_TOKEN_{len(urls)-1}__"

        masked = cls.URL_PATTERN.sub(mask_url, text)

        # Protect emails
        emails: List[str] = []

        def mask_email(m):
            emails.append(m.group(0))
            return f"__EMAIL_TOKEN_{len(emails)-1}__"

        masked = cls.EMAIL_PATTERN.sub(mask_email, masked)

        # Split on sentence boundaries: punctuation followed by space and uppercase/quote
        # Negative lookbehinds for abbreviations and numbers
        pattern = r"(?<=[.!?])\s+(?=[A-Z0-9\"'«“\n])"
        parts = re.split(pattern, masked)

        # Unmask URLs and emails
        restored = []
        for part in parts:
            p = part
            for i, u in enumerate(urls):
                p = p.replace(f"__URL_TOKEN_{i}__", u)
            for i, e in enumerate(emails):
                p = p.replace(f"__EMAIL_TOKEN_{i}__", e)
            restored.append(p)

        return restored

    @classmethod
    def _split_long_sentence(cls, sentence: str, max_chars: int) -> List[str]:
        """Split an overly long sentence on clauses (;, :, commas) or words."""
        clauses = re.split(r"(?<=[;,])\s+", sentence)
        chunks: List[str] = []
        cur = ""
        for clause in clauses:
            if cur and (len(cur) + len(clause) + 1 > max_chars):
                chunks.append(cur)
                cur = clause
            else:
                cur = (cur + " " + clause).strip() if cur else clause

        if cur:
            chunks.append(cur)
        return chunks if chunks else [sentence]
