"""Text reconstructor restoring original formatting, whitespaces, and paragraphs."""

from typing import Dict, List
from .chunker import TextChunk


class TextReconstructor:
    """Reconstructs translated text from chunks, maintaining exact formatting and ordering."""

    @staticmethod
    def reconstruct(
        original_chunks: List[TextChunk],
        translated_chunks_map: Dict[int, str],
    ) -> str:
        """Reconstruct the full translated text in original sequential order."""
        if not original_chunks:
            return ""

        # Sort chunks strictly by chunk_id to ensure order preservation
        sorted_chunks = sorted(original_chunks, key=lambda c: c.chunk_id)

        output_parts: List[str] = []

        for chunk in sorted_chunks:
            if not chunk.is_translatable:
                # Raw separator or un-translatable segment
                output_parts.append(chunk.text)
            else:
                # Get translated text or fallback to original text if missing
                trans_text = translated_chunks_map.get(chunk.chunk_id, chunk.text)
                formatted = f"{chunk.prefix_ws}{trans_text}{chunk.suffix_ws}"
                output_parts.append(formatted)

        return "".join(output_parts)
