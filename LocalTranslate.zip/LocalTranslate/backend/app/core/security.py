"""Security guards, input validation, and sanitization."""

import html
import re
from fastapi import HTTPException, status
from ..config import settings


class SecurityValidator:
    """Validates inputs to prevent injection, resource exhaustion, and path traversal."""

    # Disallowed command execution / shell syntax patterns
    SHELL_INJECTION_PATTERN = re.compile(r"(\||;|`|\$\(|\$\{)")
    # Disallowed path traversal patterns
    PATH_TRAVERSAL_PATTERN = re.compile(r"(\.\./|\.\.\\)")

    @classmethod
    def validate_text_input(cls, text: str) -> str:
        """Validate user input text size and characteristics."""
        if text is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Input text cannot be null."
            )

        if len(text) > settings.max_input_characters:
            raise HTTPException(
                status_code=getattr(status, "HTTP_413_CONTENT_TOO_LARGE", 413),
                detail=f"Input text exceeds maximum allowed limit of {settings.max_input_characters} characters."
            )

        return text

    @classmethod
    def sanitize_ui_output(cls, text: str) -> str:
        """Sanitize text for safe rendering in browser HTML/DOM."""
        if not text:
            return ""
        return html.escape(text, quote=True)

    @classmethod
    def validate_safe_filename(cls, filename: str) -> str:
        """Verify filename does not contain path traversal or unsafe characters."""
        if cls.PATH_TRAVERSAL_PATTERN.search(filename):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file path or path traversal detected."
            )
        return filename
