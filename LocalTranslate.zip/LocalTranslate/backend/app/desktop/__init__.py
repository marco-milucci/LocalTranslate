"""Desktop module for LocalTranslate: global hotkeys, floating quick HUD, system tray."""
