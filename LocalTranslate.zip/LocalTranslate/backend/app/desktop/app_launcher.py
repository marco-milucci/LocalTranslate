"""Main desktop application launcher combining background server, tray, hotkey, and HUD."""

import os
import signal
import sys
import threading
import time
import urllib.request
import json
from pathlib import Path
from typing import Optional

# Setup import path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.config import settings
from backend.app.core.logging_filter import logger
from backend.app.desktop.hotkey import GlobalHotkeyListener, capture_active_selection, get_clipboard_text
from backend.app.desktop.quick_hud import QuickTranslationHUD
from backend.app.desktop.tray import SystemTrayApp


class LocalTranslateDesktopApp:
    """Universal desktop application runner for Windows."""

    def __init__(self, port: int = 8765):
        self.port = port
        self.hud = QuickTranslationHUD()
        self.profile = "fast"
        self._running = False
        self._server_thread: Optional[threading.Thread] = None

        icon_path = PROJECT_ROOT / "assets" / "LocalTranslate.ico"
        self.tray = SystemTrayApp(
            on_translate_selection=self.translate_selection,
            on_translate_clipboard=self.translate_clipboard,
            on_exit=self.shutdown,
            icon_path=icon_path,
        )
        self.hotkey_listener = GlobalHotkeyListener(callback=self._handle_captured_text)

    def is_server_alive(self) -> bool:
        """Check if local backend is responding on localhost."""
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}/health")
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                return resp.status == 200
        except Exception:
            return False

    def start_background_server(self) -> None:
        """Run uvicorn server in background thread if not already running."""
        if self.is_server_alive():
            logger.info("LocalTranslate server already running on 127.0.0.1:%s", self.port)
            return

        def run_uvicorn():
            import uvicorn
            from backend.app.main import app
            config = uvicorn.Config(
                app=app,
                host=settings.host,
                port=self.port,
                log_level="warning",
                access_log=False,
            )
            server = uvicorn.Server(config)
            server.run()

        self._server_thread = threading.Thread(target=run_uvicorn, name="LocalTranslateServerThread", daemon=True)
        self._server_thread.start()

        # Wait for server ready
        for _ in range(30):
            if self.is_server_alive():
                logger.info("LocalTranslate backend server ready on 127.0.0.1:%s", self.port)
                break
            time.sleep(0.1)

    def _handle_captured_text(self, text: str) -> None:
        """Translate captured text and display in floating HUD."""
        clean = text.strip()
        if not clean:
            return

        # Query local backend
        try:
            url = f"http://127.0.0.1:{self.port}/v1/translate"
            payload = json.dumps({
                "text": clean,
                "source_language": "auto",
                "target_language": "ita_Latn",
                "profile": self.tray.profile if hasattr(self, "tray") else "fast",
            }).encode("utf-8")

            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            translation = data.get("translation", "")
            source_lang = data.get("source_language", "auto")
            target_lang = data.get("target_language", "ita_Latn")
            device = data.get("device", "cpu")
            compute_type = data.get("compute_type", "int8")
            duration_ms = data.get("duration_ms", 0.0)

            # Display floating HUD
            self.hud.show(
                original_text=clean,
                translated_text=translation,
                source_lang=source_lang,
                target_lang=target_lang,
                device=device,
                compute_type=compute_type,
                duration_ms=duration_ms,
            )
        except Exception as e:
            logger.error(f"Error during desktop translation: {e}")
            self.hud.show(
                original_text=clean,
                translated_text=f"Errore durante la traduzione: {e}",
                source_lang="auto",
                target_lang="ita_Latn",
                device="errore",
                compute_type="",
                duration_ms=0.0,
            )

    def translate_selection(self) -> None:
        """Trigger capture and translation of active selection."""
        captured = capture_active_selection()
        if captured:
            self._handle_captured_text(captured)

    def translate_clipboard(self) -> None:
        """Trigger translation of current clipboard contents."""
        text = get_clipboard_text()
        if text:
            self._handle_captured_text(text)

    def run(self) -> None:
        """Start all desktop components."""
        self._running = True
        print("[LocalTranslate] Avvio dell'applicazione desktop universale...")

        # 1. Start background server
        self.start_background_server()

        # 2. Start global hotkey listener
        self.hotkey_listener.start()
        print("[LocalTranslate] Scorciatoia globale attiva: Ctrl+Alt+T in qualsiasi programma.")

        # 3. Start System Tray icon
        self.tray.start()
        print("[LocalTranslate] Icona di notifica presente nella System Tray.")

        # Show ready notification
        self.tray.notify(
            "LocalTranslate Attivo",
            "Premi Ctrl+Alt+T su qualsiasi testo selezionato per tradurlo all'istante!"
        )

        # Keep alive
        try:
            while self._running:
                time.sleep(1.0)
        except (KeyboardInterrupt, SystemExit):
            self.shutdown()

    def shutdown(self) -> None:
        """Stop all desktop services and exit."""
        self._running = False
        print("\n[LocalTranslate] Arresto dell'applicazione desktop in corso...")
        self.hotkey_listener.stop()
        self.tray.stop()
        sys.exit(0)


def main():
    app = LocalTranslateDesktopApp()
    app.run()


if __name__ == "__main__":
    main()
