"""Main desktop application launcher combining background server, tray, hotkey, and HUD."""

import json
import os
import signal
import socket
import sys
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any, Dict, Optional

# Setup import path
if getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(sys.executable).resolve().parent
else:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.config import settings
from backend.app.core.chunker import IntelligentChunker
from backend.app.core.hardware import HardwareDetector
from backend.app.core.language_detector import LocalLanguageDetector
from backend.app.core.languages import normalize_language_code
from backend.app.core.logging_filter import logger
from backend.app.core.profiles import get_profile
from backend.app.desktop.hotkey import GlobalHotkeyListener, capture_active_selection, get_clipboard_text
from backend.app.desktop.quick_hud import QuickTranslationHUD
from backend.app.desktop.tray import SystemTrayApp
from backend.app.engine.batch_manager import BatchManager
from backend.app.engine.ctranslate2_engine import CTranslate2TranslationEngine
from backend.app.engine.model_manager import ModelManager, ModelNotInstalledError


def find_available_port(start_port: int = 8765, max_attempts: int = 15) -> int:
    """Find the first available TCP port on 127.0.0.1 starting from start_port."""
    for port in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return start_port


class LocalTranslateDesktopApp:
    """Universal desktop application runner for Windows."""

    def __init__(self, port: Optional[int] = None):
        # Resolve port dynamically to avoid socket collisions (WinError 10061 / 10048)
        if port is not None:
            self.port = port
        else:
            self.port = find_available_port(start_port=8765, max_attempts=15)

        # Persist active port for browser extension and CLI tools
        try:
            port_file = PROJECT_ROOT / ".localtranslate_port"
            port_file.write_text(str(self.port), encoding="utf-8")
        except Exception:
            pass

        self.hud = QuickTranslationHUD()
        self.profile = "fast"
        self._running = False
        self._server_thread: Optional[threading.Thread] = None

        # Direct in-process translation engine for 100% offline desktop hotkeys (0 network sockets)
        self.hardware = HardwareDetector.detect()
        self.engine = CTranslate2TranslationEngine(hardware=self.hardware)
        self.model_manager = ModelManager(model_dir=settings.default_model_dir, engine=self.engine)
        self.batch_manager = BatchManager(engine=self.engine)

        icon_path = PROJECT_ROOT / "assets" / "LocalTranslate.ico"
        if not icon_path.exists():
            alt_icon = PROJECT_ROOT / "_internal" / "assets" / "LocalTranslate.ico"
            if alt_icon.exists():
                icon_path = alt_icon
        self.tray = SystemTrayApp(
            on_translate_selection=self.translate_selection,
            on_translate_clipboard=self.translate_clipboard,
            on_exit=self.shutdown,
            icon_path=icon_path,
        )
        self.hotkey_listener = GlobalHotkeyListener(callback=self._handle_captured_text)

    def is_server_alive(self) -> bool:
        """Check if local backend is responding on localhost."""
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}/health")
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                return resp.status == 200
        except Exception:
            return False

    def start_background_server(self) -> None:
        """Run uvicorn server in background thread if not already running."""
        if self.is_server_alive():
            logger.info("LocalTranslate server already running on 127.0.0.1:%s", self.port)
            return

        def run_uvicorn():
            try:
                import uvicorn
                from backend.app.main import app
                config = uvicorn.Config(
                    app=app,
                    host="127.0.0.1",
                    port=self.port,
                    log_level="warning",
                    access_log=False,
                )
                server = uvicorn.Server(config)
                server.run()
            except Exception as ex:
                logger.error("Uvicorn server error on port %s: %s", self.port, ex)

        self._server_thread = threading.Thread(target=run_uvicorn, name="LocalTranslateServerThread", daemon=True)
        self._server_thread.start()

        # Wait for server ready (up to 8 seconds)
        for _ in range(40):
            if self.is_server_alive():
                logger.info("LocalTranslate backend server ready on 127.0.0.1:%s", self.port)
                break
            time.sleep(0.2)

    def _translate_in_process(
        self,
        text: str,
        source_lang: str = "auto",
        target_lang: str = "ita_Latn",
        profile_name: str = "fast",
    ) -> Dict[str, Any]:
        """Perform instant 100% in-process offline translation without network sockets."""
        if not self.model_manager.provider.is_available():
            raise ModelNotInstalledError("Modello non installato")

        if not self.engine.is_loaded():
            self.model_manager.load()

        profile = get_profile(profile_name)

        detected_lang = None
        confidence = None
        if source_lang.lower() == "auto":
            detection = LocalLanguageDetector.detect(text)
            if detection.is_reliable and detection.language:
                source_lang = detection.language
                detected_lang = detection.language
                confidence = detection.confidence
            else:
                source_lang = "eng_Latn"
        else:
            source_lang = normalize_language_code(source_lang)

        target_lang = normalize_language_code(target_lang)

        t0 = time.perf_counter()
        chunks = IntelligentChunker.chunk_text(text)
        translated_text = self.batch_manager.translate_chunks(
            chunks=chunks,
            source_lang=source_lang,
            target_lang=target_lang,
            profile=profile,
        )
        duration_ms = (time.perf_counter() - t0) * 1000.0
        dev_info = self.engine.get_device_info()

        return {
            "translation": translated_text,
            "source_language": source_lang,
            "target_language": target_lang,
            "device": dev_info.get("device", "cpu"),
            "compute_type": dev_info.get("compute_type", "int8"),
            "duration_ms": duration_ms,
            "detected_language": detected_lang,
            "detection_confidence": confidence,
        }

    def _handle_captured_text(self, text: str) -> None:
        """Translate captured text and display in floating HUD."""
        clean = text.strip()
        if not clean:
            return

        profile_name = self.tray.profile if hasattr(self, "tray") else "fast"

        # Check if model is installed
        if not self.model_manager.provider.is_available():
            self.hud.show(
                original_text=clean,
                translated_text=(
                    "⚠️ Modello locale non ancora installato!\n\n"
                    "LocalTranslate esegue tutte le traduzioni al 100% in locale sul tuo computer (zero cloud, massima privacy).\n\n"
                    "👉 Fai doppio clic sul file:\n"
                    "   '1-INSTALLA-SUBITO.bat'\n"
                    "nella cartella di LocalTranslate per scaricare il modello locale (600 MB) una sola volta."
                ),
                source_lang="auto",
                target_lang="ita_Latn",
                device="info",
                compute_type="guida",
                duration_ms=0.0,
            )
            return

        # 1. Attempt in-process translation first (0 network sockets, completely immune to WinError 10061)
        try:
            res = self._translate_in_process(
                clean,
                source_lang="auto",
                target_lang="ita_Latn",
                profile_name=profile_name,
            )
            self.hud.show(
                original_text=clean,
                translated_text=res["translation"],
                source_lang=res.get("detected_language") or res.get("source_language", "auto"),
                target_lang=res.get("target_language", "ita_Latn"),
                device=res.get("device", "cpu"),
                compute_type=res.get("compute_type", "int8"),
                duration_ms=res.get("duration_ms", 0.0),
            )
            return
        except Exception as in_proc_err:
            logger.warning("In-process translation error: %s. Falling back to HTTP...", in_proc_err)

        # 2. Fallback to local HTTP server
        try:
            url = f"http://127.0.0.1:{self.port}/v1/translate"
            payload = json.dumps({
                "text": clean,
                "source_language": "auto",
                "target_language": "ita_Latn",
                "profile": profile_name,
            }).encode("utf-8")

            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            self.hud.show(
                original_text=clean,
                translated_text=data.get("translation", ""),
                source_lang=data.get("detected_language") or data.get("source_language", "auto"),
                target_lang=data.get("target_language", "ita_Latn"),
                device=data.get("device", "cpu"),
                compute_type=data.get("compute_type", "int8"),
                duration_ms=data.get("duration_ms", 0.0),
            )
        except Exception as e:
            err_str = str(e)
            if "10061" in err_str or "Connection refused" in err_str:
                user_msg = (
                    "⚠️ Impossibile contattare il server locale (127.0.0.1).\n\n"
                    "Possibili cause:\n"
                    "1. L'installazione iniziale non è stata completata. Esegui '1-INSTALLA-SUBITO.bat'.\n"
                    "2. Il server locale è ancora in fase di avvio. Riprova tra pochi secondi."
                )
            else:
                user_msg = f"Errore durante la traduzione: {err_str}"

            logger.error("Error during desktop translation: %s", e)
            self.hud.show(
                original_text=clean,
                translated_text=user_msg,
                source_lang="auto",
                target_lang="ita_Latn",
                device="errore",
                compute_type="",
                duration_ms=0.0,
            )

    def translate_selection(self) -> None:
        """Trigger capture and translation of active selection."""
        captured = capture_active_selection()
        if captured:
            self._handle_captured_text(captured)

    def translate_clipboard(self) -> None:
        """Trigger translation of current clipboard contents."""
        text = get_clipboard_text()
        if text:
            self._handle_captured_text(text)

    def run(self) -> None:
        """Start all desktop components and launch native GUI window."""
        self._running = True
        logger.info("[LocalTranslate] Avvio dell'applicazione desktop...")

        # 1. Start background server on active port
        self.start_background_server()

        # 2. Start global hotkey listener
        self.hotkey_listener.start()
        logger.info("[LocalTranslate] Scorciatoia globale attiva: Ctrl+Alt+T.")

        # 3. Start System Tray icon
        try:
            self.tray.start()
        except Exception as e:
            logger.warning("System tray warning: %s", e)

        # 4. Launch main GUI window on main thread
        self._launch_gui()

    def _launch_gui(self) -> None:
        """Create and run native desktop GUI window on the main thread."""
        try:
            import tkinter as tk
            from tkinter import ttk
        except ImportError:
            # Fallback for environments without Tkinter
            try:
                while self._running:
                    time.sleep(1.0)
            except (KeyboardInterrupt, SystemExit):
                self.shutdown()
            return

        root = tk.Tk()
        self.root = root
        root.title("LocalTranslate • Traduttore Offline 100%")
        root.geometry("680x520")
        root.minsize(550, 420)

        # Style & Colors: Fluent Modern Dark Theme
        bg_main = "#1e1e2e"
        bg_card = "#2a2b3d"
        fg_text = "#f8fafc"
        fg_muted = "#94a3b8"
        accent_blue = "#0284c7"
        accent_hover = "#0369a1"
        accent_green = "#10b981"

        root.configure(bg=bg_main)

        icon_path = PROJECT_ROOT / "assets" / "LocalTranslate.ico"
        if icon_path.exists():
            try:
                root.iconbitmap(str(icon_path))
            except Exception:
                pass

        # Header Frame: Title & Hardware Badge
        header = tk.Frame(root, bg=bg_main)
        header.pack(fill="x", padx=20, pady=(15, 10))

        title_lbl = tk.Label(
            header,
            text="LocalTranslate",
            font=("Segoe UI", 16, "bold"),
            bg=bg_main,
            fg=fg_text,
        )
        title_lbl.pack(side="left")

        dev_name = self.hardware.selected_device.upper()
        comp_type = self.hardware.selected_compute_type.upper()
        dev_badge = f"● Offline • {dev_name} {comp_type}"
        status_lbl = tk.Label(
            header,
            text=dev_badge,
            font=("Segoe UI", 9, "bold"),
            bg="#1e293b",
            fg=accent_green,
            padx=10,
            pady=3,
        )
        status_lbl.pack(side="right")

        # Language Selection Bar
        lang_bar = tk.Frame(root, bg=bg_main)
        lang_bar.pack(fill="x", padx=20, pady=(0, 10))

        tk.Label(lang_bar, text="Da:", font=("Segoe UI", 10), bg=bg_main, fg=fg_muted).pack(side="left", padx=(0, 5))

        lang_choices = [
            "Rileva automaticamente", "Inglese", "Italiano", "Francese", "Spagnolo",
            "Tedesco", "Portoghese", "Russo", "Cinese", "Giapponese", "Arabo"
        ]
        target_choices = [
            "Italiano", "Inglese", "Francese", "Spagnolo", "Tedesco",
            "Portoghese", "Russo", "Cinese", "Giapponese", "Arabo"
        ]

        src_lang_var = tk.StringVar(value="Rileva automaticamente")
        src_combo = ttk.Combobox(
            lang_bar,
            textvariable=src_lang_var,
            values=lang_choices,
            state="readonly",
            width=22,
        )
        src_combo.pack(side="left", padx=(0, 15))

        tk.Label(lang_bar, text="➔   A:", font=("Segoe UI", 10, "bold"), bg=bg_main, fg=accent_blue).pack(side="left", padx=(0, 5))

        tgt_lang_var = tk.StringVar(value="Italiano")
        tgt_combo = ttk.Combobox(
            lang_bar,
            textvariable=tgt_lang_var,
            values=target_choices,
            state="readonly",
            width=18,
        )
        tgt_combo.pack(side="left")

        # Input Frame
        input_frame = tk.Frame(root, bg=bg_main)
        input_frame.pack(fill="both", expand=True, padx=20, pady=(0, 5))

        tk.Label(input_frame, text="Testo da tradurre:", font=("Segoe UI", 10, "bold"), bg=bg_main, fg=fg_text).pack(anchor="w", pady=(0, 3))
        input_txt = tk.Text(
            input_frame,
            bg=bg_card,
            fg=fg_text,
            insertbackground="white",
            font=("Segoe UI", 10),
            relief="flat",
            padx=10,
            pady=8,
            height=5,
        )
        input_txt.pack(fill="both", expand=True)

        # Buttons Bar
        btn_bar = tk.Frame(root, bg=bg_main)
        btn_bar.pack(fill="x", padx=20, pady=8)

        def do_translate():
            raw_text = input_txt.get("1.0", "end-1c").strip()
            if not raw_text:
                return

            if str(translate_btn["state"]) == "disabled":
                return

            translate_btn.config(text="Traduzione in corso...", state="disabled")
            status_lbl.config(text="● Traduzione...", fg="#f59e0b")
            root.update_idletasks()

            def async_task():
                try:
                    lang_map = {
                        "Rileva automaticamente": "auto",
                        "Italiano": "ita_Latn",
                        "Inglese": "eng_Latn",
                        "Francese": "fra_Latn",
                        "Spagnolo": "spa_Latn",
                        "Tedesco": "deu_Latn",
                        "Portoghese": "por_Latn",
                        "Russo": "rus_Cyrl",
                        "Cinese": "zho_Hans",
                        "Giapponese": "jpn_Jpan",
                        "Arabo": "arb_Arab",
                    }
                    s_code = lang_map.get(src_lang_var.get(), "auto")
                    t_code = lang_map.get(tgt_lang_var.get(), "ita_Latn")

                    res = self._translate_in_process(raw_text, source_lang=s_code, target_lang=t_code)
                    translated = res.get("translation", "")
                    dur = res.get("duration_ms", 0.0)

                    def update_ui():
                        output_txt.delete("1.0", "end")
                        output_txt.insert("1.0", translated)
                        dev_info = self.engine.get_device_info()
                        dev_str = f"{dev_info.get('device', 'CPU').upper()} {dev_info.get('compute_type', 'INT8').upper()}"
                        info_lbl.config(text=f"Tempo: {dur:.0f} ms | Dispositivo: {dev_str}")
                        status_lbl.config(text=f"● Offline • {dev_str}", fg=accent_green)
                        translate_btn.config(text="TRADUCI", state="normal")

                    root.after(0, update_ui)
                except Exception as ex:
                    def show_err():
                        output_txt.delete("1.0", "end")
                        output_txt.insert("1.0", f"Errore: {ex}")
                        status_lbl.config(text="● Errore", fg="#ef4444")
                        translate_btn.config(text="TRADUCI", state="normal")
                    root.after(0, show_err)

            threading.Thread(target=async_task, daemon=True, name="TranslateWorker").start()

        translate_btn = tk.Button(
            btn_bar,
            text="TRADUCI",
            font=("Segoe UI", 11, "bold"),
            bg=accent_blue,
            fg="white",
            activebackground=accent_hover,
            activeforeground="white",
            relief="flat",
            padx=20,
            pady=6,
            cursor="hand2",
            command=do_translate,
        )
        translate_btn.pack(side="left")

        def clear_all():
            input_txt.delete("1.0", "end")
            output_txt.delete("1.0", "end")

        clear_btn = tk.Button(
            btn_bar,
            text="Pulisci",
            font=("Segoe UI", 10),
            bg=bg_card,
            fg=fg_text,
            relief="flat",
            padx=15,
            pady=6,
            command=clear_all,
        )
        clear_btn.pack(side="left", padx=10)

        # Output Frame
        output_frame = tk.Frame(root, bg=bg_main)
        output_frame.pack(fill="both", expand=True, padx=20, pady=(0, 5))

        tk.Label(output_frame, text="Traduzione:", font=("Segoe UI", 10, "bold"), bg=bg_main, fg=fg_text).pack(anchor="w", pady=(0, 3))
        output_txt = tk.Text(
            output_frame,
            bg=bg_card,
            fg=fg_text,
            insertbackground="white",
            font=("Segoe UI", 10),
            relief="flat",
            padx=10,
            pady=8,
            height=5,
        )
        output_txt.pack(fill="both", expand=True)

        # Bottom Bar
        bottom_bar = tk.Frame(root, bg=bg_main)
        bottom_bar.pack(fill="x", padx=20, pady=(5, 15))

        def copy_output():
            out_content = output_txt.get("1.0", "end-1c").strip()
            if out_content:
                root.clipboard_clear()
                root.clipboard_append(out_content)
                copy_btn.config(text="✓ Copiato!")
                root.after(1500, lambda: copy_btn.config(text="Copia Traduzione"))

        copy_btn = tk.Button(
            bottom_bar,
            text="Copia Traduzione",
            font=("Segoe UI", 9, "bold"),
            bg="#334155",
            fg="white",
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2",
            command=copy_output,
        )
        copy_btn.pack(side="left")

        info_lbl = tk.Label(
            bottom_bar,
            text="Scorciatoia globale: seleziona un testo e premi Ctrl+Alt+T",
            font=("Segoe UI", 9),
            bg=bg_main,
            fg=fg_muted,
        )
        info_lbl.pack(side="right")

        # Global Hotkey hook to main window: always restore and focus window
        def handle_hotkey(captured_text: str):
            def on_main():
                root.deiconify()
                root.lift()
                root.attributes("-topmost", True)
                root.after_idle(root.attributes, "-topmost", False)
                root.focus_force()
                input_txt.focus_set()

                clean = (captured_text or "").strip()
                if clean:
                    input_txt.delete("1.0", "end")
                    input_txt.insert("1.0", clean)
                    do_translate()
            root.after(0, on_main)

        self._hotkey_gui_handler = handle_hotkey

        # Bind Ctrl+Enter to translate
        input_txt.bind("<Control-Return>", lambda e: do_translate())

        # Preload model in background thread on startup
        def background_preload():
            try:
                if self.model_manager.provider.is_available() and not self.engine.is_loaded():
                    logger.info("Preloading translation model in background...")
                    self.model_manager.load()
                    def on_ready():
                        dev = self.engine.get_device_info()
                        dev_str = f"{dev.get('device', 'CPU').upper()} {dev.get('compute_type', 'INT8').upper()}"
                        status_lbl.config(text=f"● Offline • {dev_str}", fg=accent_green)
                    root.after(0, on_ready)
            except Exception as ex:
                logger.warning("Background preload warning: %s", ex)

        threading.Thread(target=background_preload, daemon=True, name="ModelPreloadThread").start()

        def on_close():
            self.shutdown()
            root.destroy()

        root.protocol("WM_DELETE_WINDOW", on_close)

        root.mainloop()

    def _handle_captured_text(self, text: str) -> None:
        """Route captured hotkey text to GUI or fallback HUD."""
        clean = (text or "").strip()

        if hasattr(self, "_hotkey_gui_handler") and self._hotkey_gui_handler:
            self._hotkey_gui_handler(clean)
            return

        if not clean:
            return

    def shutdown(self) -> None:
        """Stop all desktop services and exit."""
        self._running = False
        logger.info("Arresto dell'applicazione desktop...")
        try:
            self.hotkey_listener.stop()
        except Exception:
            pass
        try:
            self.tray.stop()
        except Exception:
            pass
        if self.engine and self.engine.is_loaded():
            try:
                self.engine.unload()
            except Exception:
                pass


def ensure_single_instance() -> bool:
    """Ensure only one instance runs at a time on Windows, focusing existing instance if found."""
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        kernel32.CreateMutexW(None, False, "LocalTranslate_SingleInstance_Mutex_v1")
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            hwnd = user32.FindWindowW(None, "LocalTranslate • Traduttore Offline 100%")
            if hwnd:
                user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                user32.SetForegroundWindow(hwnd)
            return False
        return True
    except Exception:
        return True


def main():
    if not ensure_single_instance():
        sys.exit(0)
    try:
        app = LocalTranslateDesktopApp()
        app.run()
    except Exception as e:
        import traceback
        log_path = Path("LocalTranslate-Crash.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n--- CRASH {time.ctime()} ---\n")
            f.write(traceback.format_exc())
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(
                    0,
                    f"Errore all'avvio di LocalTranslate:\n{e}\n\nI dettagli sono nel file LocalTranslate-Crash.log",
                    "LocalTranslate Errore",
                    0x10,
                )
            except Exception:
                pass
        sys.exit(1)


if __name__ == "__main__":
    main()
