"""Windows System Tray integration using pystray and native assets."""

import os
import sys
import threading
from pathlib import Path
from typing import Callable, Optional

from PIL import Image, ImageDraw

try:
    import pystray
    PYSTRAY_AVAILABLE = True
except ImportError:
    pystray = None
    PYSTRAY_AVAILABLE = False


def create_default_icon_image() -> Image.Image:
    """Create a high-contrast icon image in case asset file is not found."""
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([0, 0, 64, 64], radius=14, fill=(2, 132, 199))
    draw.rectangle([14, 14, 22, 50], fill=(255, 255, 255))
    draw.rectangle([14, 42, 50, 50], fill=(255, 255, 255))
    draw.ellipse([42, 14, 50, 22], fill=(56, 189, 248))
    return img


class SystemTrayApp:
    """Windows System Tray Controller managing quick actions, profiles, and state."""

    def __init__(
        self,
        on_translate_selection: Callable[[], None],
        on_translate_clipboard: Callable[[], None],
        on_exit: Callable[[], None],
        icon_path: Optional[Path] = None,
    ):
        self.on_translate_selection = on_translate_selection
        self.on_translate_clipboard = on_translate_clipboard
        self.on_exit = on_exit
        self.icon_path = icon_path
        self.profile = "fast"
        self._tray_icon: Optional[Any] = None
        self._running = False

    def _get_icon_image(self) -> Image.Image:
        if self.icon_path and self.icon_path.exists():
            try:
                return Image.open(self.icon_path)
            except Exception:
                pass
        return create_default_icon_image()

    def set_profile(self, profile: str) -> None:
        self.profile = profile
        if self._tray_icon:
            self._tray_icon.menu = self._build_menu()

    def _build_menu(self):
        if not PYSTRAY_AVAILABLE or not pystray:
            return None

        return pystray.Menu(
            pystray.MenuItem("Traduci Selezione (Ctrl+Alt+T)", lambda icon, item: self.on_translate_selection(), default=True),
            pystray.MenuItem("Traduci dagli appunti", lambda icon, item: self.on_translate_clipboard()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(f"Profilo: {self.profile.upper()} (Clicca per cambiare)", lambda icon, item: self._toggle_profile()),
            pystray.MenuItem("Stato: 127.0.0.1:8765 (Online)", lambda icon, item: None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Esci da LocalTranslate", lambda icon, item: self._handle_exit()),
        )

    def _toggle_profile(self):
        new_prof = "quality" if self.profile == "fast" else "fast"
        self.set_profile(new_prof)

    def _handle_exit(self):
        self.stop()
        self.on_exit()

    def start(self) -> None:
        """Start system tray in a background thread."""
        if not PYSTRAY_AVAILABLE:
            return

        self._running = True
        img = self._get_icon_image()
        self._tray_icon = pystray.Icon(
            name="LocalTranslate",
            icon=img,
            title="LocalTranslate • 100% Offline (Ctrl+Alt+T)",
            menu=self._build_menu(),
        )

        def run_tray():
            try:
                self._tray_icon.run()
            except Exception:
                pass

        t = threading.Thread(target=run_tray, name="LocalTranslateTrayThread", daemon=True)
        t.start()

    def notify(self, title: str, message: str) -> None:
        """Display Windows system tray notification."""
        if self._tray_icon and hasattr(self._tray_icon, "notify"):
            try:
                self._tray_icon.notify(message, title)
            except Exception:
                pass

    def stop(self) -> None:
        """Stop tray icon."""
        self._running = False
        if self._tray_icon:
            try:
                self._tray_icon.stop()
            except Exception:
                pass
            self._tray_icon = None
