"""Floating Quick Translation HUD (Heads-Up Display) for instant Windows desktop translation."""

import os
import sys
import threading
from typing import Optional

try:
    import tkinter as tk
    from tkinter import font as tkfont
    TKINTER_AVAILABLE = True
except ImportError:
    tk = None
    TKINTER_AVAILABLE = False


class QuickTranslationHUD:
    """Floating, non-intrusive translation widget appearing at the cursor in any Windows app."""

    def __init__(self):
        self._window: Optional[Any] = None
        self._root: Optional[Any] = None

    def show(
        self,
        original_text: str,
        translated_text: str,
        source_lang: str = "auto",
        target_lang: str = "ita_Latn",
        device: str = "cpu",
        compute_type: str = "int8",
        duration_ms: float = 0.0,
    ) -> None:
        """Display the floating HUD with translation results."""
        if not TKINTER_AVAILABLE:
            return

        # Check if running under tests or headless
        if "PYTEST_CURRENT_TEST" in os.environ or os.environ.get("LOCALTRANSLATE_HEADLESS"):
            return

        # Check if headless / no display
        if sys.platform != "win32" and not os.environ.get("DISPLAY"):
            return

        # Run on main UI thread
        try:
            self._create_window(
                original_text=original_text,
                translated_text=translated_text,
                source_lang=source_lang,
                target_lang=target_lang,
                device=device,
                compute_type=compute_type,
                duration_ms=duration_ms,
            )
        except Exception as e:
            # Headless or display error
            pass

    def _create_window(
        self,
        original_text: str,
        translated_text: str,
        source_lang: str,
        target_lang: str,
        device: str,
        compute_type: str,
        duration_ms: float,
    ) -> None:
        root = tk.Tk()
        root.title("LocalTranslate - Quick HUD")

        # Styling: Dark Modern Fluent
        bg_dark = "#1e1e2e"
        bg_card = "#2a2b3d"
        text_light = "#f5f5f7"
        text_muted = "#a6adc8"
        accent_blue = "#0284c7"
        accent_green = "#10b981"

        root.configure(bg=bg_dark)
        root.overrideredirect(True)  # Frameless
        root.attributes("-topmost", True)  # Always on top

        # Dimensions & positioning
        width = 460
        height = 300

        # Position near mouse cursor if available
        try:
            x = root.winfo_pointerx() + 15
            y = root.winfo_pointery() + 15
            screen_w = root.winfo_screenwidth()
            screen_h = root.winfo_screenheight()
            if x + width > screen_w:
                x = screen_w - width - 20
            if y + height > screen_h:
                y = screen_h - height - 40
        except Exception:
            x = 200
            y = 200

        root.geometry(f"{width}x{height}+{x}+{y}")

        # Dragging support
        def start_move(event):
            root.x = event.x
            root.y = event.y

        def do_move(event):
            deltax = event.x - root.x
            deltay = event.y - root.y
            root.geometry(f"+{root.winfo_x() + deltax}+{root.winfo_y() + deltay}")

        # Header Frame
        header = tk.Frame(root, bg=bg_dark, height=36)
        header.pack(fill="x", padx=12, pady=(10, 4))
        header.bind("<Button-1>", start_move)
        header.bind("<B1-Motion>", do_move)

        title_lbl = tk.Label(
            header,
            text="LocalTranslate • Quick HUD",
            font=("Segoe UI", 10, "bold"),
            fg=accent_blue,
            bg=bg_dark,
        )
        title_lbl.pack(side="left")

        # Close button (X)
        def close():
            root.destroy()

        close_btn = tk.Label(
            header,
            text="✕",
            font=("Segoe UI", 10, "bold"),
            fg=text_muted,
            bg=bg_dark,
            cursor="hand2",
        )
        close_btn.pack(side="right")
        close_btn.bind("<Button-1>", lambda e: close())

        # Badge Frame
        badge_frame = tk.Frame(root, bg=bg_dark)
        badge_frame.pack(fill="x", padx=12, pady=(0, 6))

        badge_txt = f"{device.upper()} {compute_type.upper()} • {duration_ms:.0f} ms • {len(original_text)} car."
        badge_lbl = tk.Label(
            badge_frame,
            text=badge_txt,
            font=("Segoe UI", 8),
            fg=text_muted,
            bg=bg_card,
            padx=6,
            pady=2,
        )
        badge_lbl.pack(side="left")

        # Content Card Frame
        card = tk.Frame(root, bg=bg_card, padx=10, pady=8)
        card.pack(fill="both", expand=True, padx=12, pady=4)

        # Original text preview (shortened if long)
        orig_snippet = original_text.strip().replace("\n", " ")
        if len(orig_snippet) > 80:
            orig_snippet = orig_snippet[:80] + "..."
        orig_lbl = tk.Label(
            card,
            text=f"Origine ({source_lang}): {orig_snippet}",
            font=("Segoe UI", 8, "italic"),
            fg=text_muted,
            bg=bg_card,
            anchor="w",
            justify="left",
        )
        orig_lbl.pack(fill="x", pady=(0, 4))

        # Translated Text Box
        trans_box = tk.Text(
            card,
            wrap="word",
            font=("Segoe UI", 10),
            bg="#212234",
            fg=text_light,
            relief="flat",
            padx=8,
            pady=6,
            height=6,
        )
        trans_box.insert("1.0", translated_text)
        trans_box.configure(state="normal")
        trans_box.pack(fill="both", expand=True)

        # Footer Actions Frame
        footer = tk.Frame(root, bg=bg_dark, height=36)
        footer.pack(fill="x", padx=12, pady=(6, 10))

        # Copy Button
        def copy_to_clipboard():
            root.clipboard_clear()
            root.clipboard_append(translated_text)
            root.update()
            copy_btn.configure(text="Copiato! ✓", fg=accent_green)
            root.after(1200, lambda: close())

        copy_btn = tk.Button(
            footer,
            text="Copia Traduzione",
            font=("Segoe UI", 9, "bold"),
            bg=accent_blue,
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2",
            command=copy_to_clipboard,
        )
        copy_btn.pack(side="right")

        hint_lbl = tk.Label(
            footer,
            text="Premi Esc per chiudere",
            font=("Segoe UI", 8),
            fg=text_muted,
            bg=bg_dark,
        )
        hint_lbl.pack(side="left")

        # Keybindings
        root.bind("<Escape>", lambda e: close())
        root.bind("<Return>", lambda e: copy_to_clipboard())

        # Auto-focus and run
        root.focus_force()
        root.mainloop()
