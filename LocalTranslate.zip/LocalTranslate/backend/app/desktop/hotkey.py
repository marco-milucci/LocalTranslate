"""Global Windows hotkey listener and selection capturer."""

import platform
import sys
import threading
import time
from typing import Callable, Optional

# Win32 Constants
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008
MOD_NOREPEAT = 0x4000

WM_HOTKEY = 0x0312
VK_T = 0x54

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
else:
    user32 = None


def get_clipboard_text() -> str:
    """Retrieve current text content from system clipboard."""
    if IS_WINDOWS:
        try:
            import ctypes
            import ctypes.wintypes
            OpenClipboard = ctypes.windll.user32.OpenClipboard
            GetClipboardData = ctypes.windll.user32.GetClipboardData
            CloseClipboard = ctypes.windll.user32.CloseClipboard
            CF_UNICODETEXT = 13

            if OpenClipboard(None):
                try:
                    h_clip_mem = GetClipboardData(CF_UNICODETEXT)
                    if h_clip_mem:
                        p_clip_mem = ctypes.windll.kernel32.GlobalLock(h_clip_mem)
                        text = ctypes.c_wchar_p(p_clip_mem).value or ""
                        ctypes.windll.kernel32.GlobalUnlock(h_clip_mem)
                        return text
                finally:
                    CloseClipboard()
        except Exception:
            pass
    # Fallback using tkinter
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        text = root.clipboard_get()
        root.destroy()
        return text
    except Exception:
        return ""


def set_clipboard_text(text: str) -> None:
    """Copy text to system clipboard."""
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        root.destroy()
    except Exception:
        pass


def capture_active_selection() -> str:
    """Simulate Ctrl+C to capture currently selected text in any active Windows application."""
    if not IS_WINDOWS:
        return get_clipboard_text()

    # Back up existing clipboard content
    old_clipboard = get_clipboard_text()

    # Clear clipboard to detect if new content arrives
    try:
        import ctypes
        if ctypes.windll.user32.OpenClipboard(None):
            ctypes.windll.user32.EmptyClipboard()
            ctypes.windll.user32.CloseClipboard()
    except Exception:
        pass

    # Win32 Virtual Key codes
    VK_CONTROL = 0x11
    VK_MENU = 0x12
    VK_C = 0x43
    VK_T = 0x54
    KEYEVENTF_KEYUP = 0x0002

    # Crucial: explicitly release Alt and T so Windows registers pure Ctrl+C (not Ctrl+Alt+C)
    user32.keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_T, 0, KEYEVENTF_KEYUP, 0)
    time.sleep(0.04)

    # Press Ctrl, Press C, Release C, Release Ctrl
    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(VK_C, 0, 0, 0)
    time.sleep(0.03)
    user32.keybd_event(VK_C, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)

    # Wait up to 150ms for clipboard update
    for _ in range(6):
        time.sleep(0.025)
        new_text = get_clipboard_text()
        if new_text and new_text != old_clipboard:
            return new_text.strip()

    # If nothing new was copied, return existing clipboard text or new text
    curr = get_clipboard_text().strip()
    return curr or old_clipboard.strip()


class GlobalHotkeyListener:
    """Listens for system-wide Windows hotkey (Ctrl+Alt+T) to trigger translation in any context."""

    HOTKEY_ID = 1001

    def __init__(self, callback: Callable[[str], None], modifiers: int = MOD_CONTROL | MOD_ALT, vk: int = VK_T):
        self.callback = callback
        self.modifiers = modifiers | MOD_NOREPEAT if IS_WINDOWS else modifiers
        self.vk = vk
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self) -> bool:
        """Start listening for the global hotkey in a dedicated background thread."""
        if self._running:
            return True

        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="LocalTranslateHotkeyListener", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        """Stop listening and release system hotkey registration."""
        self._running = False
        if IS_WINDOWS and user32:
            try:
                user32.UnregisterHotKey(None, self.HOTKEY_ID)
            except Exception:
                pass

    def trigger_manually(self, text: Optional[str] = None) -> None:
        """Manually trigger translation callback with selected or provided text."""
        captured = text if text is not None else capture_active_selection()
        self.callback(captured or "")

    def _run_loop(self) -> None:
        """Windows message pump for global hotkeys."""
        if not IS_WINDOWS or not user32:
            # Simulated loop for non-Windows test environments
            while self._running:
                time.sleep(0.5)
            return

        # Register hotkey
        res = user32.RegisterHotKey(None, self.HOTKEY_ID, self.modifiers, self.vk)
        if not res:
            # Fallback without MOD_NOREPEAT
            user32.RegisterHotKey(None, self.HOTKEY_ID, self.modifiers & ~MOD_NOREPEAT, self.vk)

        msg = wintypes.MSG()
        while self._running:
            # Peek and get message
            if user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                if msg.message == WM_HOTKEY and msg.wParam == self.HOTKEY_ID:
                    # Capture selection and trigger callback (always call so window opens even if selection empty)
                    selected_text = capture_active_selection()
                    self.callback(selected_text or "")
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            else:
                break
