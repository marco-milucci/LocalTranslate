' LocalTranslate - Avvio Silenzioso per Windows (Nessuna finestra di comando)
Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

strScriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)
strVenvPythonw = strScriptDir & "\.venv\Scripts\pythonw.exe"

' Controlla se l'installazione iniziale e' stata completata
If Not FSO.FileExists(strVenvPythonw) Then
    MsgBox "LocalTranslate non e' ancora installato!" & vbCrLf & vbCrLf & _
           "Prima del primo utilizzo, fai doppio clic sul file:" & vbCrLf & _
           "'1-INSTALLA-SUBITO.bat'" & vbCrLf & vbCrLf & _
           "L'installazione automatica preparera' l'ambiente e scarichera' il modello locale (600 MB) una sola volta.", _
           vbExclamation, "LocalTranslate - Installazione richiesta"
    WScript.Quit 1
End If

' Avvia il desktop launcher con finestra completamente nascosta (0)
strCommand = """" & strVenvPythonw & """ -m backend.app.desktop.app_launcher"
WshShell.CurrentDirectory = strScriptDir
WshShell.Run strCommand, 0, False
