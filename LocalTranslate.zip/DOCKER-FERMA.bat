@echo off
title LocalTranslate - Arresto Docker
cd /d "%~dp0"

echo Arresto di LocalTranslate container in corso...
docker compose down

echo.
echo LocalTranslate e' stato arrestato.
timeout /t 3 >nul
exit
