@echo off
title LocalTranslate
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    set "PYTHON_EXE=.venv\Scripts\python.exe"
) else (
    set "PYTHON_EXE=python.exe"
)

echo ==========================================================
echo          LocalTranslate - Avvio Desktop Universale
echo ==========================================================
echo Avvio del servizio in background e scorciatoia globale Ctrl+Alt+T...
"%PYTHON_EXE%" -m backend.app.desktop.app_launcher
pause
