@echo off
title LocalTranslate - Crea Icona Desktop
cd /d "%~dp0"

echo Creazione icona ufficiale sul Desktop di Windows...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "windows\create-desktop-shortcut.ps1"

echo.
echo Operazione completata. Controlla il tuo Desktop!
pause
