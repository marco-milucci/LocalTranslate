@echo off
title LocalTranslate - Avvio tramite Docker
color 0B
cd /d "%~dp0"

echo ================================================================
echo            LocalTranslate - Avvio con Docker Container
echo          100%% Offline Traduzione Locale - Zero Cloud
echo ================================================================
echo.

:: 1. Verifica che Docker Desktop sia attivo
docker info >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERRORE] Docker non e' in esecuzione sul tuo PC!
    echo.
    echo Per favore avvia Docker Desktop su Windows e attendi che sia pronto.
    echo Dopo che l'icona della balena di Docker e' verde, rilancia questo file.
    echo.
    pause
    exit /b 1
)

echo [1/3] Verifica immagine Docker e container...
docker compose up -d --build

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERRORE] Impossibile avviare il container Docker.
    echo Se sei dietro un proxy aziendale, assicurati di aver configurato il proxy
    echo in Docker Desktop:
    echo   Impostazioni (ingranaggio) -> Resources -> Proxies
    echo.
    pause
    exit /b 1
)

echo.
echo [2/3] Verifica stato del modello di traduzione...
if not exist "backend\models\manifest.json" (
    if not exist "backend\models\nllb-200-distilled-600M-int8\manifest.json" (
        echo.
        echo [ATTENZIONE] Il modello locale (600 MB) non e' ancora stato scaricato!
        echo Vuoi scaricarlo adesso direttamente dentro il container Docker?
        echo (Usa la connessione Internet configurata in Docker Desktop)
        echo.
        choice /C SN /M "Scaricare il modello adesso (S/N)?"
        if errorlevel 2 goto fine_avvio
        echo.
        echo Download e ottimizzazione INT8 in corso dentro Docker...
        docker compose exec localtranslate python -m backend.scripts.download_and_convert
    )
)

:fine_avvio
echo.
echo ================================================================
echo [SUCCESSO] LocalTranslate e' ATTIVO su Docker (127.0.0.1:8765)!
echo.
echo - Tutte le dipendenze Python sono isolate nel container Docker.
echo - Il tuo sistema Windows non richiede installazioni pip locali.
echo.
echo Utilizzo con Chrome / Edge:
echo   1. Apri chrome://extensions (o edge://extensions)
echo   2. Carica la cartella "extension"
echo   3. Fai click destro su qualsiasi testo -> LocalTranslate -> Traduci!
echo.
echo Per fermare il servizio in qualsiasi momento, usa:
echo   "DOCKER-FERMA.bat"
echo ================================================================
echo.
pause
