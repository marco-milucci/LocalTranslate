@echo off
title LocalTranslate - Installazione Automatica Windows
color 0B
cd /d "%~dp0"

echo ================================================================
echo            LocalTranslate - Installazione Automatica
echo          100%% Offline Traduzione Locale - Zero Cloud
echo ================================================================
echo.
echo Verifica prerequisiti e avvio della configurazione guidata...
echo.

:: 1. Rileva comando Python (python o py launcher standard di Windows)
set PYTHON_CMD=python
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    where py >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set PYTHON_CMD=py
    ) else (
        echo [ERRORE] Python non e' stato trovato nel sistema!
        echo.
        echo Per favore installa Python 3.11 o superiore da https://www.python.org
        echo IMPORTANTE: Durante l'installazione di Python, metti la spunta su:
        echo "Add python.exe to PATH"
        echo.
        pause
        exit /b 1
    )
)

:: 2. Ripristina variabili proxy per evitare errori socket su proxy disattivati
set HTTP_PROXY=
set HTTPS_PROXY=
set ALL_PROXY=

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "windows\install.ps1" -PythonPath "%PYTHON_CMD%"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ================================================================
    echo [SUCCESSO] Installazione completata con successo!
    echo.
    echo L'icona "LocalTranslate" e' stata creata sul tuo Desktop.
    echo.
    echo Puoi avviare LocalTranslate facendo doppio clic sull'icona 
    echo creata sul Desktop oppure facendo doppio clic su:
    echo "2-AVVIA-LOCALTRANSLATE.bat"
    echo ================================================================
) else (
    echo.
    echo ================================================================
    echo [ERRORE] Si e' verificato un problema durante l'installazione.
    echo Assicurati di avere connessione Internet attiva per il download
    echo iniziale del modello locale (600 MB).
    echo ================================================================
)

echo.
pause
