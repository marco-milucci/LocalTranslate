# -*- mode: python ; coding: utf-8 -*-
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Collect CTranslate2, SentencePiece, and Transformers metadata
ctranslate2_datas = collect_data_files('ctranslate2')
transformers_datas = collect_data_files('transformers')
assets_datas = [('../assets/LocalTranslate.ico', 'assets')]

a = Analysis(
    ['app/desktop/app_launcher.py'],
    pathex=['.', '..'],
    binaries=[],
    datas=ctranslate2_datas + transformers_datas + assets_datas,
    hiddenimports=[
        'uvicorn.logging',
        'uvicorn.loops',
        'uvicorn.loops.auto',
        'uvicorn.protocols',
        'uvicorn.protocols.http',
        'uvicorn.protocols.http.auto',
        'uvicorn.protocols.websockets',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.lifespans',
        'uvicorn.lifespans.on',
        'ctranslate2',
        'sentencepiece',
        'psutil',
        'pystray',
        'pystray._win32',
        'PIL',
        'PIL.Image',
        'tkinter',
        'backend.app.main',
        'backend.app.config',
        'backend.app.api.routes_health',
        'backend.app.api.routes_capabilities',
        'backend.app.api.routes_translate',
        'backend.app.api.routes_jobs',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['torch', 'torchvision', 'torchaudio', 'scipy', 'matplotlib'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LocalTranslate',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    icon='../assets/LocalTranslate.ico',
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LocalTranslate',
)
