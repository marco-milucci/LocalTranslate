"""Main desktop application launcher combining background server, tray, hotkey, and HUD."""

import json
import os
import signal
import socket
import sys
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any, Dict, Optional

# Setup import path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.config import settings
from backend.app.core.chunker import IntelligentChunker
from backend.app.core.hardware import HardwareDetector
from backend.app.core.language_detector import LocalLanguageDetector
from backend.app.core.languages import normalize_language_code
from backend.app.core.logging_filter import logger
from backend.app.core.profiles import get_profile
from backend.app.desktop.hotkey import GlobalHotkeyListener, capture_active_selection, get_clipboard_text
from backend.app.desktop.quick_hud import QuickTranslationHUD
from backend.app.desktop.tray import SystemTrayApp
from backend.app.engine.batch_manager import BatchManager
from backend.app.engine.ctranslate2_engine import CTranslate2TranslationEngine
from backend.app.engine.model_manager import ModelManager, ModelNotInstalledError


def find_available_port(start_port: int = 8765, max_attempts: int = 15) -> int:
    """Find the first available TCP port on 127.0.0.1 starting from start_port."""
    for port in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return start_port


class LocalTranslateDesktopApp:
    """Universal desktop application runner for Windows."""

    def __init__(self, port: Optional[int] = None):
        # Resolve port dynamically to avoid socket collisions (WinError 10061 / 10048)
        if port is not None:
            self.port = port
        else:
            self.port = find_available_port(start_port=8765, max_attempts=15)

        # Persist active port for browser extension and CLI tools
        try:
            port_file = PROJECT_ROOT / ".localtranslate_port"
            port_file.write_text(str(self.port), encoding="utf-8")
        except Exception:
            pass

        self.hud = QuickTranslationHUD()
        self.profile = "fast"
        self._running = False
        self._server_thread: Optional[threading.Thread] = None

        # Direct in-process translation engine for 100% offline desktop hotkeys (0 network sockets)
        self.hardware = HardwareDetector.detect()
        self.engine = CTranslate2TranslationEngine(hardware=self.hardware)
        self.model_manager = ModelManager(model_dir=settings.default_model_dir, engine=self.engine)
        self.batch_manager = BatchManager(engine=self.engine)

        icon_path = PROJECT_ROOT / "assets" / "LocalTranslate.ico"
        self.tray = SystemTrayApp(
            on_translate_selection=self.translate_selection,
            on_translate_clipboard=self.translate_clipboard,
            on_exit=self.shutdown,
            icon_path=icon_path,
        )
        self.hotkey_listener = GlobalHotkeyListener(callback=self._handle_captured_text)

    def is_server_alive(self) -> bool:
        """Check if local backend is responding on localhost."""
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}/health")
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                return resp.status == 200
        except Exception:
            return False

    def start_background_server(self) -> None:
        """Run uvicorn server in background thread if not already running."""
        if self.is_server_alive():
            logger.info("LocalTranslate server already running on 127.0.0.1:%s", self.port)
            return

        def run_uvicorn():
            try:
                import uvicorn
                from backend.app.main import app
                config = uvicorn.Config(
                    app=app,
                    host="127.0.0.1",
                    port=self.port,
                    log_level="warning",
                    access_log=False,
                )
                server = uvicorn.Server(config)
                server.run()
            except Exception as ex:
                logger.error("Uvicorn server error on port %s: %s", self.port, ex)

        self._server_thread = threading.Thread(target=run_uvicorn, name="LocalTranslateServerThread", daemon=True)
        self._server_thread.start()

        # Wait for server ready (up to 8 seconds)
        for _ in range(40):
            if self.is_server_alive():
                logger.info("LocalTranslate backend server ready on 127.0.0.1:%s", self.port)
                break
            time.sleep(0.2)

    def _translate_in_process(
        self,
        text: str,
        source_lang: str = "auto",
        target_lang: str = "ita_Latn",
        profile_name: str = "fast",
    ) -> Dict[str, Any]:
        """Perform instant 100% in-process offline translation without network sockets."""
        if not self.model_manager.provider.is_available():
            raise ModelNotInstalledError("Modello non installato")

        if not self.engine.is_loaded():
            self.model_manager.load()

        profile = get_profile(profile_name)

        detected_lang = None
        confidence = None
        if source_lang.lower() == "auto":
            detection = LocalLanguageDetector.detect(text)
            if detection.is_reliable and detection.language:
                source_lang = detection.language
                detected_lang = detection.language
                confidence = detection.confidence
            else:
                source_lang = "eng_Latn"
        else:
            source_lang = normalize_language_code(source_lang)

        target_lang = normalize_language_code(target_lang)

        t0 = time.perf_counter()
        chunks = IntelligentChunker.chunk_text(text)
        translated_text = self.batch_manager.translate_chunks(
            chunks=chunks,
            source_lang=source_lang,
            target_lang=target_lang,
            profile=profile,
        )
        duration_ms = (time.perf_counter() - t0) * 1000.0
        dev_info = self.engine.get_device_info()

        return {
            "translation": translated_text,
            "source_language": source_lang,
            "target_language": target_lang,
            "device": dev_info.get("device", "cpu"),
            "compute_type": dev_info.get("compute_type", "int8"),
            "duration_ms": duration_ms,
            "detected_language": detected_lang,
            "detection_confidence": confidence,
        }

    def _handle_captured_text(self, text: str) -> None:
        """Translate captured text and display in floating HUD."""
        clean = text.strip()
        if not clean:
            return

        profile_name = self.tray.profile if hasattr(self, "tray") else "fast"

        # Check if model is installed
        if not self.model_manager.provider.is_available():
            self.hud.show(
                original_text=clean,
                translated_text=(
                    "⚠️ Modello locale non ancora installato!\n\n"
                    "LocalTranslate esegue tutte le traduzioni al 100% in locale sul tuo computer (zero cloud, massima privacy).\n\n"
                    "👉 Fai doppio clic sul file:\n"
                    "   '1-INSTALLA-SUBITO.bat'\n"
                    "nella cartella di LocalTranslate per scaricare il modello locale (600 MB) una sola volta."
                ),
                source_lang="auto",
                target_lang="ita_Latn",
                device="info",
                compute_type="guida",
                duration_ms=0.0,
            )
            return

        # 1. Attempt in-process translation first (0 network sockets, completely immune to WinError 10061)
        try:
            res = self._translate_in_process(
                clean,
                source_lang="auto",
                target_lang="ita_Latn",
                profile_name=profile_name,
            )
            self.hud.show(
                original_text=clean,
                translated_text=res["translation"],
                source_lang=res.get("detected_language") or res.get("source_language", "auto"),
                target_lang=res.get("target_language", "ita_Latn"),
                device=res.get("device", "cpu"),
                compute_type=res.get("compute_type", "int8"),
                duration_ms=res.get("duration_ms", 0.0),
            )
            return
        except Exception as in_proc_err:
            logger.warning("In-process translation error: %s. Falling back to HTTP...", in_proc_err)

        # 2. Fallback to local HTTP server
        try:
            url = f"http://127.0.0.1:{self.port}/v1/translate"
            payload = json.dumps({
                "text": clean,
                "source_language": "auto",
                "target_language": "ita_Latn",
                "profile": profile_name,
            }).encode("utf-8")

            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            self.hud.show(
                original_text=clean,
                translated_text=data.get("translation", ""),
                source_lang=data.get("detected_language") or data.get("source_language", "auto"),
                target_lang=data.get("target_language", "ita_Latn"),
                device=data.get("device", "cpu"),
                compute_type=data.get("compute_type", "int8"),
                duration_ms=data.get("duration_ms", 0.0),
            )
        except Exception as e:
            err_str = str(e)
            if "10061" in err_str or "Connection refused" in err_str:
                user_msg = (
                    "⚠️ Impossibile contattare il server locale (127.0.0.1).\n\n"
                    "Possibili cause:\n"
                    "1. L'installazione iniziale non è stata completata. Esegui '1-INSTALLA-SUBITO.bat'.\n"
                    "2. Il server locale è ancora in fase di avvio. Riprova tra pochi secondi."
                )
            else:
                user_msg = f"Errore durante la traduzione: {err_str}"

            logger.error("Error during desktop translation: %s", e)
            self.hud.show(
                original_text=clean,
                translated_text=user_msg,
                source_lang="auto",
                target_lang="ita_Latn",
                device="errore",
                compute_type="",
                duration_ms=0.0,
            )

    def translate_selection(self) -> None:
        """Trigger capture and translation of active selection."""
        captured = capture_active_selection()
        if captured:
            self._handle_captured_text(captured)

    def translate_clipboard(self) -> None:
        """Trigger translation of current clipboard contents."""
        text = get_clipboard_text()
        if text:
            self._handle_captured_text(text)

    def run(self) -> None:
        """Start all desktop components."""
        self._running = True
        print("[LocalTranslate] Avvio dell'applicazione desktop universale...")

        # 1. Start background server on active port
        self.start_background_server()

        # 2. Start global hotkey listener
        self.hotkey_listener.start()
        print("[LocalTranslate] Scorciatoia globale attiva: Ctrl+Alt+T in qualsiasi programma.")

        # 3. Start System Tray icon
        self.tray.start()
        print("[LocalTranslate] Icona di notifica presente nella System Tray.")

        # Show ready notification
        self.tray.notify(
            "LocalTranslate Attivo",
            "Premi Ctrl+Alt+T su qualsiasi testo selezionato per tradurlo all'istante!"
        )

        # Keep alive
        try:
            while self._running:
                time.sleep(1.0)
        except (KeyboardInterrupt, SystemExit):
            self.shutdown()

    def shutdown(self) -> None:
        """Stop all desktop services and exit."""
        self._running = False
        print("\n[LocalTranslate] Arresto dell'applicazione desktop in corso...")
        self.hotkey_listener.stop()
        self.tray.stop()
        if self.engine and self.engine.is_loaded():
            self.engine.unload()
        sys.exit(0)


def main():
    app = LocalTranslateDesktopApp()
    app.run()


if __name__ == "__main__":
    main()
